package github.com.gengyoubo.util;

import github.com.gengyoubo.core.MPSynchedDataCore;
import net.minecraft.class_1297;
import net.minecraft.class_2940;

public enum MPEntityData {
    manaita,
    death,
    remove;

    public static final String KEY = "manaita_plus_general_type";
    public static final class_2940<Integer> TYPE = MPSynchedDataCore.get();

    private final String tagName;
    private final int flag;

    MPEntityData() {
        this.tagName = name();
        this.flag = 1 << ordinal();
    }

    public void add(class_1297 entity) {
        if (entity == null) {
            return;
        }

        entity.method_5780(tagName);
        if (entity.method_5841().method_51696(TYPE)) {
            entity.method_5841().method_12778(TYPE, entity.method_5841().method_12789(TYPE) | flag);
        }
    }

    public void remove(class_1297 entity) {
        if (entity == null) {
            return;
        }

        entity.method_5738(tagName);
        if (entity.method_5841().method_51696(TYPE)) {
            entity.method_5841().method_12778(TYPE, entity.method_5841().method_12789(TYPE) & ~flag);
        }
    }

    public boolean accept(class_1297 entity) {
        if (entity == null) {
            return false;
        }

        return entity.method_5752().contains(tagName)
                || (entity.method_5841().method_51696(TYPE) && (entity.method_5841().method_12789(TYPE) & flag) != 0);
    }

    public int getFlag() {
        return flag;
    }
}
