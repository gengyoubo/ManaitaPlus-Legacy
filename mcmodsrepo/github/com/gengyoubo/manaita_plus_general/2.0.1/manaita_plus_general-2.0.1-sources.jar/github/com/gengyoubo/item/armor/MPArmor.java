package github.com.gengyoubo.item.armor;

import com.google.common.collect.Lists;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import github.com.gengyoubo.item.data.IMPKey;
import github.com.gengyoubo.util.MPText;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1702;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_4081;
import net.minecraft.class_5134;

public class MPArmor extends class_1738 {
    private static final float DEFAULT_WALKING_SPEED = 0.1F;
    private static final float DEFAULT_FLYING_SPEED = 0.05F;

    protected MPArmor(class_8051 type) {
        super(new ManaitaArmorMaterial(), type, new class_1792.class_1793().method_24359());
    }

    @Override
    public void method_7851(@NotNull class_1799 stack, @Nullable class_1937 level, List<class_2561> tooltip, @NotNull class_1836 flag) {
        tooltip.add(class_2561.method_43470(MPText.manaita_infinity.formatting(class_2561.method_43471("info.armor").getString())));
    }

    public static void syncArmorState(class_1657 player) {
        class_1799 helmet = player.method_31548().field_7548.get(3);
        class_1799 leggings = player.method_31548().field_7548.get(1);
        class_1799 boots = player.method_31548().field_7548.get(0);

        if (!(helmet.method_7909() instanceof Helmet) && player.method_6059(class_1294.field_5925)) {
            player.method_6016(class_1294.field_5925);
        }

        if (!(leggings.method_7909() instanceof Leggings) && !player.method_6059(class_1294.field_5905)) {
            player.method_5648(false);
        }

        if (!(boots.method_7909() instanceof Boots)) {
            boolean abilityChanged = false;
            if (!player.method_7337() && !player.method_7325()) {
                if (player.method_31549().field_7478) {
                    player.method_31549().field_7478 = false;
                    abilityChanged = true;
                }
                if (player.method_31549().field_7479) {
                    player.method_31549().field_7479 = false;
                    abilityChanged = true;
                }
            }

            Objects.requireNonNull(player.method_5996(class_5134.field_23719)).method_6192(DEFAULT_WALKING_SPEED);
            player.method_31549().method_7250(DEFAULT_WALKING_SPEED);
            player.method_31549().method_7248(DEFAULT_FLYING_SPEED);

            if (abilityChanged && player instanceof class_3222 serverPlayer) {
                serverPlayer.method_7355();
            }
        }
    }

    static class ManaitaArmorMaterial implements class_1741 {
        @Override
        public int method_48402(@NotNull class_8051 type) {
            return -1;
        }

        @Override
        public int method_48403(@NotNull class_8051 type) {
            return 0;
        }

        @Override
        public int method_7699() {
            return 0;
        }

        @Override
        public @NotNull class_3414 method_7698() {
            return class_3417.field_14684;
        }

        @Override
        public @NotNull class_1856 method_7695() {
            return class_1856.field_9017;
        }

        @Override
        public @NotNull String method_7694() {
            return "manaita_armor";
        }

        @Override
        public float method_7700() {
            return 0;
        }

        @Override
        public float method_24355() {
            return 0;
        }
    }

    public static class Helmet extends MPArmor implements IMPKey {
        public Helmet() {
            super(class_8051.field_41934);
        }

        @Override
        public void method_7851(@NotNull class_1799 stack, @Nullable class_1937 level, List<class_2561> tooltip, @NotNull class_1836 flag) {
            tooltip.add(class_2561.method_43470(
                    MPText.manaita_mode.formatting(
                            class_2561.method_43471("mode.nightvision").getString() + ": " + (getNightVision(stack) ? class_2561.method_43471("info.on").getString() : class_2561.method_43471("info.off").getString()))));
            super.method_7851(stack, level, tooltip, flag);
        }

        @Override
        public @NotNull class_2561 method_7864(@NotNull class_1799 stack) {
            return class_2561.method_43471("item.helmet.name");
        }

        public String getArmorTexture(class_1799 stack, class_1297 entity, class_1304 slot, String type) {
            return "manaita_plus_general:textures/models/armor/manaita_armor_layer_1.png";
        }

        @Override
        public void method_7888(@NotNull class_1799 stack, @NotNull class_1937 level, @NotNull class_1297 entity, int slot, boolean selected) {
            if (slot == 3 && entity instanceof class_1657 player) {
                player.method_5855(300);
                class_1702 foodData = player.method_7344();
                if (foodData.method_7586() < 20) {
                    foodData.method_7580(20);
                }
                if (foodData.method_7589() < 20) {
                    foodData.method_7581(20);
                }
                foodData.method_35218(0);
                if (getNightVision(stack)) {
                    player.method_6092(new class_1293(class_1294.field_5925, 400, 0, false, false));
                }
            }
        }

        public static boolean getNightVision(class_1799 itemStack) {
            return itemStack.method_7948().method_10577("NightVision");
        }

        @Override
        public void onManaitaKeyPress(class_1799 itemStack) {
            itemStack.method_7948().method_10556("NightVision", !getNightVision(itemStack));
        }

        @Override
        public void onManaitaKeyPressOnClient(class_1799 itemStack, class_1657 player) {
            onManaitaKeyPress(itemStack);
            player.method_7353(class_2561.method_43470(
                    MPText.manaita_mode.formatting(String.format("[%s] %s: %s",
                            class_2561.method_43471("item.helmet.name").getString(), class_2561.method_43471("mode.nightvision").getString(),
                            getNightVision(itemStack) ? class_2561.method_43471("info.on").getString() : class_2561.method_43471("info.off").getString()))), true);
        }
    }

    public static class Chestplate extends MPArmor {
        public Chestplate() {
            super(class_8051.field_41935);
        }

        @Override
        public @NotNull class_2561 method_7864(@NotNull class_1799 stack) {
            return class_2561.method_43471("item.chestplate.name");
        }

        public String getArmorTexture(class_1799 stack, class_1297 entity, class_1304 slot, String type) {
            return "manaita_plus_general:textures/models/armor/manaita_armor_layer_1.png";
        }

        @Override
        public void method_7888(@NotNull class_1799 stack, @NotNull class_1937 level, @NotNull class_1297 entity, int slot, boolean selected) {
            if (slot == 2 && entity instanceof class_1657 player) {
                List<class_1291> badEffects = Lists.newArrayList();
                for (class_1293 effect : player.method_6026()) {
                    if (effect.method_5579().method_18792() == class_4081.field_18272) {
                        badEffects.add(effect.method_5579());
                    }
                }
                for (class_1291 effect : badEffects) {
                    player.method_6016(effect);
                }
            }
        }
    }

    public static class Leggings extends MPArmor implements IMPKey {
        public Leggings() {
            super(class_8051.field_41936);
        }

        @Override
        public @NotNull class_2561 method_7864(@NotNull class_1799 stack) {
            return class_2561.method_43471("item.leggings.name");
        }

        public String getArmorTexture(class_1799 stack, class_1297 entity, class_1304 slot, String type) {
            return "manaita_plus_general:textures/models/armor/manaita_armor_layer_2.png";
        }

        @Override
        public void method_7888(@NotNull class_1799 stack, @NotNull class_1937 level, @NotNull class_1297 entity, int slot, boolean selected) {
            if (slot == 1 && entity instanceof class_1657 player) {
                player.method_20803(0);
                if (getInvisibility(stack)) {
                    player.method_6092(new class_1293(class_1294.field_5905, 400, 0, false, false));
                    player.method_5648(true);
                } else {
                    player.method_5648(false);
                }
            }
        }

        @Override
        public void method_7851(@NotNull class_1799 stack, @Nullable class_1937 level, List<class_2561> tooltip, @NotNull class_1836 flag) {
            tooltip.add(class_2561.method_43470(
                    MPText.manaita_mode.formatting(
                            class_2561.method_43471("mode.invisibility").getString() + ": " + (getInvisibility(stack) ? class_2561.method_43471("info.on").getString() : class_2561.method_43471("info.off").getString()))));
            super.method_7851(stack, level, tooltip, flag);
        }

        public static boolean getInvisibility(class_1799 itemStack) {
            return itemStack.method_7948().method_10577("Invisibility");
        }

        @Override
        public void onManaitaKeyPress(class_1799 itemStack) {
            itemStack.method_7948().method_10556("Invisibility", !getInvisibility(itemStack));
        }

        @Override
        public void onManaitaKeyPressOnClient(class_1799 itemStack, class_1657 player) {
            onManaitaKeyPress(itemStack);
            player.method_7353(class_2561.method_43470(
                    MPText.manaita_mode.formatting(String.format("[%s] %s: %s",
                            class_2561.method_43471("item.leggings.name").getString(), class_2561.method_43471("mode.invisibility").getString(),
                            getInvisibility(itemStack) ? class_2561.method_43471("info.on").getString() : class_2561.method_43471("info.off").getString()))), true);
        }
    }

    public static class Boots extends MPArmor implements IMPKey {
        public Boots() {
            super(class_8051.field_41937);
        }

        @Override
        public @NotNull class_2561 method_7864(@NotNull class_1799 stack) {
            return class_2561.method_43471("item.boots.name");
        }

        public String getArmorTexture(class_1799 stack, class_1297 entity, class_1304 slot, String type) {
            return "manaita_plus_general:textures/models/armor/manaita_armor_layer_2.png";
        }

        @Override
        public void method_7888(@NotNull class_1799 stack, @NotNull class_1937 level, @NotNull class_1297 entity, int slot, boolean selected) {
            if (slot == 0 && entity instanceof class_1657 player) {
                player.method_31549().field_7478 = true;
                int speed = getSpeed(stack);
                float baseSpeed = 0.1F * speed;
                Objects.requireNonNull(player.method_5996(class_5134.field_23719)).method_6192(baseSpeed);
                player.method_31549().method_7250(baseSpeed);
                player.method_31549().method_7248(baseSpeed / 2.0F);
            }
        }

        public static int getSpeed(class_1799 itemStack) {
            return Math.max(itemStack.method_7948().method_10550("Speed"), 1);
        }

        @Override
        public void onManaitaKeyPress(class_1799 itemStack) {
            int next = Math.max(1, itemStack.method_7948().method_10550("Speed") + 1) % 10;
            itemStack.method_7948().method_10569("Speed", next == 0 ? 1 : next);
        }

        @Override
        public void onManaitaKeyPressOnClient(class_1799 itemStack, class_1657 player) {
            onManaitaKeyPress(itemStack);
            player.method_7353(class_2561.method_43470(
                    MPText.manaita_mode.formatting(String.format("[%s] %s: %d",
                            class_2561.method_43471("item.boots.name").getString(), class_2561.method_43471("mode.speed").getString(), getSpeed(itemStack)))), true);
        }
    }
}

