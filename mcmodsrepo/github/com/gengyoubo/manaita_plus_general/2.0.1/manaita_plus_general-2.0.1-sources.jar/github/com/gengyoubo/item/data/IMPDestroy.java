package github.com.gengyoubo.item.data;

import net.minecraft.class_1799;
import net.minecraft.class_2680;

public interface IMPDestroy {
    boolean accept(class_2680 state);
    int getRange(class_1799 itemStack);
    // --娉ㄩ噴鎺夋鏌?(2026/4/24 23:35):void setRange(ItemStack itemStack,int range);
}

