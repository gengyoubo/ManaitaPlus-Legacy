package github.com.gengyoubo.item.portable;

import github.com.gengyoubo.menu.MPCraftingMenu;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;

public class MPCraftingPortable extends MPGPortableItem {
    public MPCraftingPortable() {
        super("item.portableCrafting.");
    }

    @Override
    protected void openPortableMenu(class_3222 serverPlayer, class_1799 itemInHand, class_1937 level) {
        openPortableScreen(serverPlayer, itemInHand, level, "container.crafting_manaita",
                (containerId, inventory, player, heldStack, world) -> new MPCraftingMenu(containerId, inventory, player.method_37908()));
    }
}



