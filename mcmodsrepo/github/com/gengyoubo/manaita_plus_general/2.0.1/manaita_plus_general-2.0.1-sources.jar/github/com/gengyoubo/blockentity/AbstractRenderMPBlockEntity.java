package github.com.gengyoubo.blockentity;

import github.com.gengyoubo.block.data.MPBlockData;
import github.com.gengyoubo.core.MPBlockCore;
import github.com.gengyoubo.util.MPNBTData;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_776;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;
import net.minecraft.class_918;
import org.jetbrains.annotations.NotNull;

public abstract class AbstractRenderMPBlockEntity<T extends class_2586> implements class_827<T> {
    private final class_1799 displayStack;
    private final class_2680 hookBlockTemplate;

    protected AbstractRenderMPBlockEntity(class_1799 displayStack) {
        this.displayStack = displayStack;
        this.hookBlockTemplate = MPBlockCore.HookBlock.get().method_9564();
        this.displayStack.method_7980(new class_2487());
    }

    @Override
    public void method_3569(T blockEntity, float partialTick, class_4587 poseStack, @NotNull class_4597 bufferSource, int packedLight, int packedOverlay) {
        class_2680 blockState = blockEntity.method_11010();
        class_2350 direction = blockState.method_11654(MPBlockData.FACING);
        class_2350 wall = blockState.method_11654(MPBlockData.WALL);

        poseStack.method_22903();
        applyWallTransform(poseStack, wall, direction);
        renderMainBlockItem(blockEntity, blockState, poseStack, bufferSource, packedLight, packedOverlay);
        poseStack.method_22909();

        renderHook(blockState, poseStack, bufferSource, packedLight, packedOverlay);
    }

    private void renderMainBlockItem(T blockEntity, class_2680 blockState, class_4587 poseStack, class_4597 bufferSource, int packedLight, int packedOverlay) {
        displayStack.method_7948().method_10569(MPNBTData.ItemType, blockState.method_11654(MPBlockData.TYPES));
        class_918 itemRenderer = class_310.method_1551().method_1480();
        class_1087 bakedModel = itemRenderer.method_4019(displayStack, blockEntity.method_10997(), null, 0);
        itemRenderer.method_23179(displayStack, class_811.field_4319, true, poseStack, bufferSource, packedLight, packedOverlay, bakedModel);
    }

    private void renderHook(class_2680 blockState, class_4587 poseStack, class_4597 bufferSource, int packedLight, int packedOverlay) {
        int hookType = blockState.method_11654(MPBlockData.HOOK);
        if (hookType == 8) {
            return;
        }

        class_776 blockRenderer = class_310.method_1551().method_1541();
        class_2680 hookBlock = hookBlockTemplate
                .method_11657(MPBlockData.FACING, blockState.method_11654(MPBlockData.FACING))
                .method_11657(MPBlockData.TYPES, hookType);
        blockRenderer.method_3353(hookBlock, poseStack, bufferSource, packedLight, packedOverlay);
    }

    private static void applyWallTransform(class_4587 poseStack, class_2350 wall, class_2350 direction) {
        switch (wall) {
            case field_11043:
                poseStack.method_46416(0.5F, 0.5F, 0.0F);
                poseStack.method_22907(class_7833.field_40718.rotationDegrees(-90.0F));
                break;
            case field_11035:
                poseStack.method_46416(0.5F, 0.5F, 1.0F);
                poseStack.method_22907(class_7833.field_40718.rotationDegrees(90.0F));
                break;
            case field_11039:
                poseStack.method_46416(0.0F, 0.5F, 0.5F);
                poseStack.method_22907(class_7833.field_40714.rotationDegrees(90.0F));
                poseStack.method_22907(class_7833.field_40716.rotationDegrees(90.0F));
                break;
            case field_11034:
                poseStack.method_46416(1.0F, 0.5F, 0.5F);
                poseStack.method_22907(class_7833.field_40714.rotationDegrees(90.0F));
                poseStack.method_22907(class_7833.field_40716.rotationDegrees(90.0F));
                break;
            case field_11036:
                poseStack.method_46416(0.5F, 1.0F, 0.5F);
                applyVerticalFacing(poseStack, direction);
                break;
            case field_11033:
                poseStack.method_46416(0.5F, 0.0F, 0.5F);
                applyVerticalFacing(poseStack, direction);
                break;
        }
    }

    private static void applyVerticalFacing(class_4587 poseStack, class_2350 direction) {
        switch (direction) {
            case field_11043:
                poseStack.method_22907(class_7833.field_40714.rotationDegrees(90.0F));
                break;
            case field_11035:
                poseStack.method_22907(class_7833.field_40714.rotationDegrees(-90.0F));
                break;
            case field_11039:
                poseStack.method_22907(class_7833.field_40714.rotationDegrees(90.0F));
                poseStack.method_22907(class_7833.field_40718.rotationDegrees(90.0F));
                break;
            case field_11034:
                poseStack.method_22907(class_7833.field_40714.rotationDegrees(90.0F));
                poseStack.method_22907(class_7833.field_40718.rotationDegrees(-90.0F));
                break;
        }
    }
}
