package github.com.gengyoubo.gui;

import github.com.gengyoubo.MPGConfig;
import github.com.gengyoubo.menu.MPBrewingStandMenu;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_465;
import org.jetbrains.annotations.NotNull;

public class MPBrewingStandScreen extends class_465<MPBrewingStandMenu> {
    private static final class_2960 BREWING_STAND_LOCATION = new class_2960("textures/gui/container/brewing_stand.png");
    private static final int[] BUBBLE_LENGTHS = new int[]{29, 24, 20, 16, 11, 6, 0};
    private final String doublingText;

    public MPBrewingStandScreen(MPBrewingStandMenu menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
        doublingText = MPGConfig.brewing_doubling_value + "x";
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        this.field_25267 = (this.field_2792 - this.field_22793.method_27525(this.field_22785)) / 2;
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.method_25420(guiGraphics);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        this.method_2380(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void method_2388(class_332 guiGraphics, int mouseX, int mouseY) {
        guiGraphics.method_51439(this.field_22793, this.field_22785, this.field_25267, this.field_25268, 4210752, false);
        guiGraphics.method_51439(this.field_22793, this.field_29347, this.field_25269, this.field_25270, 4210752, false);
        guiGraphics.method_51433(this.field_22793, doublingText, this.field_25267 + this.field_22793.method_27525(this.field_22785), this.field_25268, 4210752, false);
    }

    @Override
    protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        int left = (this.field_22789 - this.field_2792) / 2;
        int top = (this.field_22790 - this.field_2779) / 2;
        guiGraphics.method_25302(BREWING_STAND_LOCATION, left, top, 0, 0, this.field_2792, this.field_2779);
        int fuel = this.field_2797.getFuel();
        int fuelWidth = class_3532.method_15340((18 * fuel + 20 - 1) / 20, 0, 18);
        if (fuelWidth > 0) {
            guiGraphics.method_25302(BREWING_STAND_LOCATION, left + 60, top + 44, 176, 29, fuelWidth, 4);
        }

        int brewingTicks = this.field_2797.getBrewingTicks();
        if (brewingTicks > 0) {
            int progress = (int) (28.0F * (1.0F - (float) brewingTicks / 400.0F));
            if (progress > 0) {
                guiGraphics.method_25302(BREWING_STAND_LOCATION, left + 97, top + 16, 176, 0, 9, progress);
            }

            progress = BUBBLE_LENGTHS[brewingTicks / 2 % 7];
            if (progress > 0) {
                guiGraphics.method_25302(BREWING_STAND_LOCATION, left + 63, top + 14 + 29 - progress, 185, 29 - progress, 12, progress);
            }
        }
    }
}
