package github.com.gengyoubo.util;

import java.util.Arrays;
import java.util.Objects;
import net.minecraft.class_124;

public enum MPText {
    manaita_infinity(80.0D,
            class_124.field_1061, class_124.field_1065, class_124.field_1054, class_124.field_1060,
            class_124.field_1075, class_124.field_1078, class_124.field_1076),
    manaita_mode(120.0D,
            class_124.field_1054, class_124.field_1054, class_124.field_1054, class_124.field_1054, class_124.field_1054,
            class_124.field_1054, class_124.field_1065, class_124.field_1061, class_124.field_1054, class_124.field_1054, class_124.field_1054,
            class_124.field_1054, class_124.field_1054, class_124.field_1054, class_124.field_1065, class_124.field_1061),
    manaita_enchantment(120.0D,
            class_124.field_1076, class_124.field_1076, class_124.field_1076, class_124.field_1076,
            class_124.field_1078, class_124.field_1064, class_124.field_1076, class_124.field_1076,
            class_124.field_1076, class_124.field_1076, class_124.field_1075, class_124.field_1064);

    private final String[] chatFormattings;
    private final double delay;

    MPText(double delay,class_124... chatFormattings) {
        this.chatFormattings = Arrays.stream(chatFormattings).map(class_124::toString).toArray(String[]::new);
        if (delay <= 0.0D)
            delay = 0.001D;
        this.delay = delay;
    }

    public String formatting(String input) {
        String stripFormatting = class_124.method_539(input);
        String[] colours = this.chatFormattings;
        StringBuilder sb = null;
        if (stripFormatting != null) {
            sb = new StringBuilder(stripFormatting.length() * 3);
        }
        int offset = (int)Math.floor((System.currentTimeMillis() & 0x3FFFL) / delay) % colours.length;
        for (int i = 0; i < Objects.requireNonNull(stripFormatting).length(); i++) {
            char c = stripFormatting.charAt(i);
            int col = (i + colours.length - offset) % colours.length;
            Objects.requireNonNull(sb).append(colours[col]);
            sb.append(c);
        }
        return Objects.requireNonNull(sb).toString();
    }
}

