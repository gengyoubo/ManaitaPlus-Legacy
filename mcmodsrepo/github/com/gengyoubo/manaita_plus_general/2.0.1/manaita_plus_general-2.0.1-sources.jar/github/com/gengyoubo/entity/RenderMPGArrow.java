package github.com.gengyoubo.entity;

import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_876;
import org.jetbrains.annotations.NotNull;

public class RenderMPGArrow extends class_876<MPGEntityArrow> {
    private static final class_2960 NORMAL_ARROW_LOCATION = new class_2960("textures/entity/projectiles/arrow.png");

    public RenderMPGArrow(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public @NotNull class_2960 getTextureLocation(@NotNull MPGEntityArrow arrow) {
        return NORMAL_ARROW_LOCATION;
    }
}
