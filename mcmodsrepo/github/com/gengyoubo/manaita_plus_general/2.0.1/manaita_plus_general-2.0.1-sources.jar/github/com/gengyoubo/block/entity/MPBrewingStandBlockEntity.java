package github.com.gengyoubo.block.entity;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1278;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2624;
import net.minecraft.class_2680;
import net.minecraft.class_3913;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;
import github.com.gengyoubo.MPGConfig;
import github.com.gengyoubo.block.MPBrewingStandBlock;
import github.com.gengyoubo.menu.MPBrewingStandMenu;
import github.com.gengyoubo.core.MPBlockEntityCore;

import java.util.Arrays;

public class MPBrewingStandBlockEntity extends class_2624 implements class_1278, ExtendedScreenHandlerFactory {
    private static final int[] SLOTS_FOR_UP = new int[]{3};
    private static final int[] SLOTS_FOR_DOWN = new int[]{0, 1, 2, 3};
    private static final int[] SLOTS_FOR_SIDES = new int[]{0, 1, 2, 4};
    private class_2371<class_1799> items = class_2371.method_10213(5, class_1799.field_8037);
    int brewTime;
    private boolean[] lastPotionCount;
    int fuel;
    protected final class_3913 dataAccess = new class_3913() {
        public int method_17390(int p_59038_) {
            return switch (p_59038_) {
                case 0 -> MPBrewingStandBlockEntity.this.brewTime;
                case 1 -> MPBrewingStandBlockEntity.this.fuel;
                default -> 0;
            };
        }

        public void method_17391(int p_59040_, int p_59041_) {
            switch (p_59040_) {
                case 0:
                    MPBrewingStandBlockEntity.this.brewTime = p_59041_;
                    break;
                case 1:
                    MPBrewingStandBlockEntity.this.fuel = p_59041_;
            }

        }

        public int method_17389() {
            return 2;
        }
    };

    public MPBrewingStandBlockEntity(class_2338 p_155283_, class_2680 p_155284_) {
        super(MPBlockEntityCore.BREWING_BLOCK_ENTITY.get(), p_155283_, p_155284_);
    }

    protected @NotNull class_2561 method_17823() {
        return class_2561.method_43471("container.brewing_manaita");
    }

    public int method_5439() {
        return this.items.size();
    }

    public boolean method_5442() {
        for(class_1799 itemstack : this.items) {
            if (!itemstack.method_7960()) {
                return false;
            }
        }

        return true;
    }

    public static void serverTick(class_1937 p_155286_, class_2338 p_155287_, class_2680 p_155288_, MPBrewingStandBlockEntity p_155289_) {
        if (isBrewable(p_155289_.items)) {
            doBrew(p_155286_, p_155287_, p_155289_.items);
            method_31663(p_155286_, p_155287_, p_155288_);
        }

        boolean[] aboolean = p_155289_.getPotionBits();
        if (!Arrays.equals(aboolean, p_155289_.lastPotionCount)) {
            p_155289_.lastPotionCount = aboolean;
            class_2680 blockstate = p_155288_;
            if (!(p_155288_.method_26204() instanceof MPBrewingStandBlock)) {
                return;
            }

            for (int i = 0; i < MPBrewingStandBlock.HAS_BOTTLE.length; ++i) {
                blockstate = blockstate.method_11657(MPBrewingStandBlock.HAS_BOTTLE[i], aboolean[i]);
            }

            p_155286_.method_8652(p_155287_, blockstate, 2);
        }
    }

    private boolean[] getPotionBits() {
        boolean[] aboolean = new boolean[3];

        for(int i = 0; i < 3; ++i) {
            if (!this.items.get(i).method_7960()) {
                aboolean[i] = true;
            }
        }

        return aboolean;
    }

    private static boolean isBrewable(class_2371<class_1799> p_155295_) {
        class_1799 itemstack = p_155295_.get(3);
        return !itemstack.method_7960()
                && (!p_155295_.get(0).method_7960() || !p_155295_.get(1).method_7960() || !p_155295_.get(2).method_7960());
    }

    private static void doBrew(class_1937 p_155291_, class_2338 p_155292_, class_2371<class_1799> p_155293_) {
        class_1799 itemstack = p_155293_.get(3);
        for (int slotsForSide : SLOTS_FOR_SIDES) {
            class_1799 itemStack = p_155293_.get(slotsForSide);
            if (!itemStack.method_7960()) {
                itemStack.method_7939(itemStack.method_7947() * MPGConfig.brewing_doubling_value);
            }
        }
        MPGBrewingLogicHelper.finishBrew(p_155291_, p_155292_.method_10263(), p_155292_.method_10264(), p_155292_.method_10260(), p_155293_, 3);
        p_155291_.method_20290(1035, p_155292_, 0);
    }

    public void method_11014(@NotNull class_2487 p_155297_) {
        super.method_11014(p_155297_);
        this.items = class_2371.method_10213(this.method_5439(), class_1799.field_8037);
        class_1262.method_5429(p_155297_, this.items);
    }

    protected void method_11007(@NotNull class_2487 p_187484_) {
        super.method_11007(p_187484_);
        class_1262.method_5426(p_187484_, this.items);
    }

    public @NotNull class_1799 method_5438(int p_58985_) {
        return p_58985_ >= 0 && p_58985_ < this.items.size() ? this.items.get(p_58985_) : class_1799.field_8037;
    }

    public @NotNull class_1799 method_5434(int p_58987_, int p_58988_) {
        return class_1262.method_5430(this.items, p_58987_, p_58988_);
    }

    public @NotNull class_1799 method_5441(int p_59015_) {
        return class_1262.method_5428(this.items, p_59015_);
    }

    public void method_5447(int p_58993_, @NotNull class_1799 p_58994_) {
        if (p_58993_ >= 0 && p_58993_ < this.items.size()) {
            this.items.set(p_58993_, p_58994_);
        }

    }

    public boolean method_5443(@NotNull class_1657 p_59000_) {
        return class_1263.method_49105(this, p_59000_);
    }

    public boolean method_5437(int p_59017_, @NotNull class_1799 p_59018_) {
        return MPGBrewingLogicHelper.canPlaceItem(p_59017_, p_59018_, this.method_5438(p_59017_));
    }

    public int @NotNull [] method_5494(@NotNull class_2350 p_59010_) {
        if (p_59010_ == class_2350.field_11036) {
            return SLOTS_FOR_UP;
        } else {
            return p_59010_ == class_2350.field_11033 ? SLOTS_FOR_DOWN : SLOTS_FOR_SIDES;
        }
    }

    public boolean method_5492(int p_58996_, @NotNull class_1799 p_58997_, @Nullable class_2350 p_58998_) {
        return this.method_5437(p_58996_, p_58997_);
    }

    public boolean method_5493(int p_59020_, @NotNull class_1799 p_59021_, @NotNull class_2350 p_59022_) {
        return p_59020_ != 3 || p_59021_.method_31574(class_1802.field_8469);
    }

    public void method_5448() {
        this.items.clear();
    }

    protected @NotNull class_1703 method_5465(int p_58990_, @NotNull class_1661 p_58991_) {
        return new MPBrewingStandMenu(p_58990_, p_58991_, this, this.dataAccess);
    }

    @Override
    public void writeScreenOpeningData(net.minecraft.class_3222 player, class_2540 buf) {
        buf.method_10807(this.field_11867);
    }

}


