package github.com.gengyoubo.item.data;

import github.com.gengyoubo.util.MPNBTData;
import net.minecraft.class_1799;

public interface IMPDoubling {
    default boolean isDoubling(class_1799 itemStack) {
        if (!itemStack.method_7985()) return false;
        if (itemStack.method_7969() != null) {
            return itemStack.method_7969().method_10577(MPNBTData.Doubling);
        }
        return false;
    }

    default void setDoubling(class_1799 itemStack, boolean doubling) {
        itemStack.method_7948().method_10556(MPNBTData.Doubling, doubling);
    }

    default boolean toggleDoubling(class_1799 itemStack) {
        boolean doubling = !isDoubling(itemStack);
        setDoubling(itemStack, doubling);
        return doubling;
    }
}

