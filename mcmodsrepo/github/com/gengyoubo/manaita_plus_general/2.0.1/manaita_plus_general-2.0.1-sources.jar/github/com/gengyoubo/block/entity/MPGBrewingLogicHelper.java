package github.com.gengyoubo.block.entity;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2371;

public final class MPGBrewingLogicHelper {
    private MPGBrewingLogicHelper() {
    }

    public static void finishBrew(class_1937 level, double x, double y, double z, class_2371<class_1799> items, int ingredientSlot) {
        class_1799 ingredient = items.get(ingredientSlot);
        ingredient.method_7934(1);
        items.set(ingredientSlot, ingredient);
    }

    public static boolean canPlaceItem(int index, class_1799 stack, class_1799 currentSlotItem) {
        if (index == 3) {
            return !stack.method_7960();
        }
        if (index == 4) {
            return stack.method_31574(class_1802.field_8183);
        }
        return !stack.method_7960() && currentSlotItem.method_7960();
    }
}
