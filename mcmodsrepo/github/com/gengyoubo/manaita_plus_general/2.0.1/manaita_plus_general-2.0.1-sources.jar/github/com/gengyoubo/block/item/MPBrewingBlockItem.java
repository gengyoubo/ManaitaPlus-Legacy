package github.com.gengyoubo.block.item;

import github.com.gengyoubo.block.MPBrewingStandBlock;

import static github.com.gengyoubo.core.MPBlockCore.BrewingBlock;

public class MPBrewingBlockItem extends MPTypedBlockItem {
    public MPBrewingBlockItem() {
        super(BrewingBlock.get(), new class_1793().method_24359(), "block.brewing.", MPBrewingStandBlock.class);
    }
}

