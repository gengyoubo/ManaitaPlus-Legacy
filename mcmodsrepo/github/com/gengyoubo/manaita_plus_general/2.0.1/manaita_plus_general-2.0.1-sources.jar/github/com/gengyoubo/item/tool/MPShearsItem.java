package github.com.gengyoubo.item.tool;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import github.com.gengyoubo.item.data.IMPDestroy;
import github.com.gengyoubo.item.data.IMPDoubling;
import github.com.gengyoubo.item.data.IMPKey;
import github.com.gengyoubo.item.tool.base.MPToolActionHelper;
import github.com.gengyoubo.util.MPNBTData;
import github.com.gengyoubo.util.MPText;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1820;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3481;

public class MPShearsItem extends class_1820 implements IMPKey, IMPDestroy, IMPDoubling {
    public MPShearsItem() {
        super(new class_1793().method_7889(1).method_7895(-1).method_24359());
    }

    @Override
    public float method_7865(@NotNull class_1799 stack, class_2680 state) {
        if (!state.method_27852(class_2246.field_10343) && !state.method_26164(class_3481.field_15503) && !state.method_27852(class_2246.field_10597) && !state.method_27852(class_2246.field_28411) && !state.method_26164(class_3481.field_15481)) {
            return super.method_7865(stack, state);
        }
        return Float.MAX_VALUE;
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        class_1937 level = context.method_8045();
        class_2338 blockPos = context.method_8037();
        class_2680 blockState = level.method_8320(blockPos);
        if (MPToolActionHelper.applyGrowPlantAction(context, blockPos, blockState)) {
            return class_1269.method_29236(level.field_9236);
        }
        return super.method_7884(context);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(@NotNull class_1937 level, class_1657 player, @NotNull class_1268 hand) {
        class_1799 itemInHand = player.method_5998(hand);
        MPToolActionHelper.handleRangeOrEnchantmentUse(level, player, itemInHand, (getRange(itemInHand) + 2) % 21, range -> setRange(itemInHand, range, player));
        return class_1271.method_22430(itemInHand);
    }

    @Override
    public int getRange(class_1799 itemStack) {
        if (itemStack.method_7969() == null) {
            itemStack.method_7980(new class_2487());
        }
        int range = itemStack.method_7969().method_10550(MPNBTData.Range);
        if (range == 0) {
            itemStack.method_7969().method_10569(MPNBTData.Range, 1);
            return 1;
        }
        return range;
    }

    public void setRange(class_1799 itemStack, int range, class_1657 player) {
        if (range == 0) {
            range = 1;
        }
        itemStack.method_7948().method_10569(MPNBTData.Range, range);
        if (player != null) {
            player.method_7353(class_2561.method_43470(MPText.manaita_mode.formatting("[" + class_2561.method_43471("item.manaita_plus_general.manaita_shears").getString() + "] " + class_2561.method_43471("mode.range.name").getString() + ": " + range + "x" + range + "x" + range)), true);
        }
    }

    @Override
    public void method_7851(@NotNull class_1799 stack, @Nullable class_1937 level, @NotNull List<class_2561> tooltip, @NotNull class_1836 flag) {
        super.method_7851(stack, level, tooltip, flag);
        MPToolActionHelper.appendRangeAndDoublingTooltip(tooltip, getRange(stack), isDoubling(stack));
    }

    @Override
    public void onManaitaKeyPress(class_1799 itemStack) {
        toggleDoubling(itemStack);
    }

    @Override
    public void onManaitaKeyPressOnClient(class_1799 itemStack, class_1657 player) {
        boolean doubling = toggleDoubling(itemStack);
        player.method_7353(class_2561.method_43470(MPText.manaita_mode.formatting(String.format("[%s] %s: %s", class_2561.method_43471("item.manaita_plus_general.manaita_shears").getString(), class_2561.method_43471("mode.doubling").getString(), (doubling ? class_2561.method_43471("info.on").getString() : class_2561.method_43471("info.off").getString())))), true);
    }

    @Override
    public boolean accept(class_2680 state) {
        return !state.method_26164(class_3481.field_33714);
    }
}

