package github.com.gengyoubo.item.portable;

import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1662;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_1874;
import net.minecraft.class_1937;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2609;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3956;
import net.minecraft.class_5455;
import net.minecraft.world.*;
import org.jetbrains.annotations.NotNull;
import github.com.gengyoubo.MPGConfig;
import github.com.gengyoubo.block.entity.MPGFurnaceLogicHelper;
import github.com.gengyoubo.core.MPBlockEntityCore;
import github.com.gengyoubo.core.MPBlockCore;
import github.com.gengyoubo.menu.MPFurnaceMenu;

import org.jetbrains.annotations.Nullable;

public class MPFurnacePortable extends MPGPortableItem {
    public MPFurnacePortable() {
        super("item.portableFurnace.");
    }

    @Override
    protected void openPortableMenu(class_3222 serverPlayer, class_1799 itemInHand, class_1937 level) {
        openPortableScreen(serverPlayer, itemInHand, level, "container.furnace_manaita",
                (containerId, inventory, player, heldStack, world) -> {
                    MPFurnaceBlockEntity block = new MPFurnaceBlockEntity(player, heldStack);
                    return block.createMenu(containerId, inventory, player);
                });
    }


    public static class MPFurnaceBlockEntity extends class_2609 {
        private final Object2IntOpenHashMap<class_2960> recipesUsed = new Object2IntOpenHashMap<>();
        private final class_1863.class_7266<class_1263, ? extends class_1874> quickCheck;
        private final class_1657 player;
        private final class_1799 stack;
        protected final class_2371<class_1799> items = class_2371.method_10213(3, class_1799.field_8037);

        public MPFurnaceBlockEntity(class_1657 player,class_1799 stack) {
            super(MPBlockEntityCore.FURNACE_BLOCK_ENTITY.get(), player.method_24515(), MPBlockCore.FurnaceBlock.get().method_9564(), class_3956.field_17546);
            this.quickCheck = class_1863.method_42302(class_3956.field_17546);
            this.player = player;
            this.stack = stack;
            method_11014(stack.method_7948());
        }

        protected @NotNull class_2561 method_17823() {
            return class_2561.method_43471("container.furnace_manaita");
        }

        protected @NotNull class_1703 method_5465(int p_59293_, @NotNull class_1661 p_59294_) {
            return new MPFurnaceMenu(p_59293_, p_59294_, this, this.field_17374);
        }

        @Override
        public int method_5444() {
            return Integer.MAX_VALUE;
        }

        public void method_11014(@NotNull class_2487 p_155025_) {
            super.method_11014(p_155025_);
            class_1262.method_5429(p_155025_, this.field_11984);
            class_2487 compoundtag = p_155025_.method_10562("RecipesUsed");

            for(String s : compoundtag.method_10541()) {
                this.recipesUsed.put(new class_2960(s), compoundtag.method_10550(s));
            }

        }

        protected void method_11007(@NotNull class_2487 p_187452_) {
            class_1262.method_5426(p_187452_, this.field_11984);
            class_2487 compoundtag = new class_2487();
            this.recipesUsed.forEach((p_187449_, p_187450_) -> compoundtag.method_10569(p_187449_.toString(), p_187450_));
            p_187452_.method_10566("RecipesUsed", compoundtag);
        }



        private boolean canBurn(class_5455 registryAccess, @Nullable class_1860<?> recipe, class_2371<class_1799> items) {
            return MPGFurnaceLogicHelper.canBurn(registryAccess, recipe, items, this);
        }

        private boolean burn(class_5455 p_266740_, @Nullable class_1860<?> p_266780_, class_2371<class_1799> p_267073_) {
            if (p_266780_ != null && this.canBurn(p_266740_, p_266780_, p_267073_)) {
                class_1799 itemstack = p_267073_.get(0);
                class_1799 itemstack1 = MPGFurnaceLogicHelper.assembleResult(p_266780_, this, p_266740_);
                class_1799 itemstack2 = p_267073_.get(2);
                if (itemstack2.method_7960()) {
                    class_1799 copy = itemstack1.method_7972();
                    copy.method_7939(copy.method_7947() * MPGConfig.furnace_doubling_value);
                    p_267073_.set(2, copy);
                } else if (itemstack2.method_31574(itemstack1.method_7909())) {
                    itemstack2.method_7933(itemstack1.method_7947() * MPGConfig.furnace_doubling_value);
                }

                itemstack.method_7934(1);
                return true;
            } else {
                return false;
            }
        }

        protected int method_11200(@NotNull class_1799 p_58343_) {
            return 0;
        }



        public boolean method_5492(int p_58336_, @NotNull class_1799 p_58337_, @Nullable class_2350 p_58338_) {
            return this.method_5437(p_58336_, p_58337_);
        }

        public int method_5439() {
            return this.field_11984.size();
        }

        public boolean method_5442() {
            for(class_1799 itemstack : this.field_11984) {
                if (!itemstack.method_7960()) {
                    return false;
                }
            }

            return true;
        }

        public @NotNull class_1799 method_5438(int p_58328_) {
            return this.field_11984.get(p_58328_);
        }

        public @NotNull class_1799 method_5434(int p_58330_, int p_58331_) {
            return class_1262.method_5430(this.field_11984, p_58330_, p_58331_);
        }

        public @NotNull class_1799 method_5441(int p_58387_) {
            return class_1262.method_5428(this.field_11984, p_58387_);
        }

        public void method_5447(int p_58333_, @NotNull class_1799 p_58334_) {
            this.field_11984.set(p_58333_, p_58334_);
            if (!this.field_11984.get(0).method_7960()) {
                class_1937 level = player.method_37908();
                class_1860<?> recipe = this.quickCheck.method_42303(this, level).orElse(null);
                while (this.canBurn(level.method_30349(), recipe, this.field_11984)) {
                    if (this.burn(level.method_30349(), recipe, this.field_11984)) {
                        this.method_7662(recipe);
                    }
                }
            }
//            save
            method_11007(stack.method_7948());
        }

        public boolean method_5443(@NotNull class_1657 p_58340_) {
            return true;
        }

        public boolean method_5437(int p_58389_, @NotNull class_1799 p_58390_) {
            return p_58389_ != 2;
        }

        public void method_5448() {
            this.field_11984.clear();
        }

        public void method_7662(@Nullable class_1860<?> p_58345_) {
            if (p_58345_ != null) {
                class_2960 resourcelocation = p_58345_.method_8114();
                this.recipesUsed.addTo(resourcelocation, 1);
            }
        }

        public void method_17763(@NotNull class_3222 p_155004_) {
            MPGFurnaceLogicHelper.awardUsedRecipesAndPopExperience(p_155004_, this.field_11984, this.recipesUsed);
        }

        public @NotNull java.util.List<class_1860<?>> method_27354(@NotNull class_3218 p_154996_, @NotNull class_243 p_154997_) {
            return MPGFurnaceLogicHelper.getRecipesToAwardAndPopExperience(p_154996_, p_154997_, this.recipesUsed);
        }

        public void method_7683(@NotNull class_1662 p_58342_) {
            for(class_1799 itemstack : this.field_11984) {
                p_58342_.method_7400(itemstack);
            }

        }
    }
}




