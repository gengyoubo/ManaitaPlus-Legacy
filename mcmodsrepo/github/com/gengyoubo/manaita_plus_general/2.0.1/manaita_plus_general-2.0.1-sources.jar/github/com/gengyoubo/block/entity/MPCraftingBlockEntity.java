package github.com.gengyoubo.block.entity;

import github.com.gengyoubo.core.MPBlockEntityCore;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class MPCraftingBlockEntity extends class_2586 {
    public MPCraftingBlockEntity(class_2338 p_155545_, class_2680 p_155546_) {
        super(MPBlockEntityCore.CRAFTING_BLOCK_ENTITY.get(), p_155545_, p_155546_);
    }
}
