package github.com.gengyoubo.block.item;

import org.jetbrains.annotations.NotNull;
import github.com.gengyoubo.core.MPBlockCore;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;

public class MPCraftingBlockItem extends class_1747 {
    public MPCraftingBlockItem() {
        super(MPBlockCore.CraftingBlock.get(), new class_1792.class_1793().method_24359());
    }

    @Override
    public @NotNull class_2561 method_7864(@NotNull class_1799 stack) {
        return class_2561.method_43471("block.crafting.name");
    }
}

