package github.com.gengyoubo.gui;

import github.com.gengyoubo.MPGConfig;
import github.com.gengyoubo.menu.MPFurnaceMenu;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3876;
import net.minecraft.class_489;

public class MPFurnaceScreen extends class_489<MPFurnaceMenu> {
    private static final class_2960 TEXTURE = new class_2960("textures/gui/container/furnace.png");
    private final String doublingText;

    public MPFurnaceScreen(MPFurnaceMenu menu, class_1661 inventory, class_2561 title) {
        super(menu, new class_3876(), inventory, title, TEXTURE);
        doublingText = MPGConfig.furnace_doubling_value + "x";
    }

    @Override
    protected void method_2388(class_332 guiGraphics, int mouseX, int mouseY) {
        guiGraphics.method_51439(this.field_22793, this.field_22785, this.field_25267, this.field_25268, 4210752, false);
        guiGraphics.method_51439(this.field_22793, this.field_29347, this.field_25269, this.field_25270, 4210752, false);
        guiGraphics.method_51433(this.field_22793, doublingText, 118, 22, 4210752, false);
    }
}
