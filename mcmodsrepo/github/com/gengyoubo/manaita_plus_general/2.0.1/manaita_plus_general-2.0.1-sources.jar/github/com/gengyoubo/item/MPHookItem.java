package github.com.gengyoubo.item;

import net.minecraft.class_1792;

public class MPHookItem extends class_1792 {
    public MPHookItem() {
        super(new class_1792.class_1793().method_24359());
    }
}

