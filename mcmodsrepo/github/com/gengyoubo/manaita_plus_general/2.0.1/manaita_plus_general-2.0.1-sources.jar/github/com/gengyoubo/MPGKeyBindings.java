package github.com.gengyoubo;

import github.com.gengyoubo.core.MPKeyBoardCore;
import github.com.gengyoubo.item.data.IMPKey;
import github.com.gengyoubo.network.MPNetworking;
import github.com.gengyoubo.network.client.MPKeyPressPacket;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import org.lwjgl.glfw.GLFW;

public final class MPGKeyBindings {
    private MPGKeyBindings() {
    }

    public static void init() {
        MPKeyBoardCore.MESSAGE_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.manaita",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_X,
                "key.categories.misc"
        ));
        MPKeyBoardCore.MESSAGE_ARMOR_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.manaita.armor",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_Y,
                "key.categories.misc"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(MPGKeyBindings::onClientTick);
    }

    private static void onClientTick(class_310 client) {
        if (client.field_1724 == null) {
            return;
        }

        while (MPKeyBoardCore.MESSAGE_KEY.method_1436()) {
            class_1799 mainHandItem = client.field_1724.method_6047();
            if (!mainHandItem.method_7960() && mainHandItem.method_7909() instanceof IMPKey keyItem) {
                keyItem.onManaitaKeyPressOnClient(mainHandItem, client.field_1724);
            }
            sendKeyPacket((byte) 0);
        }

        while (MPKeyBoardCore.MESSAGE_ARMOR_KEY.method_1436()) {
            for (class_1799 itemStack : client.field_1724.method_31548().field_7548) {
                if (!itemStack.method_7960() && itemStack.method_7909() instanceof IMPKey keyItem) {
                    keyItem.onManaitaKeyPressOnClient(itemStack, client.field_1724);
                }
            }
            sendKeyPacket((byte) 1);
        }
    }

    private static void sendKeyPacket(byte keyCode) {
        MPKeyPressPacket packet = new MPKeyPressPacket(keyCode);
        var buf = MPNetworking.createBuf();
        packet.write(buf);
        ClientPlayNetworking.send(MPNetworking.KEY_PRESS, buf);
    }
}
