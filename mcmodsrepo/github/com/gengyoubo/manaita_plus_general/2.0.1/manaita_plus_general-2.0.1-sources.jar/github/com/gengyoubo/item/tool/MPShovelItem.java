package github.com.gengyoubo.item.tool;

import org.jetbrains.annotations.NotNull;
import github.com.gengyoubo.item.tool.base.MPTaggedToolItem;
import github.com.gengyoubo.item.tool.base.MPToolActionHelper;
import net.minecraft.class_1269;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3481;

public class MPShovelItem extends MPTaggedToolItem {
    public MPShovelItem() {
        super(class_3481.field_33716);
    }
    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        class_1937 level = context.method_8045();
        class_2338 blockPos = context.method_8037();
        class_2680 blockState = level.method_8320(blockPos);
        if (MPToolActionHelper.applyShovelAction(context, blockPos, blockState)) {
            return class_1269.method_29236(level.field_9236);
        }
        return class_1269.field_5811;
    }
}
