package github.com.gengyoubo.jei;

import github.com.gengyoubo.core.MPItemCore;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.jetbrains.annotations.NotNull;

public class MPSourceCopyRecipeCategory implements IRecipeCategory<MPSourceCopyJeiRecipe> {
    public static final RecipeType<MPSourceCopyJeiRecipe> TYPE =
            RecipeType.create("manaita_plus_general", "source_copying", MPSourceCopyJeiRecipe.class);

    private final IDrawable background;
    private final IDrawable icon;
    private final IDrawable arrow;

    public MPSourceCopyRecipeCategory(IGuiHelper guiHelper) {
        this.background = guiHelper.createBlankDrawable(118, 54);
        this.icon = guiHelper.createDrawableItemStack(new class_1799(MPItemCore.ManaitaSource.get()));
        this.arrow = guiHelper.getRecipeArrow();
    }

    @Override
    public @NotNull RecipeType<MPSourceCopyJeiRecipe> getRecipeType() {
        return TYPE;
    }

    @Override
    public @NotNull class_2561 getTitle() {
        return class_2561.method_43471("jei.manaita_plus_general.source_copying");
    }

    @Override
    @SuppressWarnings("removal")
    public IDrawable getBackground() {
        return background;
    }

    @Override
    public @NotNull IDrawable getIcon() {
        return icon;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, MPSourceCopyJeiRecipe recipe, @NotNull IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 8, 18)
                .addItemStack(new class_1799(MPItemCore.ManaitaSource.get()))
                .setStandardSlotBackground();
        builder.addSlot(RecipeIngredientRole.INPUT, 32, 18)
                .addItemStack(recipe.input())
                .setStandardSlotBackground();
        builder.addSlot(RecipeIngredientRole.OUTPUT, 86, 18)
                .addItemStack(recipe.output())
                .setOutputSlotBackground();
    }

    @Override
    public void draw(MPSourceCopyJeiRecipe recipe, @NotNull mezz.jei.api.gui.ingredient.IRecipeSlotsView recipeSlotsView, class_332 guiGraphics, double mouseX, double mouseY) {
        arrow.draw(guiGraphics, 56, 19);
        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1724 == null) {
            return;
        }
        guiGraphics.method_51439(minecraft.field_1772, class_2561.method_43469("jei.manaita_plus_general.source_copying.source_result", recipe.sourceResultCount()), 86, 2, 0x404040, false);
    }

    @Override
    public class_2960 getRegistryName(MPSourceCopyJeiRecipe recipe) {
        return recipe.input().method_41409().method_40230().orElseThrow().method_29177();
    }
}
