package github.com.gengyoubo.network;

import github.com.gengyoubo.item.data.IMPDestroy;
import github.com.gengyoubo.network.server.MPChangeEntityDataPacket;
import github.com.gengyoubo.network.server.MPDestroyBlockPacket;
import github.com.gengyoubo.util.MPEntityData;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3419;
import net.minecraft.class_638;

public final class MPClientPacketHandlers {
    private MPClientPacketHandlers() {
    }

    public static void handleDestroyBlock(MPDestroyBlockPacket packet) {
        class_310 mc = class_310.method_1551();
        class_638 level = mc.field_1687;
        if (level == null || mc.field_1724 == null) {
            return;
        }
        if (!(packet.getItem() instanceof IMPDestroy destroyItem)) {
            return;
        }

        class_2338 blockPos = packet.getBlockPos();
        int range = packet.getRange();
        class_2338.class_2339 mutableBlockPos = new class_2338.class_2339();
        for (int x = blockPos.method_10263() - range; x <= blockPos.method_10263() + range; x++) {
            for (int y = blockPos.method_10264() - range; y <= blockPos.method_10264() + range; y++) {
                for (int z = blockPos.method_10260() - range; z <= blockPos.method_10260() + range; z++) {
                    mutableBlockPos.method_10103(x, y, z);
                    class_2680 blockState = level.method_8320(mutableBlockPos);
                    if (destroyItem.accept(blockState)) {
                        continue;
                    }

                    level.method_8652(mutableBlockPos, level.method_8316(mutableBlockPos).method_15759(), 10);
                    class_2498 soundType = blockState.method_26231();
                    mc.method_1483().method_4873(new class_1109(soundType.method_10596(), class_3419.field_15245,
                            (soundType.method_10597() + 1.0F) / 8.0F, soundType.method_10599() * 0.5F,
                            class_1113.method_43221(), mutableBlockPos));
                }
            }
        }
    }

    public static void handleChangeEntityData(MPChangeEntityDataPacket packet) {
        class_638 level = class_310.method_1551().field_1687;
        if (level == null) {
            return;
        }
        class_1297 entity = level.method_8469(packet.getId());
        if (entity == null) {
            return;
        }

        boolean remove = packet.getFlag() < 0;
        int flags = remove ? -packet.getFlag() : packet.getFlag();
        for (MPEntityData entityData : MPEntityData.values()) {
            if ((entityData.getFlag() & flags) != 0) {
                if (remove) {
                    entityData.remove(entity);
                } else {
                    entityData.add(entity);
                }
            }
        }
    }
}
