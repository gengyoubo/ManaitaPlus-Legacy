package github.com.gengyoubo.block;

import com.google.common.collect.Lists;
import org.jetbrains.annotations.NotNull;
import github.com.gengyoubo.block.data.MPBlockData;
import github.com.gengyoubo.util.MPNBTData;

import java.util.List;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3726;

@SuppressWarnings("deprecation")
public class MPHookBlock extends class_2248 {
    public MPHookBlock() {
        super(class_2251.method_9637().method_22488());
        this.method_9590(this.field_10647.method_11664().method_11657(MPBlockData.FACING, class_2350.field_11043).method_11657(MPBlockData.TYPES,0));
    }

    @Override
    public @NotNull class_265 method_9530(class_2680 p_60555_, @NotNull class_1922 p_60556_, @NotNull class_2338 p_60557_, @NotNull class_3726 p_60558_) {
        class_2350 direction = p_60555_.method_11654(MPBlockData.FACING);
        return direction == class_2350.field_11034 ? MPBlockData.shapeE : direction == class_2350.field_11035 ? MPBlockData.shapeS : direction == class_2350.field_11043 ? MPBlockData.shapeN : MPBlockData.shapeW;
    }

    @Override
    public @NotNull List<class_1799> method_9560(class_2680 p_287732_, class_8567.@NotNull class_8568 p_287596_) {
        class_1799 itemStack = new class_1799(p_287732_.method_26204());
        itemStack.method_7980(new class_2487());
        int type = p_287732_.method_11654(MPBlockData.TYPES);
        if (itemStack.method_7969() != null) {
            itemStack.method_7969().method_10569(MPNBTData.ItemType,type);
        }
        return Lists.newArrayList(itemStack);
    }


    public class_2680 method_9605(class_1750 p_48689_) {
        return this.method_9564().method_11657(MPBlockData.FACING, p_48689_.method_8038());
    }

    public @NotNull class_2464 method_9604(@NotNull class_2680 p_48727_) {
        return class_2464.field_11458;
    }

    public @NotNull class_2680 method_9598(class_2680 p_48722_, class_2470 p_48723_) {
        return p_48722_.method_11657(MPBlockData.FACING, p_48723_.method_10503(p_48722_.method_11654(MPBlockData.FACING)));
    }

    public @NotNull class_2680 method_9569(class_2680 p_48719_, class_2415 p_48720_) {
        return p_48719_.method_26186(p_48720_.method_10345(p_48719_.method_11654(MPBlockData.FACING)));
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> p_48725_) {
        p_48725_.method_11667(MPBlockData.FACING, MPBlockData.TYPES);
    }
}

