package github.com.gengyoubo.item.tool.base;

import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_6862;
import org.jetbrains.annotations.NotNull;

public abstract class MPTaggedToolItem extends MPToolBase {
    private final class_6862<class_2248> mineableTag;

    protected MPTaggedToolItem(class_6862<class_2248> mineableTag) {
        super(mineableTag);
        this.mineableTag = mineableTag;
    }

    public boolean isCorrectToolForDrops(@NotNull class_1799 stack, class_2680 state) {
        return state.method_26164(mineableTag);
    }

    public boolean accept(class_2680 state) {
        return !state.method_26164(mineableTag);
    }
}
