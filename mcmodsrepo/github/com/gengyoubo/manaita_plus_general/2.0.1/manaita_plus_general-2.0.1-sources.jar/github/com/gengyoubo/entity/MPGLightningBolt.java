package github.com.gengyoubo.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1538;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.jetbrains.annotations.NotNull;

public class MPGLightningBolt extends class_1538 {
    public MPGLightningBolt(class_1299<? extends class_1538> entityType, class_1937 level) {
        super(entityType, level);
        this.field_5985 = true;
    }

    @Override
    public void method_5773() {
        if (this.field_6012 == 0 && this.method_37908().method_8608()) {
            this.method_37908().method_8486(this.method_23317(), this.method_23318(), this.method_23321(), class_3417.field_14865, class_3419.field_15252, 10000.0F, 0.8F + this.field_5974.method_43057() * 0.2F, false);
            this.method_37908().method_8486(this.method_23317(), this.method_23318(), this.method_23321(), class_3417.field_14956, class_3419.field_15252, 2.0F, 0.5F + this.field_5974.method_43057() * 0.2F, false);
        }
        super.method_5773();
        if (!(this.method_37908() instanceof class_3218) && !this.method_31481()) {
            this.method_37908().method_8509(2);
        }
    }

    @Override
    protected void method_5749(@NotNull class_2487 tag) {
        super.method_5749(tag);
    }

    @Override
    protected void method_5652(@NotNull class_2487 tag) {
        super.method_5652(tag);
    }
}
