package github.com.gengyoubo.item.tier;

import org.jetbrains.annotations.NotNull;
import github.com.gengyoubo.core.MPBlockCore;
import net.minecraft.class_1832;
import net.minecraft.class_1856;

public class MPToolTier implements class_1832 {
    @Override
    public int method_8025() {
        return -1;
    }

    @Override
    public float method_8027() {
        return Float.POSITIVE_INFINITY;
    }

    @Override
    public float method_8028() {
        return Float.POSITIVE_INFINITY;
    }

    @Override
    public int method_8024() {
        return Integer.MAX_VALUE;
    }

    @Override
    public int method_8026() {
        return 0;
    }

    @Override
    public @NotNull class_1856 method_8023() {
        return class_1856.method_8091(MPBlockCore.CraftingBlockItem.get(), MPBlockCore.FurnaceBlockItem.get(), MPBlockCore.BrewingBlockItem.get());
    }

}
