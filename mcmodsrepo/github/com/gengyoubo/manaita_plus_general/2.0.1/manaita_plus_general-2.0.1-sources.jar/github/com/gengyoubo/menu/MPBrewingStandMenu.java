package github.com.gengyoubo.menu;

import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_174;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import net.minecraft.class_3919;
import net.minecraft.world.inventory.*;
import org.jetbrains.annotations.NotNull;
import github.com.gengyoubo.core.MPMenuCore;

public class MPBrewingStandMenu extends class_1703 {
    private final class_1263 brewingStand;
    private final class_3913 brewingStandData;
    private final class_1735 ingredientSlot;

    @SuppressWarnings("unused")
    public MPBrewingStandMenu(int id, class_1661 inv, class_2540 extraData) {
        this(id, inv, new class_1277(5), new class_3919(2));
    }

    public MPBrewingStandMenu(int p_39093_, class_1661 p_39094_, class_1263 p_39095_, class_3913 p_39096_) {
        super(MPMenuCore.BrewingStandManaita.get(), p_39093_);
        method_17359(p_39095_, 5);
        method_17361(p_39096_, 2);
        this.brewingStand = p_39095_;
        this.brewingStandData = p_39096_;
        this.method_7621(new PotionSlot(p_39095_, 0, 56, 51));
        this.method_7621(new PotionSlot(p_39095_, 1, 79, 58));
        this.method_7621(new PotionSlot(p_39095_, 2, 102, 51));
        this.ingredientSlot = this.method_7621(new IngredientsSlot(p_39095_, 3, 79, 17));
        this.method_7621(new FuelSlot(p_39095_, 4, 17, 17));
        this.method_17360(p_39096_);

        for(int i = 0; i < 3; ++i) {
            for(int j = 0; j < 9; ++j) {
                this.method_7621(new class_1735(p_39094_, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }

        for(int k = 0; k < 9; ++k) {
            this.method_7621(new class_1735(p_39094_, k, 8 + k * 18, 142));
        }
    }

    public boolean method_7597(@NotNull class_1657 p_39098_) {
        return this.brewingStand.method_5443(p_39098_);
    }

    public @NotNull class_1799 method_7601(@NotNull class_1657 p_39100_, int p_39101_) {
        class_1799 itemstack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(p_39101_);
        if (slot.method_7681()) {
            class_1799 itemstack1 = slot.method_7677();
            itemstack = itemstack1.method_7972();
            if ((p_39101_ < 0 || p_39101_ > 2) && p_39101_ != 3 && p_39101_ != 4) {
                if (FuelSlot.mayPlaceItem(itemstack)) {
                    if (this.method_7616(itemstack1, 4, 5, false) || this.ingredientSlot.method_7680(itemstack1) && !this.method_7616(itemstack1, 3, 4, false)) {
                        return class_1799.field_8037;
                    }
                } else if (this.ingredientSlot.method_7680(itemstack1)) {
                    if (!this.method_7616(itemstack1, 3, 4, false)) {
                        return class_1799.field_8037;
                    }
                } else if (PotionSlot.mayPlaceItem(itemstack)) {
                    if (!this.method_7616(itemstack1, 0, 3, false)) {
                        return class_1799.field_8037;
                    }
                } else if (p_39101_ >= 5 && p_39101_ < 32) {
                    if (!this.method_7616(itemstack1, 32, 41, false)) {
                        return class_1799.field_8037;
                    }
                } else if (p_39101_ >= 32 && p_39101_ < 41) {
                    if (!this.method_7616(itemstack1, 5, 32, false)) {
                        return class_1799.field_8037;
                    }
                } else if (!this.method_7616(itemstack1, 5, 41, false)) {
                    return class_1799.field_8037;
                }
            } else {
                if (!this.method_7616(itemstack1, 5, 41, true)) {
                    return class_1799.field_8037;
                }

                slot.method_7670(itemstack1, itemstack);
            }

            if (itemstack1.method_7960()) {
                slot.method_48931(class_1799.field_8037);
            } else {
                slot.method_7668();
            }

            if (itemstack1.method_7947() == itemstack.method_7947()) {
                return class_1799.field_8037;
            }

            slot.method_7667(p_39100_, itemstack1);
        }

        return itemstack;
    }

    public int getFuel() {
        return this.brewingStandData.method_17390(1);
    }

    public int getBrewingTicks() {
        return this.brewingStandData.method_17390(0);
    }

    static class FuelSlot extends class_1735 {
        public FuelSlot(class_1263 p_39105_, int p_39106_, int p_39107_, int p_39108_) {
            super(p_39105_, p_39106_, p_39107_, p_39108_);
        }

        public boolean method_7680(@NotNull class_1799 p_39111_) {
            return mayPlaceItem(p_39111_);
        }

        public static boolean mayPlaceItem(class_1799 p_39113_) {
            return p_39113_.method_31574(class_1802.field_8183);
        }

        public int method_7675() {
            return 64;
        }
    }

    static class IngredientsSlot extends class_1735 {
        public IngredientsSlot(class_1263 p_39115_, int p_39116_, int p_39117_, int p_39118_) {
            super(p_39115_, p_39116_, p_39117_, p_39118_);
        }

        public boolean method_7680(@NotNull class_1799 p_39121_) {
            return !p_39121_.method_7960();
        }

        public int method_7675() {
            return 64;
        }
    }

    static class PotionSlot extends class_1735 {
        public PotionSlot(class_1263 p_39123_, int p_39124_, int p_39125_, int p_39126_) {
            super(p_39123_, p_39124_, p_39125_, p_39126_);
        }

        public boolean method_7680(@NotNull class_1799 p_39132_) {
            return mayPlaceItem(p_39132_);
        }

        public int method_7675() {
            return 1;
        }

        public void method_7667(@NotNull class_1657 p_150499_, @NotNull class_1799 p_150500_) {
            class_1842 potion = class_1844.method_8063(p_150500_);
            if (p_150499_ instanceof class_3222) {
                class_174.field_1213.method_8784((class_3222)p_150499_, potion);
            }

            super.method_7667(p_150499_, p_150500_);
        }

        public static boolean mayPlaceItem(class_1799 p_39134_) {
            return p_39134_.method_31574(class_1802.field_8574) || p_39134_.method_31574(class_1802.field_8436) || p_39134_.method_31574(class_1802.field_8150) || p_39134_.method_31574(class_1802.field_8469);
        }
    }
}

