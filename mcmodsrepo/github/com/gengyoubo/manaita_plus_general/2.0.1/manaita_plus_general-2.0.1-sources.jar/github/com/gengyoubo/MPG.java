package github.com.gengyoubo;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.resource.conditions.v1.ResourceConditions;
import net.minecraft.class_1299;
import net.minecraft.class_1320;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1865;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_7923;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import github.com.gengyoubo.core.*;
import github.com.gengyoubo.network.MPNetworking;
import github.com.gengyoubo.util.MPNBTData;

public class MPG implements ModInitializer {
    public static final String MODID = "manaita_plus_general";
    public static final Logger LOGGER = LoggerFactory.getLogger(MODID);
    public static final DeferredRegister<class_2248> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<net.minecraft.class_3917<?>> MENU_TYPES = DeferredRegister.create(ForgeRegistries.MENU_TYPES, MODID);
    public static final DeferredRegister<class_1320> ATTRIBUTE_TYPE = DeferredRegister.create(ForgeRegistries.ATTRIBUTES, MODID);
    public static final DeferredRegister<class_1865<?>> RECIPE_SERIALIZER_DEFERRED_REGISTER =  DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, MODID);
    public static final DeferredRegister<class_1299<?>> ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<class_2591<?>> BLOCK_ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MODID);
    public static final DeferredRegister<class_1792> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static class_1761 MANAITA_PLUS_TAB;

    @Override
    public void onInitialize() {
        initFabric();
    }

    public static void initFabric() {
        MPGConfig.load();

        // Force-load all registry holder classes before registration.
        MPBlockCore.init();
        MPItemCore.init();
        MPBlockEntityCore.init();
        MPMenuCore.init();
        MPAttributeCore.init();
        MPRecipeSerializerCore.init();
        MPSynchedDataCore.init();
        registerResourceConditions();
        MPNetworking.initServer();

        BLOCKS.registerAll();
        ITEMS.registerAll();
        ATTRIBUTE_TYPE.registerAll();
        ENTITY_TYPES.registerAll();
        MENU_TYPES.registerAll();
        BLOCK_ENTITY_TYPES.registerAll();
        RECIPE_SERIALIZER_DEFERRED_REGISTER.registerAll();

        MANAITA_PLUS_TAB = class_2378.method_10230(class_7923.field_44687, new class_2960(MODID, "manaita_plus_tab"), FabricItemGroup.builder()
            .method_47320(() -> MPBlockCore.CraftingBlockItem.get().method_7854())
            .method_47321(class_2561.method_43471("itemGroup.MPTab"))
            .method_47317((context, entries) -> {
                entries.method_45421(MPBlockCore.CraftingBlockItem.get());
                acceptMPGType(MPBlockCore.FurnaceBlockItem.get(), entries, 8);
                acceptMPGType(MPBlockCore.BrewingBlockItem.get(), entries, 8);
                acceptMPGType(MPBlockCore.HookBlockItem.get(), entries, 7);

                acceptMPGType(MPItemCore.ManaitaCraftingPortable.get(), entries, 8);
                acceptMPGType(MPItemCore.ManaitaFurnacePortable.get(), entries, 8);
                acceptMPGType(MPItemCore.ManaitaBrewingPortable.get(), entries, 8);

                entries.method_45421(MPItemCore.ManaitaSword.get());
                entries.method_45421(MPItemCore.ManaitaSwordGod.get());
                entries.method_45421(MPItemCore.ManaitaBow.get());
                entries.method_45421(MPItemCore.ManaitaAxe.get());
                entries.method_45421(MPItemCore.ManaitaHoe.get());
                entries.method_45421(MPItemCore.ManaitaPaxel.get());
                entries.method_45421(MPItemCore.ManaitaPickaxe.get());
                entries.method_45421(MPItemCore.ManaitaShears.get());
                entries.method_45421(MPItemCore.ManaitaShovel.get());
                entries.method_45421(MPItemCore.ManaitaHelmet.get());
                entries.method_45421(MPItemCore.ManaitaChestplate.get());
                entries.method_45421(MPItemCore.ManaitaLeggings.get());
                entries.method_45421(MPItemCore.ManaitaBoots.get());
                entries.method_45421(MPItemCore.ManaitaSource.get());
            }).method_47324());
    }

    private static void registerResourceConditions() {
        ResourceConditions.register(new class_2960(MODID, "easy_mode"), json ->
                class_3518.method_15258(json, "value", true) == MPGConfig.easy_mode_value);
    }

    private static void acceptMPGType(class_1792 item, class_1761.class_7704 entries, int maxType) {
        for (int type = 0; type <= maxType; type++) {
            class_1799 stack = new class_1799(item);
            stack.method_7948().method_10569(MPNBTData.ItemType, type);
            entries.method_45420(stack);
        }
    }
}
