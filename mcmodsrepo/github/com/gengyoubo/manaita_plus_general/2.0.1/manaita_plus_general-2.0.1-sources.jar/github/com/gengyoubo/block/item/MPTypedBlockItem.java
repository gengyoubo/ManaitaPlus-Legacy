package github.com.gengyoubo.block.item;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import github.com.gengyoubo.block.MPHookBlock;
import github.com.gengyoubo.block.data.MPBlockData;
import github.com.gengyoubo.util.MPNBTData;
import github.com.gengyoubo.util.MPTypeHelper;

import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_5712;

public abstract class MPTypedBlockItem extends class_1747 {
    private final String translationPrefix;
    private final Class<? extends class_2248> typedBlockClass;

    protected MPTypedBlockItem(class_2248 block, class_1793 properties, String translationPrefix, Class<? extends class_2248> typedBlockClass) {
        super(block, properties);
        this.translationPrefix = translationPrefix;
        this.typedBlockClass = typedBlockClass;
    }

    @Override
    public @NotNull class_2561 method_7864(class_1799 stack) {
        return class_2561.method_43471(
                translationPrefix + MPTypeHelper.getTypes(stack.method_7948().method_10550(MPNBTData.ItemType)) + "name");
    }

    @Override
    public void method_7851(@NotNull class_1799 stack, @Nullable class_1937 level, @NotNull List<class_2561> tooltip, @NotNull class_1836 flag) {
        super.method_7851(stack, level, tooltip, flag);
    }

    @Override
    public @NotNull class_1269 method_7712(class_1750 context) {
        if (!this.method_7711().method_45382(context.method_8045().method_45162())) {
            return class_1269.field_5814;
        } else if (!context.method_7716()) {
            return class_1269.field_5814;
        } else {
            class_1750 blockPlaceContext = this.method_16356(context);
            if (blockPlaceContext == null) {
                return class_1269.field_5814;
            } else {
                class_2680 blockState = this.method_7707(blockPlaceContext);
                if (blockState == null) {
                    return class_1269.field_5814;
                } else {
                    class_2338 blockPos = blockPlaceContext.method_8037();
                    class_1937 level = blockPlaceContext.method_8045();
                    class_1657 player = blockPlaceContext.method_8036();
                    class_1799 itemStack = blockPlaceContext.method_8041();
                    class_2338 relative = blockPos.method_10093(blockPlaceContext.method_8038().method_10153());
                    class_2680 relativeState = level.method_8320(relative);
                    if (relativeState.method_26204() instanceof MPHookBlock) {
                        blockState = blockState
                                .method_11657(MPBlockData.HOOK, relativeState.method_11654(MPBlockData.TYPES))
                                .method_11657(MPBlockData.WALL, relativeState.method_11654(MPBlockData.FACING))
                                .method_11657(MPBlockData.FACING, relativeState.method_11654(MPBlockData.FACING));
                        blockPos = relative;
                    } else if (blockPlaceContext.method_8038() != class_2350.field_11036
                            && blockPlaceContext.method_8038() != class_2350.field_11033
                            || !context.method_8045().method_8628(relativeState, context.method_8037(),
                            player == null ? class_3726.method_16194() : class_3726.method_16195(player))) {
                        return class_1269.field_5814;
                    }
                    if (!level.method_8652(blockPos, blockState, 11)) {
                        return class_1269.field_5814;
                    } else {
                        class_2680 placedState = level.method_8320(blockPos);

                        if (placedState.method_27852(blockState.method_26204())) {
                            placedState = this.method_18084(blockPos, level, itemStack, placedState);
                            this.method_7710(blockPos, level, player, itemStack, placedState);
                            placedState.method_26204().method_9567(level, blockPos, placedState, player, itemStack);
                            if (player instanceof class_3222 serverPlayer) {
                                class_174.field_1191.method_23889(serverPlayer, blockPos, itemStack);
                            }
                        }

                        class_2498 soundType = placedState.method_26231();
                        class_3414 placeSound = player != null
                                ? this.method_19260(placedState)
                                : soundType.method_10598();
                        level.method_8396(player, blockPos, placeSound, class_3419.field_15245,
                                (soundType.method_10597() + 1.0F) / 2.0F, soundType.method_10599() * 0.8F);
                        level.method_43276(class_5712.field_28164, blockPos, class_5712.class_7397.method_43286(player, placedState));
                        if (player == null || !player.method_31549().field_7477) {
                            itemStack.method_7934(1);
                        }

                        return class_1269.method_29236(level.field_9236);
                    }
                }
            }
        }
    }

    @Override
    protected boolean method_7709(@NotNull class_1750 context, @NotNull class_2680 state) {
        return !this.method_20360() || state.method_26184(context.method_8045(), context.method_8037());
    }

    private class_2680 method_18084(class_2338 pos, class_1937 level, class_1799 stack, class_2680 state) {
        if (typedBlockClass.isInstance(state.method_26204()) && stack.method_7969() != null) {
            class_2680 typedState = state.method_11657(MPBlockData.TYPES, stack.method_7969().method_10550(MPNBTData.ItemType));
            level.method_8652(pos, typedState, 2);
            return typedState;
        }

        return state;
    }
}

