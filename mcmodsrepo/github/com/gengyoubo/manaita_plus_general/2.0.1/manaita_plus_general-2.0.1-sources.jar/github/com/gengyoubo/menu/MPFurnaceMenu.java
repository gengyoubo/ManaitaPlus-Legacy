package github.com.gengyoubo.menu;

import github.com.gengyoubo.core.MPMenuCore;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1661;
import net.minecraft.class_1719;
import net.minecraft.class_1720;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_3913;
import net.minecraft.class_3919;
import net.minecraft.class_3956;
import net.minecraft.class_5421;

public class MPFurnaceMenu extends class_1720 {
    @SuppressWarnings("unused")
    public MPFurnaceMenu(int p_39532_, class_1661 p_39533_, class_2540 extraData) {
        super(MPMenuCore.FurnaceManaita.get(), class_3956.field_17546, class_5421.field_25764, p_39532_, p_39533_, new UnlimitedSimpleContainer(), new class_3919(4));
        replaceResultSlot(p_39533_);
    }

    public MPFurnaceMenu(int p_39535_, class_1661 p_39536_, class_1263 p_39537_, class_3913 p_39538_) {
        super(MPMenuCore.FurnaceManaita.get(), class_3956.field_17546, class_5421.field_25764, p_39535_, p_39536_, p_39537_, p_39538_);
        replaceResultSlot(p_39536_);
    }

    private void replaceResultSlot(class_1661 inventory) {
        class_1719 originalSlot = (class_1719) this.field_7761.get(2);
        UnlimitedFurnaceResultSlot replacement = new UnlimitedFurnaceResultSlot(inventory.field_7546, originalSlot.field_7871, 2, originalSlot.field_7873, originalSlot.field_7872);
        replacement.field_7874 = originalSlot.field_7874;
        this.field_7761.set(2, replacement);
    }

    private static class UnlimitedFurnaceResultSlot extends class_1719 {
        public UnlimitedFurnaceResultSlot(net.minecraft.class_1657 player, class_1263 container, int slot, int x, int y) {
            super(player, container, slot, x, y);
        }

        @Override
        public int method_7675() {
            return Integer.MAX_VALUE;
        }

        @Override
        public int method_7676(class_1799 stack) {
            return Integer.MAX_VALUE;
        }
    }

    private static class UnlimitedSimpleContainer extends class_1277 {
        public UnlimitedSimpleContainer() {
            super(3);
        }

        @Override
        public int method_5444() {
            return Integer.MAX_VALUE;
        }
    }

}

