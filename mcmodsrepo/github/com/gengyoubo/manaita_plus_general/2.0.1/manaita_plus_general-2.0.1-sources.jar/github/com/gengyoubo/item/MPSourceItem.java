package github.com.gengyoubo.item;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import github.com.gengyoubo.menu.MPCraftingMenu;
import github.com.gengyoubo.util.MPText;

import java.util.List;

public class MPSourceItem extends class_1792 {
    public MPSourceItem() {
        super(new class_1792.class_1793().method_24359());
    }

    @Override
    public @NotNull class_2561 method_7864(@NotNull class_1799 stack) {
        return class_2561.method_43470(MPText.manaita_mode.formatting(class_2561.method_43471("item.source.name").getString()));
    }

    @Override
    public void method_7851(@NotNull class_1799 stack, @Nullable class_1937 level, @NotNull List<class_2561> tooltip, @NotNull class_1836 flag) {
        super.method_7851(stack, level, tooltip, flag);
        tooltip.add(class_2561.method_43470(MPText.manaita_infinity.formatting(class_2561.method_43471("info.source.1").getString())));
    }

    @Override
    public boolean method_7886(@NotNull class_1799 stack) {
        return true;
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, @NotNull class_1268 hand) {
        class_1799 heldItem = player.method_5998(hand);
        if (!level.field_9236 && player instanceof class_3222 serverPlayer) {
            serverPlayer.method_17355(new ExtendedScreenHandlerFactory() {
                @Override
                public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
                    buf.method_10807(class_2338.field_10980);
                }

                @Override
                public @NotNull class_2561 method_5476() {
                    return class_2561.method_43471("container.crafting");
                }

                @Override
                public @NotNull net.minecraft.class_1703 createMenu(int windowId, @NotNull net.minecraft.class_1661 inventory, @NotNull class_1657 menuPlayer) {
                    return new MPCraftingMenu(windowId, inventory, level);
                }
            });
        }
        return class_1271.method_29237(heldItem, level.method_8608());
    }
}

