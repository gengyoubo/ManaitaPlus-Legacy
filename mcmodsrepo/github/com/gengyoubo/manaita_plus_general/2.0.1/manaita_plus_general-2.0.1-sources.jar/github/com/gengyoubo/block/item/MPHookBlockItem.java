package github.com.gengyoubo.block.item;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import github.com.gengyoubo.block.MPHookBlock;
import github.com.gengyoubo.block.data.MPBlockData;
import github.com.gengyoubo.util.MPNBTData;

import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_5712;

import static github.com.gengyoubo.core.MPBlockCore.HookBlock;

public class MPHookBlockItem extends class_1747 {
    public MPHookBlockItem() {
        super(HookBlock.get(), new class_1793().method_24359());
    }

    @Override
    public @NotNull class_2561 method_7864(class_1799 p_41458_) {
        return class_2561.method_43471("tile.fixed_hook." + p_41458_.method_7948().method_10550(MPNBTData.ItemType) + ".name");
    }

    @Override
    public void method_7851(@NotNull class_1799 stack, @Nullable class_1937 level, @NotNull List<class_2561> tooltip, @NotNull class_1836 flag) {
        super.method_7851(stack, level, tooltip, flag);
    }

    public @NotNull class_1269 method_7712(class_1750 p_40577_) {
        if (!this.method_7711().method_45382(p_40577_.method_8045().method_45162())) {
            return class_1269.field_5814;
        } else if (!p_40577_.method_7716()) {
            return class_1269.field_5814;
        } else {
            class_1750 blockplacecontext = this.method_16356(p_40577_);
            if (blockplacecontext == null) {
                return class_1269.field_5814;
            } else {
                class_2680 blockstate = this.method_7707(blockplacecontext);
                if (blockstate == null) {
                    return class_1269.field_5814;
                } else {
                    class_2338 blockpos = blockplacecontext.method_8037();
                    class_1937 level = blockplacecontext.method_8045();
                    class_1657 player = blockplacecontext.method_8036();
                    class_1799 itemstack = blockplacecontext.method_8041();
                    if (blockplacecontext.method_8038() == class_2350.field_11036 || blockplacecontext.method_8038() == class_2350.field_11033) {
                        return class_1269.field_5814;
                    }
                    if (!level.method_8652(blockpos, blockstate, 11)){
                        return class_1269.field_5814;
                    } else {
                        class_2680 blockstate1 = level.method_8320(blockpos);

                        if (blockstate1.method_27852(blockstate.method_26204())) {
                            blockstate1 = this.method_18084(blockpos, level, itemstack, blockstate1);
                            this.method_7710(blockpos, level, player, itemstack, blockstate1);
                            blockstate1.method_26204().method_9567(level, blockpos, blockstate1, player, itemstack);
                            if (player instanceof class_3222) {
                                class_174.field_1191.method_23889((class_3222) player, blockpos, itemstack);
                            }
                        }

                        class_2498 soundtype = blockstate1.method_26231();
                        if (p_40577_.method_8036() != null) {
                            level.method_8396(player, blockpos, this.method_19260(blockstate1), class_3419.field_15245, (soundtype.method_10597() + 1.0F) / 2.0F, soundtype.method_10599() * 0.8F);
                        }
                        level.method_43276(class_5712.field_28164, blockpos, class_5712.class_7397.method_43286(player, blockstate1));
                        if (player == null || !player.method_31549().field_7477) {
                            itemstack.method_7934(1);
                        }

                        return class_1269.method_29236(level.field_9236);
                    }
                }
            }
        }
    }

    private class_2680 method_18084(class_2338 pos, class_1937 level, class_1799 p_40605_, class_2680 p_40606_) {
        if (p_40606_.method_26204() instanceof MPHookBlock && p_40605_.method_7969() != null) {
            class_2680 manaitaType = p_40606_.method_11657(MPBlockData.TYPES, p_40605_.method_7969().method_10550(MPNBTData.ItemType));
            level.method_8652(pos, manaitaType, 2);
            return manaitaType;
        }

        return p_40606_;
    }
}

