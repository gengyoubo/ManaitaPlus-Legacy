package github.com.gengyoubo.jei;

import github.com.gengyoubo.MPGConfig;
import github.com.gengyoubo.MPG;
import github.com.gengyoubo.block.item.MPBrewingBlockItem;
import github.com.gengyoubo.block.item.MPCraftingBlockItem;
import github.com.gengyoubo.block.item.MPFurnaceBlockItem;
import github.com.gengyoubo.block.item.MPHookBlockItem;
import github.com.gengyoubo.core.MPItemCore;
import github.com.gengyoubo.gui.MPBrewingStandScreen;
import github.com.gengyoubo.gui.MPCraftingScreen;
import github.com.gengyoubo.gui.MPFurnaceScreen;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.constants.RecipeTypes;
import mezz.jei.api.registration.IGuiHandlerRegistration;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.registration.IRecipeCategoryRegistration;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.List;

@JeiPlugin
public class MPJeiPlugin implements IModPlugin {
    private static final class_2960 UID = new class_2960("manaita_plus_general", "jei_plugin");

    @Override
    public @NotNull class_2960 getPluginUid() {
        return UID;
    }

    @Override
    public void registerCategories(IRecipeCategoryRegistration registration) {
        MPG.LOGGER.info("Registering JEI categories for {}", UID);
        registration.addRecipeCategories(new MPSourceCopyRecipeCategory(registration.getJeiHelpers().getGuiHelper()));
    }

    @Override
    public void registerRecipes(IRecipeRegistration registration) {
        MPG.LOGGER.info("Registering JEI recipes for source copying");
        registration.addRecipes(MPSourceCopyRecipeCategory.TYPE, createSourceCopyRecipes());
        registration.addItemStackInfo(
                new class_1799(MPItemCore.ManaitaSource.get()),
                class_2561.method_43471("jei.manaita_plus_general.source.info.1"),
                class_2561.method_43469("jei.manaita_plus_general.source.info.2", MPGConfig.source_doubling_value)
        );
    }

    @Override
    public void registerGuiHandlers(IGuiHandlerRegistration registration) {
        registration.addRecipeClickArea(MPCraftingScreen.class, 88, 32, 28, 23, RecipeTypes.CRAFTING);
        registration.addRecipeClickArea(MPFurnaceScreen.class, 78, 32, 28, 23, RecipeTypes.SMELTING);
        registration.addRecipeClickArea(MPBrewingStandScreen.class, 97, 16, 14, 30, RecipeTypes.BREWING);
    }

    @Override
    public void registerRecipeCatalysts(IRecipeCatalystRegistration registration) {
        registration.addRecipeCatalyst(new class_1799(MPItemCore.ManaitaSource.get()), MPSourceCopyRecipeCategory.TYPE);
    }

    private static List<MPSourceCopyJeiRecipe> createSourceCopyRecipes() {
        return java.util.stream.Stream.concat(
                        java.util.stream.Stream.of(MPItemCore.ManaitaSource.get()),
                        class_7923.field_41178.method_10220()
                )
                .distinct()
                .filter(MPJeiPlugin::isCopyableItem)
                .sorted(Comparator.comparing(item -> class_7923.field_41178.method_10221(item).toString()))
                .map(class_1792::method_7854)
                .filter(stack -> !stack.method_7960())
                .map(MPJeiPlugin::createRecipe)
                .toList();
    }

    private static MPSourceCopyJeiRecipe createRecipe(class_1799 input) {
        int sourceResultCount = input.method_7947() * MPGConfig.source_doubling_value;
        class_1799 output = input.method_7972();
        output.method_7939(Math.max(sourceResultCount, 1));
        return new MPSourceCopyJeiRecipe(input, output, sourceResultCount);
    }

    private static boolean isCopyableItem(class_1792 item) {
        if (item instanceof MPCraftingBlockItem || item instanceof MPFurnaceBlockItem || item instanceof MPBrewingBlockItem || item instanceof MPHookBlockItem) {
            return false;
        }
        return item != net.minecraft.class_1802.field_8162;
    }
}
