package github.com.gengyoubo.item.tool.base;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import github.com.gengyoubo.item.data.IMPDestroy;
import github.com.gengyoubo.item.data.IMPDoubling;
import github.com.gengyoubo.item.data.IMPKey;
import github.com.gengyoubo.item.tier.MPToolTier;
import github.com.gengyoubo.util.MPNBTData;
import github.com.gengyoubo.util.MPText;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1766;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_6862;

public class MPToolBase extends class_1766 implements IMPKey, IMPDestroy, IMPDoubling {
    public MPToolBase(class_6862<class_2248> tagKey) {
        super(Float.MAX_VALUE, Float.MAX_VALUE, new MPToolTier(), tagKey, new class_1793().method_24359());
    }

    @Override
    public boolean accept(class_2680 state) {
        return true;
    }

    @Override
    public void method_7851(@NotNull class_1799 stack, @Nullable class_1937 level, @NotNull List<class_2561> tooltip, @NotNull class_1836 flag) {
        MPToolActionHelper.appendRangeAndDoublingTooltip(tooltip, getRange(stack), isDoubling(stack));
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(@NotNull class_1937 level, class_1657 player, @NotNull class_1268 hand) {
        class_1799 itemInHand = player.method_5998(hand);
        MPToolActionHelper.handleRangeOrEnchantmentUse(level, player, itemInHand, (getRange(itemInHand) + 2) % 21, range -> setRange(itemInHand, range, player));
        return class_1271.method_22430(itemInHand);
    }

    @Override
    public boolean method_7879(@NotNull class_1799 stack, @NotNull class_1937 level, @NotNull class_2680 state, @NotNull class_2338 blockPos, @NotNull class_1309 livingEntity) {
        return true;
    }

    @Override
    public int getRange(class_1799 itemStack) {
        if (!itemStack.method_7985()) {
            return 1;
        }
        int range = Objects.requireNonNull(itemStack.method_7969()).method_10550(MPNBTData.Range);
        if (range == 0) {
            itemStack.method_7969().method_10569(MPNBTData.Range, 1);
            return 1;
        }
        return range;
    }

    public void setRange(class_1799 itemStack, int range) {
        setRange(itemStack, range, null);
    }

    public void setRange(class_1799 itemStack, int range, class_1657 player) {
        if (range == 0) {
            range = 1;
        }
        itemStack.method_7948().method_10569(MPNBTData.Range, range);
        if (player != null) {
            player.method_7353(class_2561.method_43470(MPText.manaita_mode.formatting(itemStack.method_7954().getString() + " " + class_2561.method_43471("mode.range.name").getString() + ": " + range + "x" + range + "x" + range)), true);
        }
    }

    @Override
    public void onManaitaKeyPress(class_1799 itemStack) {
        toggleDoubling(itemStack);
    }

    @Override
    public void onManaitaKeyPressOnClient(class_1799 itemStack, class_1657 player) {
        boolean doubling = toggleDoubling(itemStack);
        player.method_7353(class_2561.method_43470(MPText.manaita_mode.formatting(itemStack.method_7954().getString() + " " + class_2561.method_43471("mode.doubling").getString() + ": " + (doubling ? class_2561.method_43471("info.on").getString() : class_2561.method_43471("info.off").getString()))), true);
    }

}

