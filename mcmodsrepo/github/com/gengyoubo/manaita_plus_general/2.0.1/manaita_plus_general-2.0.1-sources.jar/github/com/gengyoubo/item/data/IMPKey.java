package github.com.gengyoubo.item.data;

import net.minecraft.class_1657;
import net.minecraft.class_1799;

public interface IMPKey {
    default void onManaitaKeyPress(class_1799 paramItemStack) {
    }

    default void onManaitaKeyPress(class_1799 paramItemStack, class_1657 paramEntityPlayer) {
        onManaitaKeyPress(paramItemStack);
    }

    default void onManaitaKeyPressOnClient(class_1799 paramItemStack, class_1657 paramEntityPlayer) {
    }
}

