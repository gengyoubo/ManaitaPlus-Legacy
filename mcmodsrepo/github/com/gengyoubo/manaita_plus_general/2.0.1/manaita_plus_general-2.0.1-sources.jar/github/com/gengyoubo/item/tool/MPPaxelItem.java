package github.com.gengyoubo.item.tool;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import github.com.gengyoubo.item.tool.base.MPToolActionHelper;
import github.com.gengyoubo.item.tool.base.MPToolBase;
import github.com.gengyoubo.util.MPEntityData;
import github.com.gengyoubo.util.MPText;

import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_3481;

public class MPPaxelItem extends MPToolBase {
    public static final net.minecraft.class_6862<class_2248> MINEABLE = class_3481.field_33715;

    public MPPaxelItem() {
        super(MINEABLE);
    }
    @Override
    public boolean method_7873(@NotNull class_1799 stack, @NotNull class_1309 target, @NotNull class_1309 attacker) {
        MPEntityData.death.add(target);
        target.method_5643(target.method_48923().method_48812(attacker), 10000);
        target.method_6033(0F);
        return super.method_7873(stack, target, attacker);
    }

    @Override
    public void method_7851(@NotNull class_1799 stack, @Nullable class_1937 level, @NotNull List<class_2561> tooltip, @NotNull class_1836 flag) {
        super.method_7851(stack, level, tooltip, flag);
        tooltip.add(class_2561.method_43473());
        tooltip.add(class_2561.method_43470(MPText.manaita_infinity.formatting(class_2561.method_43471("info.attack").getString())));
    }

    @Override
    public void method_7888(class_1799 stack, @NotNull class_1937 level, @NotNull class_1297 entity, int slot, boolean selected) {
        stack.method_7912(0);
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        int range = getRange(context.method_8041()) >> 1;
        boolean changed = MPToolActionHelper.applyInRange(context, range, (pos, state) ->
                MPToolActionHelper.applyAxeActions(context, pos, state)
                        | MPToolActionHelper.applyGrowPlantAction(context, pos, state)
                        | MPToolActionHelper.applyShovelAction(context, pos, state));
        return changed ? class_1269.method_29236(context.method_8045().field_9236) : class_1269.field_5811;
    }
}

