package github.com.gengyoubo.core;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.lang.reflect.Field;
import net.minecraft.class_1297;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;

public class MPSynchedDataCore {
    public static int i = -1;

    @SuppressWarnings("unchecked")
    public static void init() {
        try {
            Field declaredField = class_2945.class.getDeclaredField("ENTITY_ID_POOL");
            declaredField.setAccessible(true);
            Object2IntMap<Class<? extends class_1297>> classObject2IntMap = (Object2IntMap<Class<? extends class_1297>>) declaredField.get(class_2945.class);
            if (classObject2IntMap.isEmpty()) {
                i = 1;
                classObject2IntMap.put(class_1297.class, 1);
            }
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace(System.err);
        }
    }

    public static class_2940<Integer> get() {
        return class_2943.field_13327.method_12717(i);
    }
}

