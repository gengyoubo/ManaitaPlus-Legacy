package github.com.gengyoubo.item.tool.base;

import github.com.gengyoubo.util.MPText;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.IntConsumer;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3922;
import net.minecraft.class_4865;
import net.minecraft.class_5712;

public final class MPToolActionHelper {
    private MPToolActionHelper() {
    }

    @FunctionalInterface
    public interface RangeBlockAction {
        boolean apply(class_2338.class_2339 mutableBlockPos, class_2680 blockState);
    }

    public static boolean applyInRange(class_1838 context, int range, RangeBlockAction action) {
        class_1937 level = context.method_8045();
        class_2338 center = context.method_8037();
        class_2338.class_2339 mutableBlockPos = new class_2338.class_2339();
        int xM = center.method_10263() + range;
        int yM = center.method_10264() + range;
        int zM = center.method_10260() + range;
        boolean changed = false;

        for (int x = center.method_10263() - range; x <= xM; x++) {
            for (int y = center.method_10264() - range; y <= yM; y++) {
                for (int z = center.method_10260() - range; z <= zM; z++) {
                    mutableBlockPos.method_10103(x, y, z);
                    changed |= action.apply(mutableBlockPos, level.method_8320(mutableBlockPos));
                }
            }
        }
        return changed;
    }

    public static boolean applyHoeTillAction(class_1838 context, class_2338 pos, class_2680 blockState) {
        return true;
    }

    public static void handleRangeOrEnchantmentUse(class_1937 level, class_1657 player, class_1799 itemInHand, int nextRange, IntConsumer rangeSetter) {
        if (level.field_9236) {
            return;
        }
        if (player.method_5715()) {
            rangeSetter.accept(nextRange);
            return;
        }

        Map<class_1887, Integer> enchantmentMap = new HashMap<>();
        enchantmentMap.put(class_1893.field_9130, 10);
        String enchantName = class_2561.method_43471("enchantments.fortune").getString();
        if (!class_1890.method_49189(itemInHand)) {
            enchantmentMap.put(class_1893.field_9099, 1);
            enchantName = class_2561.method_43471("enchantments.silktouch").getString();
        }
        class_1890.method_8214(enchantmentMap, itemInHand);
        player.method_7353(class_2561.method_43470(MPText.manaita_enchantment.formatting(itemInHand.method_7954().getString() + class_2561.method_43471("info.enchantment").getString() + ": " + enchantName)), true);
    }

    public static void appendRangeAndDoublingTooltip(List<class_2561> tooltip, int range, boolean doubling) {
        String rangeValue = String.valueOf(range);
        tooltip.add(class_2561.method_43470(MPText.manaita_mode.formatting(class_2561.method_43471("mode.manaita_tool").getString() + ": " + rangeValue + "x" + rangeValue + "x" + rangeValue)));
        tooltip.add(class_2561.method_43470(MPText.manaita_mode.formatting(class_2561.method_43471("mode.doubling").getString() + ":" + (doubling ? class_2561.method_43471("info.on").getString() : class_2561.method_43471("info.off").getString()))));
    }

    public static boolean applyAxeActions(class_1838 context, class_2338 pos, class_2680 blockState) {
        return false;
    }

    public static boolean applyGrowPlantAction(class_1838 context, class_2338 pos, class_2680 blockState) {
        if (!(blockState.method_26204() instanceof class_4865 growingPlantHeadBlock) || growingPlantHeadBlock.method_38233(blockState)) {
            return false;
        }

        class_1937 level = context.method_8045();
        class_1657 player = context.method_8036();
        class_1799 itemStack = context.method_8041();

        if (player instanceof class_3222 serverPlayer) {
            class_174.field_24478.method_23889(serverPlayer, pos, itemStack);
        }
        level.method_8396(player, pos, class_3417.field_34896, class_3419.field_15245, 1.0F, 1.0F);
        class_2680 maxAgeState = growingPlantHeadBlock.method_38232(blockState);
        level.method_8501(pos, maxAgeState);
        level.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43286(player, maxAgeState));
        damageHeldItem(context, player, itemStack);
        return true;
    }

    public static boolean applyShovelAction(class_1838 context, class_2338 pos, class_2680 blockState) {
        if (context.method_8038() == class_2350.field_11033) {
            return false;
        }
        class_1937 level = context.method_8045();
        class_2680 targetState = null;
        if (blockState.method_26204() instanceof class_3922 && blockState.method_11654(class_3922.field_17352)) {
            if (!level.method_8608()) {
                level.method_8444(null, 1009, pos, 0);
            }
            class_3922.method_29288(context.method_8036(), level, pos, blockState);
            targetState = blockState.method_11657(class_3922.field_17352, Boolean.FALSE);
        }
        if (targetState == null) {
            return false;
        }
        class_1657 player = context.method_8036();
        if (!level.field_9236) {
            level.method_8652(pos, targetState, 11);
            level.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43286(player, targetState));
            damageHeldItem(context, player, context.method_8041());
        }
        return true;
    }

    private static void damageHeldItem(class_1838 context, class_1657 player, class_1799 itemStack) {
        if (player != null) {
            itemStack.method_7956(1, player, brokenPlayer -> brokenPlayer.method_20236(context.method_20287()));
        }
    }
}
