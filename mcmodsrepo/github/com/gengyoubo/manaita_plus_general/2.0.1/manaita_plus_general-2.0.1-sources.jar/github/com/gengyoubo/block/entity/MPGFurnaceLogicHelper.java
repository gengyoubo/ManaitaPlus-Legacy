package github.com.gengyoubo.block.entity;

import com.google.common.collect.Lists;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import org.jetbrains.annotations.Nullable;
import java.util.List;
import net.minecraft.class_1278;
import net.minecraft.class_1303;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1874;
import net.minecraft.class_2371;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_5455;

public final class MPGFurnaceLogicHelper {
    private MPGFurnaceLogicHelper() {
    }

    public static boolean canBurn(class_5455 registryAccess, @Nullable class_1860<?> recipe, class_2371<class_1799> items, class_1278 container) {
        if (items.get(0).method_7960() || recipe == null) {
            return false;
        }
        class_1799 assembled = assembleResult(recipe, container, registryAccess);
        if (assembled.method_7960()) {
            return false;
        }
        class_1799 output = items.get(2);
        return output.method_7960() || class_1799.method_7984(output, assembled);
    }

    @SuppressWarnings("unchecked")
    public static class_1799 assembleResult(class_1860<?> recipe, class_1278 container, class_5455 registryAccess) {
        return ((class_1860<class_1278>) recipe).method_8116(container, registryAccess);
    }

    public static void awardUsedRecipesAndPopExperience(class_3222 player, class_2371<class_1799> items, Object2IntMap<class_2960> recipesUsed) {
        List<class_1860<?>> recipes = getRecipesToAwardAndPopExperience(player.method_51469(), player.method_19538(), recipesUsed);
        player.method_7254(recipes);
        for (class_1860<?> recipe : recipes) {
            if (recipe != null) {
                player.method_51283(recipe, items);
            }
        }
        recipesUsed.clear();
    }

    public static List<class_1860<?>> getRecipesToAwardAndPopExperience(class_3218 level, class_243 pos, Object2IntMap<class_2960> recipesUsed) {
        List<class_1860<?>> recipes = Lists.newArrayList();
        for (Object2IntMap.Entry<class_2960> entry : recipesUsed.object2IntEntrySet()) {
            level.method_8433().method_8130(entry.getKey()).ifPresent(recipe -> {
                recipes.add(recipe);
                createExperience(level, pos, entry.getIntValue(), ((class_1874) recipe).method_8171());
            });
        }
        return recipes;
    }

    private static void createExperience(class_3218 level, class_243 pos, int craftedCount, float xpPerItem) {
        int totalXp = class_3532.method_15375((float) craftedCount * xpPerItem);
        float fractional = class_3532.method_22450((float) craftedCount * xpPerItem);
        if (fractional != 0.0F && Math.random() < (double) fractional) {
            ++totalXp;
        }
        class_1303.method_31493(level, pos, totalXp * 64);
    }
}

