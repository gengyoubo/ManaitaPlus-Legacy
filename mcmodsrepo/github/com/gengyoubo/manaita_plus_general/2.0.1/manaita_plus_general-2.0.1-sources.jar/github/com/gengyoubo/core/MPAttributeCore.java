package github.com.gengyoubo.core;

import net.minecraft.class_1320;
import net.minecraft.class_1329;
import net.minecraftforge.registries.RegistryObject;

import static github.com.gengyoubo.MPG.ATTRIBUTE_TYPE;

public class MPAttributeCore {
    public static final RegistryObject<class_1320> Type = ATTRIBUTE_TYPE.register("type", () -> (new class_1329("entity.type", 0.0D, 0.0D, 13.0D)).method_26829(true));

    public static void init() {
    }

}

