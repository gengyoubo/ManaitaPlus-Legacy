package github.com.gengyoubo.block;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2363;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3468;
import net.minecraft.class_3726;
import net.minecraft.class_3908;
import net.minecraft.class_4970;
import net.minecraft.class_5558;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import org.jetbrains.annotations.NotNull;
import github.com.gengyoubo.block.data.MPBlockData;
import github.com.gengyoubo.block.entity.MPFurnaceBlockEntity;
import github.com.gengyoubo.core.MPBlockEntityCore;

import org.jetbrains.annotations.Nullable;
import java.util.List;

import static github.com.gengyoubo.block.MPBrewingStandBlock.getItemStacks;

@SuppressWarnings("deprecation")
public class MPFurnaceBlock extends class_2363 {
    public MPFurnaceBlock() {
        super(class_4970.class_2251.method_9637().method_22488());
        this.method_9590(this.field_10647.method_11664().method_11657(MPBlockData.HOOK, 8).method_11657(field_11104, class_2350.field_11043).method_11657(MPBlockData.WALL,class_2350.field_11033).method_11657(field_11105, Boolean.FALSE).method_11657(MPBlockData.TYPES,0));
    }

    protected void method_17025(class_1937 p_53631_, @NotNull class_2338 p_53632_, @NotNull class_1657 p_53633_) {
        class_2586 blockentity = p_53631_.method_8321(p_53632_);
        if (blockentity instanceof MPFurnaceBlockEntity) {
            p_53633_.method_17355((class_3908) blockentity);
            p_53633_.method_7281(class_3468.field_15379);
        }
    }

    public @NotNull class_2464 method_9604(@NotNull class_2680 p_48727_) {
        return class_2464.field_11455;
    }


    @Override
    public @NotNull List<class_1799> method_9560(@NotNull class_2680 p_287732_, class_8567.@NotNull class_8568 p_287596_) {
        return getItemStacks(p_287732_);
    }

    public @NotNull class_2680 method_9605(class_1750 p_48689_) {
        return this.method_9564().method_11657(field_11104, p_48689_.method_8042().method_10153()).method_11657(MPBlockData.WALL,p_48689_.method_8038().method_10153()).method_11657(MPBlockData.FACING, p_48689_.method_8042().method_10153());
    }


    @Override
    public @NotNull class_265 method_9530(class_2680 p_60555_, @NotNull class_1922 p_60556_, @NotNull class_2338 p_60557_, @NotNull class_3726 p_60558_) {
        class_2350 wall = p_60555_.method_11654(MPBlockData.WALL);
        class_2350 facing = p_60555_.method_11654(MPBlockData.FACING);
        boolean hasHook = p_60555_.method_11654(MPBlockData.HOOK) != 8;
        return MPBlockData.getWallMountedShape(wall, facing, hasHook);
    }

    public @NotNull class_2680 method_9569(class_2680 p_154351_, class_2415 p_154352_) {
        return p_154351_.method_11657(field_11104, p_154352_.method_10343(p_154351_.method_11654(field_11104)));
    }

    public class_2586 method_10123(@NotNull class_2338 p_153277_, @NotNull class_2680 p_153278_) {
        return new MPFurnaceBlockEntity(p_153277_, p_153278_);
    }
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> p_48725_) {
        p_48725_.method_11667(field_11104, field_11105, MPBlockData.TYPES, MPBlockData.WALL, MPBlockData.HOOK);
    }

    @Nullable
    public <T extends class_2586> class_5558<T> method_31645(class_1937 p_153273_, @NotNull class_2680 p_153274_, @NotNull class_2591<T> p_153275_) {
        return p_153273_.field_9236 ? null : method_31618(p_153275_, MPBlockEntityCore.FURNACE_BLOCK_ENTITY.get(), MPFurnaceBlockEntity::serverTick);
    }
}


