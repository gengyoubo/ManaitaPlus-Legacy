package github.com.gengyoubo.network.server;

import github.com.gengyoubo.network.MPNetworking;
import net.minecraft.class_1792;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class MPDestroyBlockPacket {
    private final class_2338 blockPos;
    private final int range;
    private final class_1792 item;

    public MPDestroyBlockPacket(class_2540 buffer) {
        this.blockPos = buffer.method_10811();
        this.range = buffer.readInt();
        class_2960 itemId = buffer.method_10810();
        this.item = class_7923.field_41178.method_10223(itemId);
    }

    public MPDestroyBlockPacket(class_2338 blockPos, int range, class_1792 item) {
        this.blockPos = blockPos;
        this.range = range;
        this.item = item;
    }

    public class_2540 toBuf() {
        class_2540 buf = MPNetworking.createBuf();
        buf.method_10807(blockPos);
        buf.writeInt(range);
        class_2960 itemId = class_7923.field_41178.method_10221(item);
        buf.method_10812(itemId);
        return buf;
    }

    public class_2338 getBlockPos() {
        return blockPos;
    }

    public int getRange() {
        return range;
    }

    public class_1792 getItem() {
        return item;
    }
}
