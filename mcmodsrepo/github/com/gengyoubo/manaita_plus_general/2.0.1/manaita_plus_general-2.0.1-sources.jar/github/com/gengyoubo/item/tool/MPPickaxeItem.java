package github.com.gengyoubo.item.tool;

import github.com.gengyoubo.item.tool.base.MPTaggedToolItem;
import net.minecraft.class_3481;

public class MPPickaxeItem extends MPTaggedToolItem {
    public MPPickaxeItem() {
        super(class_3481.field_33715);
    }
}
