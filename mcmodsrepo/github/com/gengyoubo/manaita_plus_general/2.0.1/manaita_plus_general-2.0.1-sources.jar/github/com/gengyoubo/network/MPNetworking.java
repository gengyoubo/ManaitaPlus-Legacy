package github.com.gengyoubo.network;

import github.com.gengyoubo.MPG;
import github.com.gengyoubo.network.client.MPKeyPressPacket;
import github.com.gengyoubo.network.server.MPChangeEntityDataPacket;
import github.com.gengyoubo.network.server.MPDestroyBlockPacket;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class MPNetworking {
    public static final class_2960 KEY_PRESS = id("key_press");
    public static final class_2960 DESTROY_BLOCK = id("destroy_block");
    public static final class_2960 CHANGE_ENTITY_DATA = id("change_entity_data");

    private MPNetworking() {
    }

    public static void initServer() {
        ServerPlayNetworking.registerGlobalReceiver(KEY_PRESS, (server, player, handler, buf, responseSender) -> {
            MPKeyPressPacket packet = new MPKeyPressPacket(buf);
            server.execute(() -> packet.handle(player));
        });
    }

    public static void sendToSameLevelPlayers(class_1937 level, MPDestroyBlockPacket packet) {
        if (level instanceof class_3218 serverLevel) {
            for (class_3222 serverPlayer : serverLevel.method_18456()) {
                ServerPlayNetworking.send(serverPlayer, DESTROY_BLOCK, packet.toBuf());
            }
        }
    }

    public static void sendToSameLevelPlayers(class_1937 level, MPChangeEntityDataPacket packet) {
        if (level instanceof class_3218 serverLevel) {
            for (class_3222 serverPlayer : serverLevel.method_18456()) {
                ServerPlayNetworking.send(serverPlayer, CHANGE_ENTITY_DATA, packet.toBuf());
            }
        }
    }

    @Deprecated
    public static void sendToNearByPlayers(class_1937 level, MPDestroyBlockPacket packet, int range) {
        sendToSameLevelPlayers(level, packet);
    }

    public static void sendToTrackBySeen(class_1937 level, class_1657 player, MPDestroyBlockPacket packet) {
        if (level instanceof class_3218 serverLevel) {
            class_2540 buf = packet.toBuf();
            for (class_3222 serverPlayer : serverLevel.method_18456()) {
                if (serverPlayer == player || serverPlayer.method_5858(player) <= 128.0D * 128.0D) {
                    ServerPlayNetworking.send(serverPlayer, DESTROY_BLOCK, PacketByteBufs.copy(buf));
                }
            }
        }
    }

    public static class_2540 createBuf() {
        return PacketByteBufs.create();
    }

    private static class_2960 id(String path) {
        return new class_2960(MPG.MODID, path);
    }
}
