package github.com.gengyoubo.item.portable;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import github.com.gengyoubo.util.MPNBTData;

import java.util.List;

public abstract class MPGPortableItem extends class_1792 {
    private final String translationPrefix;

    protected MPGPortableItem(String translationPrefix) {
        super(new class_1793().method_7898(-1).method_24359().method_7889(1));
        this.translationPrefix = translationPrefix;
    }

    @Override
    public @NotNull class_2561 method_7864(class_1799 stack) {
        return class_2561.method_43471(translationPrefix + stack.method_7948().method_10550(MPNBTData.ItemType) + ".name");
    }

    @Override
    public void method_7851(@NotNull class_1799 stack, @Nullable class_1937 level, @NotNull List<class_2561> tooltip, @NotNull class_1836 flag) {
        super.method_7851(stack, level, tooltip, flag);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(@NotNull class_1937 level, @NotNull class_1657 player, @NotNull class_1268 hand) {
        class_1799 itemInHand = player.method_5998(hand);
        if (player instanceof class_3222 serverPlayer) {
            openPortableMenu(serverPlayer, itemInHand, level);
        }
        return super.method_7836(level, player, hand);
    }

    protected abstract void openPortableMenu(class_3222 serverPlayer, class_1799 itemInHand, class_1937 level);

    protected final void openPortableScreen(class_3222 serverPlayer, class_1799 itemInHand, class_1937 level, String titleKey, PortableMenuFactory menuFactory) {
        serverPlayer.method_17355(new ExtendedScreenHandlerFactory() {
            @Override
            public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
                buf.method_10807(class_2338.field_10980);
            }

            @Override
            public @NotNull class_2561 method_5476() {
                return class_2561.method_43471(titleKey);
            }

            @Override
            public @NotNull class_1703 createMenu(int containerId, @NotNull class_1661 inventory, @NotNull class_1657 player) {
                return menuFactory.create(containerId, inventory, player, itemInHand, level);
            }
        });
    }

    @FunctionalInterface
    protected interface PortableMenuFactory {
        class_1703 create(int containerId, class_1661 inventory, class_1657 player, class_1799 itemInHand, class_1937 level);
    }
}
