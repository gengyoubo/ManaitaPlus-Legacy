package github.com.gengyoubo.block.entity;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_1874;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2609;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3956;
import net.minecraft.class_5455;
import net.minecraft.core.*;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;
import github.com.gengyoubo.MPGConfig;
import github.com.gengyoubo.core.MPBlockEntityCore;
import github.com.gengyoubo.menu.MPFurnaceMenu;

public class MPFurnaceBlockEntity extends class_2609 implements ExtendedScreenHandlerFactory {
    private static final int[] SLOTS_FOR_UP = new int[]{0};
    private static final int[] SLOTS_FOR_DOWN = new int[]{2, 1};
    private static final int[] SLOTS_FOR_SIDES = new int[]{1};
    private final Object2IntOpenHashMap<class_2960> recipesUsed = new Object2IntOpenHashMap<>();
    private final class_1863.class_7266<class_1263, ? extends class_1874> quickCheck;

    public MPFurnaceBlockEntity(class_2338 p_155545_, class_2680 p_155546_) {
        super(MPBlockEntityCore.FURNACE_BLOCK_ENTITY.get(), p_155545_, p_155546_, class_3956.field_17546);
        this.quickCheck = class_1863.method_42302(class_3956.field_17546);
    }

    protected @NotNull class_2561 method_17823() {
        return class_2561.method_43471("container.furnace_manaita");
    }

    protected @NotNull class_1703 method_5465(int p_59293_, @NotNull class_1661 p_59294_) {
        return new MPFurnaceMenu(p_59293_, p_59294_, this, this.field_17374);
    }

    @Override
    public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
        buf.method_10807(this.field_11867);
    }

    @Override
    public int method_5444() {
        return Integer.MAX_VALUE;
    }

    public void method_11014(@NotNull class_2487 p_155025_) {
        super.method_11014(p_155025_);
        this.field_11984 = class_2371.method_10213(this.method_5439(), class_1799.field_8037);
        class_1262.method_5429(p_155025_, this.field_11984);
        class_2487 compoundtag = p_155025_.method_10562("RecipesUsed");

        for(String s : compoundtag.method_10541()) {
            this.recipesUsed.put(new class_2960(s), compoundtag.method_10550(s));
        }

    }

    protected void method_11007(@NotNull class_2487 p_187452_) {
        super.method_11007(p_187452_);
        class_1262.method_5426(p_187452_, this.field_11984);
        class_2487 compoundtag = new class_2487();
        this.recipesUsed.forEach((p_187449_, p_187450_) -> compoundtag.method_10569(p_187449_.toString(), p_187450_));
        p_187452_.method_10566("RecipesUsed", compoundtag);
    }


    public static void serverTick(class_1937 p_155014_, class_2338 p_155015_, class_2680 p_155016_, MPFurnaceBlockEntity entity) {
        boolean flag1 = false;

        if (!entity.field_11984.get(0).method_7960()) {
            class_1860<?> recipe = entity.quickCheck.method_42303(entity, p_155014_).orElse(null);
            while (entity.canBurn(p_155014_.method_30349(), recipe, entity.field_11984)) {
                if (entity.burn(p_155014_.method_30349(), recipe, entity.field_11984)) {
                    entity.method_7662(recipe);
                }
                flag1 = true;
            }
        }


        if (flag1) {
            method_31663(p_155014_, p_155015_, p_155016_);
        }
    }

    private boolean canBurn(class_5455 p_266924_, @Nullable class_1860<?> p_155006_, class_2371<class_1799> p_155007_) {
        return MPGFurnaceLogicHelper.canBurn(p_266924_, p_155006_, p_155007_, this);
    }

    private boolean burn(class_5455 p_266740_, @Nullable class_1860<?> p_266780_, class_2371<class_1799> p_267073_) {
        if (p_266780_ != null && this.canBurn(p_266740_, p_266780_, p_267073_)) {
            class_1799 itemstack = p_267073_.get(0);
            class_1799 itemstack1 = MPGFurnaceLogicHelper.assembleResult(p_266780_, this, p_266740_);
            class_1799 itemstack2 = p_267073_.get(2);
            if (itemstack2.method_7960()) {
                class_1799 copy = itemstack1.method_7972();
                copy.method_7939(copy.method_7947() * MPGConfig.furnace_doubling_value);
                p_267073_.set(2, copy);
            } else if (itemstack2.method_31574(itemstack1.method_7909())) {
                itemstack2.method_7933(itemstack1.method_7947() * MPGConfig.furnace_doubling_value);
            }

            itemstack.method_7934(1);
            return true;
        } else {
            return false;
        }
    }

    protected int method_11200(@NotNull class_1799 p_58343_) {
        return 0;
    }

    public int @NotNull [] method_5494(@NotNull class_2350 p_58363_) {
        if (p_58363_ == class_2350.field_11033) {
            return SLOTS_FOR_DOWN;
        } else {
            return p_58363_ == class_2350.field_11036 ? SLOTS_FOR_UP : SLOTS_FOR_SIDES;
        }
    }

    public boolean method_5492(int p_58336_, @NotNull class_1799 p_58337_, @Nullable class_2350 p_58338_) {
        return this.method_5437(p_58336_, p_58337_);
    }

    public void method_5447(int p_58333_, class_1799 p_58334_) {
        class_1799 itemstack = this.field_11984.get(p_58333_);
        boolean flag = !p_58334_.method_7960() && class_1799.method_31577(itemstack, p_58334_);
        this.field_11984.set(p_58333_, p_58334_);

        if (p_58333_ == 0 && !flag) {
            this.method_5431();
        }

    }

    public boolean method_5443(@NotNull class_1657 p_58340_) {
        return true;
    }

    public boolean method_5437(int p_58389_, @NotNull class_1799 p_58390_) {
        return p_58389_ != 2;
    }

    public void method_7662(@Nullable class_1860<?> p_58345_) {
        if (p_58345_ != null) {
            class_2960 resourcelocation = p_58345_.method_8114();
            this.recipesUsed.addTo(resourcelocation, 1);
        }

    }

    public void method_17763(@NotNull class_3222 p_155004_) {
        MPGFurnaceLogicHelper.awardUsedRecipesAndPopExperience(p_155004_, this.field_11984, this.recipesUsed);
    }

    public @NotNull java.util.List<class_1860<?>> method_27354(@NotNull class_3218 p_154996_, @NotNull class_243 p_154997_) {
        return MPGFurnaceLogicHelper.getRecipesToAwardAndPopExperience(p_154996_, p_154997_, this.recipesUsed);
    }

}


