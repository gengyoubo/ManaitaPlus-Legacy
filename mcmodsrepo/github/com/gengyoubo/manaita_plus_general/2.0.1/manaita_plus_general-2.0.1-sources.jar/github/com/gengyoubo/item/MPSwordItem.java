package github.com.gengyoubo.item;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import github.com.gengyoubo.item.data.IMPDoubling;
import github.com.gengyoubo.item.data.IMPKey;
import github.com.gengyoubo.util.MPText;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3532;

public class MPSwordItem extends class_1829 implements IMPKey, IMPDoubling {
    public MPSwordItem() {
        super(new ItemManaitaSwordTier(), 0, 0, new class_1792.class_1793().method_24359());
    }

    @Override
    public void method_7888(class_1799 stack, @NotNull class_1937 level, @NotNull class_1297 entity, int slot, boolean selected) {
        stack.method_7912(0);
    }

    @Override
    public boolean method_7873(@NotNull class_1799 stack, @NotNull class_1309 target, @NotNull class_1309 attacker) {
        if (attacker instanceof class_1657 player) {
            int sweep = getSweep(stack);
            for (int i1 = 0; i1 < sweep; i1++) {
                class_243 vec3 = player.method_5720();
                class_238 aabb = player.method_5829().method_1012(3.0D, 3.0D, 3.0D).method_989(vec3.field_1352 * i1, vec3.field_1351 * i1, vec3.field_1350 * i1);
                for (class_1297 entity1 : player.method_37908().method_8333(player, aabb, (p_20434_) -> true)) {
                    if (entity1 instanceof class_1309 living) {
                        if (!player.method_37908().field_9236) {
                            living.method_5643(living.method_48923().method_48802(player), Float.MAX_VALUE);
                            living.method_6033(Float.NaN);
                        }
                        for (int i = 0; i < 5; i++) {
                            living.method_5711((byte) 2);
                        }
                        for (int i = 47; i < 53; i++) {
                            living.method_5711((byte) i);
                        }
                        living.method_5711((byte) 3);
                    }
                }
                double d0 = (-class_3532.method_15374(player.method_36454() * ((float) Math.PI / 180F)));
                double d1 = class_3532.method_15362(player.method_36454() * ((float) Math.PI / 180F));
                if (player.method_37908() instanceof class_3218 serverLevel) {
                    serverLevel.method_14199(class_2398.field_11227, player.method_23317() + d0 + vec3.field_1352 * i1, player.method_23323(0.5D) + vec3.field_1351 * i1, player.method_23321() + d1 + vec3.field_1350 * i1, 0, d0, 0.0D, d1, 0.0D);
                }
                player.method_37908().method_43128(null, player.method_23317() + d0 + vec3.field_1352 * i1, player.method_23323(0.5D) + vec3.field_1351 * i1, player.method_23321() + d1 + vec3.field_1350 * i1, class_3417.field_14706, player.method_5634(), 1.0F, 1.0F);
            }
        }
        return super.method_7873(stack, target, attacker);
    }

    @Override
    public void method_7851(@NotNull class_1799 stack, @Nullable class_1937 level, @NotNull List<class_2561> tooltip, @NotNull class_1836 flag) {
        super.method_7851(stack, level, tooltip, flag);
        tooltip.add(class_2561.method_43470(MPText.manaita_mode.formatting(class_2561.method_43471("mode.manaita_sword").getString() + ":" + getSweep(stack))));
        tooltip.add(class_2561.method_43473());
        tooltip.add(class_2561.method_43470(MPText.manaita_infinity.formatting(class_2561.method_43471("info.attack").getString())));
    }

    @Override
    public @NotNull class_2561 method_7864(@NotNull class_1799 stack) {
        return class_2561.method_43470(MPText.manaita_infinity.formatting(class_2561.method_43471("item.manaita_sword.name").getString()));
    }

    public static int getSweep(class_1799 itemStack) {
        if (!itemStack.method_7985()) {
            return 1;
        }
        int sweep = Objects.requireNonNull(itemStack.method_7969()).method_10550("Sweep");
        return Math.max(1, sweep);
    }

    public static void setSweep(class_1799 itemStack, int sweep) {
        itemStack.method_7948().method_10569("Sweep", Math.max(1, sweep));
    }

    @Override
    public void onManaitaKeyPress(class_1799 itemStack) {
        setSweep(itemStack, (getSweep(itemStack) % 10) + 1);
    }

    @Override
    public void onManaitaKeyPressOnClient(class_1799 itemStack, class_1657 player) {
        onManaitaKeyPress(itemStack);
        player.method_7353(class_2561.method_43470(MPText.manaita_mode.formatting(String.format("[%s] %s: %d", class_2561.method_43471("item.manaita_sword.name").getString(), class_2561.method_43471("mode.manaita_sword").getString(), getSweep(itemStack)))), true);
    }

    public void method_33261(class_1542 itemEntity) {
    }

    public static final class ItemManaitaSwordTier implements class_1832 {
        @Override
        public int method_8025() {
            return -1;
        }

        @Override
        public float method_8027() {
            return Float.MAX_VALUE;
        }

        @Override
        public float method_8028() {
            return Float.MAX_VALUE;
        }

        @Override
        public int method_8024() {
            return Integer.MAX_VALUE;
        }

        @Override
        public int method_8026() {
            return 0;
        }

        @Override
        public @NotNull class_1856 method_8023() {
            return class_1856.method_8091(class_1802.field_22020);
        }

    }
}

