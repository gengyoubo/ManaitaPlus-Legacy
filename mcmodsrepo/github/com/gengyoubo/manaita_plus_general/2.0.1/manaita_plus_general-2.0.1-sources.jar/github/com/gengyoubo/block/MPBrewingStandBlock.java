package github.com.gengyoubo.block;

import com.google.common.collect.Lists;
import net.minecraft.class_10;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2589;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3468;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.world.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import org.jetbrains.annotations.NotNull;
import github.com.gengyoubo.block.data.MPBlockData;
import github.com.gengyoubo.block.entity.MPBrewingStandBlockEntity;
import github.com.gengyoubo.core.MPBlockCore;
import github.com.gengyoubo.core.MPBlockEntityCore;
import github.com.gengyoubo.util.MPNBTData;

import org.jetbrains.annotations.Nullable;
import java.util.List;

@SuppressWarnings("deprecation")
public class MPBrewingStandBlock extends class_2237 {
    public static final class_2746[] HAS_BOTTLE = new class_2746[]{class_2741.field_12554, class_2741.field_12500, class_2741.field_12531};

    public MPBrewingStandBlock() {
        super(class_2251.method_9637().method_22488());
        this.method_9590(this.field_10647.method_11664().method_11657(MPBlockData.HOOK, 8).method_11657(MPBlockData.FACING, class_2350.field_11043).method_11657(MPBlockData.WALL,class_2350.field_11033).method_11657(MPBlockData.TYPES,0).method_11657(HAS_BOTTLE[0], Boolean.FALSE).method_11657(HAS_BOTTLE[1], Boolean.FALSE).method_11657(HAS_BOTTLE[2], Boolean.FALSE));
    }

    @Deprecated
    @Override
    public @NotNull class_265 method_9530(class_2680 p_60555_, @NotNull class_1922 p_60556_, @NotNull class_2338 p_60557_, @NotNull class_3726 p_60558_) {
        class_2350 wall = p_60555_.method_11654(MPBlockData.WALL);
        class_2350 facing = p_60555_.method_11654(MPBlockData.FACING);
        boolean hasHook = p_60555_.method_11654(MPBlockData.HOOK) != 8;
        return MPBlockData.getWallMountedShape(wall, facing, hasHook);
    }

    @Override
    public @NotNull List<class_1799> method_9560(@NotNull class_2680 p_287732_, class_8567.@NotNull class_8568 p_287596_) {
        return getItemStacks(p_287732_);
    }

    static @NotNull List<class_1799> getItemStacks(class_2680 p_287732_) {
        List<class_1799> list = Lists.newArrayList();
        class_1799 itemStack = new class_1799(p_287732_.method_26204());
        itemStack.method_7948().method_10569(MPNBTData.ItemType, p_287732_.method_11654(MPBlockData.TYPES));
        list.add(itemStack);
        int hook = p_287732_.method_11654(MPBlockData.HOOK);
        if (hook != 8) {
            itemStack = new class_1799(MPBlockCore.HookBlockItem.get());
            itemStack.method_7948().method_10569(MPNBTData.ItemType, hook);
            list.add(itemStack);
        }
        return list;
    }

    public @NotNull class_1269 method_9534(@NotNull class_2680 p_50930_, class_1937 p_50931_, @NotNull class_2338 p_50932_, @NotNull class_1657 p_50933_, @NotNull class_1268 p_50934_, @NotNull class_3965 p_50935_) {
        if (p_50931_.field_9236) {
            return class_1269.field_5812;
        } else {
            class_2586 blockentity = p_50931_.method_8321(p_50932_);
            if (blockentity instanceof MPBrewingStandBlockEntity) {
                p_50933_.method_17355((MPBrewingStandBlockEntity)blockentity);
                p_50933_.method_7281(class_3468.field_15407);
            }

            return class_1269.field_21466;
        }
    }

    public class_2680 method_9605(class_1750 p_48689_) {
        return this.method_9564().method_11657(MPBlockData.WALL,p_48689_.method_8038().method_10153()).method_11657(MPBlockData.FACING, p_48689_.method_8042().method_10153());
    }


    public @NotNull class_2680 method_9598(class_2680 p_48722_, class_2470 p_48723_) {
        return p_48722_.method_11657(MPBlockData.FACING, p_48723_.method_10503(p_48722_.method_11654(MPBlockData.FACING)));
    }

    public @NotNull class_2680 method_9569(class_2680 p_48719_, class_2415 p_48720_) {
        return p_48719_.method_26186(p_48720_.method_10345(p_48719_.method_11654(MPBlockData.FACING)));
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> p_48725_) {
        p_48725_.method_11667(MPBlockData.FACING, MPBlockData.TYPES,HAS_BOTTLE[0], HAS_BOTTLE[1], HAS_BOTTLE[2], MPBlockData.WALL, MPBlockData.HOOK);
    }

    public class_2586 method_10123(@NotNull class_2338 p_153277_, @NotNull class_2680 p_153278_) {
        return new MPBrewingStandBlockEntity(p_153277_, p_153278_);
    }

    @Nullable
    public <T extends class_2586> class_5558<T> method_31645(class_1937 p_152694_, @NotNull class_2680 p_152695_, @NotNull class_2591<T> p_152696_) {
        return p_152694_.field_9236 ? null : method_31618(p_152696_, MPBlockEntityCore.BREWING_BLOCK_ENTITY.get(), MPBrewingStandBlockEntity::serverTick);
    }


    public void method_9536(class_2680 p_50937_, @NotNull class_1937 p_50938_, @NotNull class_2338 p_50939_, class_2680 p_50940_, boolean p_50941_) {
        if (!p_50937_.method_27852(p_50940_.method_26204())) {
            class_2586 blockentity = p_50938_.method_8321(p_50939_);
            if (blockentity instanceof class_2589) {
                class_1264.method_5451(p_50938_, p_50939_, (class_2589)blockentity);
            }

            super.method_9536(p_50937_, p_50938_, p_50939_, p_50940_, p_50941_);
        }
    }

    public boolean method_9498(@NotNull class_2680 p_50919_) {
        return true;
    }

    public int method_9572(@NotNull class_2680 p_50926_, class_1937 p_50927_, @NotNull class_2338 p_50928_) {
        return class_1703.method_7608(p_50927_.method_8321(p_50928_));
    }

    public boolean method_9516(@NotNull class_2680 p_50921_, @NotNull class_1922 p_50922_, @NotNull class_2338 p_50923_, @NotNull class_10 p_50924_) {
        return false;
    }
}


