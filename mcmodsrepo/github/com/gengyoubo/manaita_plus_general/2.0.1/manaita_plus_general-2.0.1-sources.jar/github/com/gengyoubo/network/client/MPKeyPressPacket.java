package github.com.gengyoubo.network.client;

import github.com.gengyoubo.item.data.IMPKey;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_3222;

public class MPKeyPressPacket {
    private final byte keyCode;

    public MPKeyPressPacket(class_2540 buffer) {
        this.keyCode = buffer.readByte();
    }

    public MPKeyPressPacket(byte keyCode) {
        this.keyCode = keyCode;
    }

    public void write(class_2540 buf) {
        buf.writeByte(keyCode);
    }

    public void handle(class_3222 sender) {
        switch (keyCode) {
            case 0 -> {
                class_1799 mainHandItem = sender.method_6047();
                if (!mainHandItem.method_7960() && mainHandItem.method_7909() instanceof IMPKey keyItem) {
                    keyItem.onManaitaKeyPress(mainHandItem, sender);
                }
            }
            case 1 -> {
                for (class_1799 itemStack : sender.method_31548().field_7548) {
                    if (!itemStack.method_7960() && itemStack.method_7909() instanceof IMPKey keyItem) {
                        keyItem.onManaitaKeyPress(itemStack, sender);
                    }
                }
            }
            default -> {
            }
        }
    }
}
