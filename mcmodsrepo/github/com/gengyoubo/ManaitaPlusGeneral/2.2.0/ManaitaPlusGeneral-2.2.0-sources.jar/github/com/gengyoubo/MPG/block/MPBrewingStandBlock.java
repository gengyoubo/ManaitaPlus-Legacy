package github.com.gengyoubo.MPG.block;

import com.google.common.collect.Lists;
import com.mojang.serialization.MapCodec;
import github.com.gengyoubo.MPG.core.MPGBlockCore;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.stats.Stats;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.NotNull;
import github.com.gengyoubo.MPG.block.data.MPGBlockData;
import github.com.gengyoubo.MPG.block.entity.MPBrewingStandBlockEntity;
import github.com.gengyoubo.MPG.core.MPGBlockEntityCore;
import github.com.gengyoubo.MPG.util.MPGItemStackData;
import github.com.gengyoubo.MPG.util.MPGNBTData;

import javax.annotation.Nullable;
import java.util.List;

@SuppressWarnings("deprecation")
public class MPBrewingStandBlock extends BaseEntityBlock {
    public static final MapCodec<MPBrewingStandBlock> CODEC = simpleCodec(MPBrewingStandBlock::new);
    public static final BooleanProperty[] HAS_BOTTLE = new BooleanProperty[]{BlockStateProperties.HAS_BOTTLE_0, BlockStateProperties.HAS_BOTTLE_1, BlockStateProperties.HAS_BOTTLE_2};

    public MPBrewingStandBlock() {
        this(Properties.of().noOcclusion());
    }

    private MPBrewingStandBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(MPGBlockData.HOOK, 8).setValue(MPGBlockData.FACING, Direction.NORTH).setValue(MPGBlockData.WALL,Direction.DOWN).setValue(MPGBlockData.TYPES,0).setValue(HAS_BOTTLE[0], Boolean.FALSE).setValue(HAS_BOTTLE[1], Boolean.FALSE).setValue(HAS_BOTTLE[2], Boolean.FALSE));
    }

    @Deprecated
    @Override
    public @NotNull VoxelShape getShape(BlockState p_60555_, @NotNull BlockGetter p_60556_, @NotNull BlockPos p_60557_, @NotNull CollisionContext p_60558_) {
        Direction wall = p_60555_.getValue(MPGBlockData.WALL);
        Direction facing = p_60555_.getValue(MPGBlockData.FACING);
        boolean hasHook = p_60555_.getValue(MPGBlockData.HOOK) != 8;
        return MPGBlockData.getWallMountedShape(wall, facing, hasHook);
    }

    @Override
    public @NotNull RenderShape getRenderShape(@NotNull BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    protected @NotNull MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    public @NotNull List<ItemStack> getDrops(@NotNull BlockState p_287732_, LootParams.@NotNull Builder p_287596_) {
        return getItemStacks(p_287732_);
    }

    static @NotNull List<ItemStack> getItemStacks(BlockState p_287732_) {
        List<ItemStack> list = Lists.newArrayList();
        ItemStack itemStack = new ItemStack(p_287732_.getBlock());
        MPGItemStackData.putInt(itemStack, MPGNBTData.ItemType, p_287732_.getValue(MPGBlockData.TYPES));
        list.add(itemStack);
        int hook = p_287732_.getValue(MPGBlockData.HOOK);
        if (hook != 8) {
            itemStack = new ItemStack(MPGBlockCore.HookBlockItem.get());
            MPGItemStackData.putInt(itemStack, MPGNBTData.ItemType, hook);
            list.add(itemStack);
        }
        return list;
    }

    @Override
    protected @NotNull InteractionResult useWithoutItem(@NotNull BlockState p_50930_, Level p_50931_, @NotNull BlockPos p_50932_, @NotNull Player p_50933_, @NotNull BlockHitResult p_50934_) {
        if (p_50931_.isClientSide) {
            return InteractionResult.SUCCESS;
        } else {
            BlockEntity blockentity = p_50931_.getBlockEntity(p_50932_);
            if (blockentity instanceof MPBrewingStandBlockEntity) {
                p_50933_.openMenu((MPBrewingStandBlockEntity)blockentity);
                p_50933_.awardStat(Stats.INTERACT_WITH_BREWINGSTAND);
            }

            return InteractionResult.CONSUME;
        }
    }

    public BlockState getStateForPlacement(BlockPlaceContext p_48689_) {
        return this.defaultBlockState().setValue(MPGBlockData.WALL,p_48689_.getClickedFace().getOpposite()).setValue(MPGBlockData.FACING, p_48689_.getHorizontalDirection().getOpposite());
    }


    public @NotNull BlockState rotate(BlockState p_48722_, Rotation p_48723_) {
        return p_48722_.setValue(MPGBlockData.FACING, p_48723_.rotate(p_48722_.getValue(MPGBlockData.FACING)));
    }

    public @NotNull BlockState mirror(BlockState p_48719_, Mirror p_48720_) {
        return p_48719_.rotate(p_48720_.getRotation(p_48719_.getValue(MPGBlockData.FACING)));
    }

    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> p_48725_) {
        p_48725_.add(MPGBlockData.FACING, MPGBlockData.TYPES,HAS_BOTTLE[0], HAS_BOTTLE[1], HAS_BOTTLE[2], MPGBlockData.WALL, MPGBlockData.HOOK);
    }

    public BlockEntity newBlockEntity(@NotNull BlockPos p_153277_, @NotNull BlockState p_153278_) {
        return new MPBrewingStandBlockEntity(p_153277_, p_153278_);
    }

    @Nullable
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level p_152694_, @NotNull BlockState p_152695_, @NotNull BlockEntityType<T> p_152696_) {
        return p_152694_.isClientSide ? null : createTickerHelper(p_152696_, MPGBlockEntityCore.BREWING_BLOCK_ENTITY.get(), MPBrewingStandBlockEntity::serverTick);
    }


    public void onRemove(BlockState p_50937_, @NotNull Level p_50938_, @NotNull BlockPos p_50939_, BlockState p_50940_, boolean p_50941_) {
        if (!p_50937_.is(p_50940_.getBlock())) {
            BlockEntity blockentity = p_50938_.getBlockEntity(p_50939_);
            if (blockentity instanceof BrewingStandBlockEntity) {
                Containers.dropContents(p_50938_, p_50939_, (BrewingStandBlockEntity)blockentity);
            }

            super.onRemove(p_50937_, p_50938_, p_50939_, p_50940_, p_50941_);
        }
    }

    public boolean hasAnalogOutputSignal(@NotNull BlockState p_50919_) {
        return true;
    }

    public int getAnalogOutputSignal(@NotNull BlockState p_50926_, Level p_50927_, @NotNull BlockPos p_50928_) {
        return AbstractContainerMenu.getRedstoneSignalFromBlockEntity(p_50927_.getBlockEntity(p_50928_));
    }

    public boolean isPathfindable() {
        return false;
    }
}
