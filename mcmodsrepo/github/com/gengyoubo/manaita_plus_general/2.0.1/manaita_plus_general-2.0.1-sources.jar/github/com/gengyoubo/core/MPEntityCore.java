package github.com.gengyoubo.core;

import github.com.gengyoubo.entity.MPGEntityArrow;
import github.com.gengyoubo.entity.MPGLightningBolt;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

import static github.com.gengyoubo.MPG.ENTITY_TYPES;

public class MPEntityCore {
    public static final RegistryObject<class_1299<MPGLightningBolt>> ManaitaLightningBolt =
            register("manaita_lightning_bolt",
                    () -> class_1299.class_1300.method_5903(MPGLightningBolt::new, class_1311.field_17715)
                            .method_5904()
                            .method_17687(0.0F, 0.0F)
                            .method_27299(16)
                            .method_27300(Integer.MAX_VALUE)
                            .method_5905("manaita_lightning_bolt"));
    public static final RegistryObject<class_1299<MPGEntityArrow>> ManaitaArrow =
            register("manaita_arrow",
                    () -> class_1299.class_1300.method_5903(MPGEntityArrow::new, class_1311.field_17715)
                            .method_5904()
                            .method_17687(0.5F, 0.5F)
                            .method_27299(4)
                            .method_27300(20)
                            .method_5905("manaita_arrow"));

    public static void init() {
    }

    @SuppressWarnings("unchecked")
    private static <T extends class_1297> RegistryObject<class_1299<T>> register(String name, Supplier<class_1299<T>> supplier) {
        return (RegistryObject<class_1299<T>>) (RegistryObject<?>) ENTITY_TYPES.register(name, (Supplier<class_1299<?>>) (Supplier<?>) supplier);
    }

}

