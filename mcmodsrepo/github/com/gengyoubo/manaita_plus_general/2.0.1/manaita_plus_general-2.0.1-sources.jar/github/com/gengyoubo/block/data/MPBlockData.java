package github.com.gengyoubo.block.data;

import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2753;
import net.minecraft.class_2758;

public class MPBlockData {
    public static final class_2758 TYPES = class_2758.method_11867("types", 0, 8);
    public static final class_2758 HOOK = class_2758.method_11867("hook", 0, 8);
    public static final class_2753 WALL = class_2753.method_11845("wall", class_2350.field_11043, class_2350.field_11034, class_2350.field_11035, class_2350.field_11039, class_2350.field_11036, class_2350.field_11033);
    public static final class_2753 FACING = class_2383.field_11177;

    public static final class_265 shapeS = class_2248.method_9541(7, 12, 0,9, 14, 2);
    public static final class_265 shapeN = class_2248.method_9541(7, 12, 14,9, 14, 16);
    public static final class_265 shapeE = class_2248.method_9541(0, 12, 7,2, 14, 9);
    public static final class_265 shapeW = class_2248.method_9541(14, 12, 7,16, 14, 9);

    public static final class_265 shapeNORTH = class_2248.method_9541(3, 1, 0, 13, 15, 0.5F);
    public static final class_265 shapeSOUTH = class_2248.method_9541(3, 1, 15.5F, 13, 15, 16F);
    public static final class_265 shapeEAST = class_2248.method_9541(15.5F, 1, 3, 16F, 15, 13);
    public static final class_265 shapeWEST = class_2248.method_9541(0F, 1, 3, 0.5F, 15, 13);
    public static final class_265 shapeUWE = class_2248.method_9541(3, 15.5F, 1, 13, 16F, 15);
    public static final class_265 shapeUNS = class_2248.method_9541(1, 15.5F, 3, 15, 16F, 13);
    public static final class_265 shapeDWE = class_2248.method_9541(3, 0, 1, 13, 0.5F, 15);
    public static final class_265 shapeDNS = class_2248.method_9541(1, 0, 3, 15, 0.5F, 13);

    public static final class_265 shapeAndS = class_259.method_1084(shapeSOUTH,shapeN);
    public static final class_265 shapeAndN = class_259.method_1084(shapeNORTH,shapeS);
    public static final class_265 shapeAndE = class_259.method_1084(shapeEAST,shapeW);
    public static final class_265 shapeAndW = class_259.method_1084(shapeWEST,shapeE);

    public static class_265 getWallMountedShape(class_2350 wall, class_2350 facing, boolean hasHook) {
        return switch (wall) {
            case field_11034 -> hasHook ? shapeAndE : shapeEAST;
            case field_11035 -> hasHook ? shapeAndS : shapeSOUTH;
            case field_11043 -> hasHook ? shapeAndN : shapeNORTH;
            case field_11039 -> hasHook ? shapeAndW : shapeWEST;
            case field_11036 -> facing == class_2350.field_11043 || facing == class_2350.field_11035 ? shapeUNS : shapeUWE;
            case field_11033 -> facing == class_2350.field_11043 || facing == class_2350.field_11035 ? shapeDNS : shapeDWE;
        };
    }
}

