package github.com.gengyoubo.jei;

import net.minecraft.class_1799;

public record MPSourceCopyJeiRecipe(class_1799 input, class_1799 output, int sourceResultCount) {
}
