package github.com.gengyoubo.block.item;

import github.com.gengyoubo.block.MPFurnaceBlock;
import net.minecraft.class_1792;

import static github.com.gengyoubo.core.MPBlockCore.FurnaceBlock;

public class MPFurnaceBlockItem extends MPTypedBlockItem {
    public MPFurnaceBlockItem() {
        super(FurnaceBlock.get(), new class_1792.class_1793().method_24359(), "block.furnace.", MPFurnaceBlock.class);
    }
}

