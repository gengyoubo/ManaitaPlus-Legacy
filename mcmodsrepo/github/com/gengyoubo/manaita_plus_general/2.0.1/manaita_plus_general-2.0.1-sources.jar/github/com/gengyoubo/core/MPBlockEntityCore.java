package github.com.gengyoubo.core;

import net.minecraft.class_2591;
import net.minecraftforge.registries.RegistryObject;
import github.com.gengyoubo.block.entity.MPBrewingStandBlockEntity;
import github.com.gengyoubo.block.entity.MPCraftingBlockEntity;
import github.com.gengyoubo.block.entity.MPFurnaceBlockEntity;

import static github.com.gengyoubo.MPG.BLOCK_ENTITY_TYPES;

public class MPBlockEntityCore {
    public static final RegistryObject<class_2591<MPFurnaceBlockEntity>> FURNACE_BLOCK_ENTITY =
            cast(BLOCK_ENTITY_TYPES.register("furnace_block_entity", () -> buildType(class_2591.class_2592.method_20528(MPFurnaceBlockEntity::new, MPBlockCore.FurnaceBlock.get()))));
    public static final RegistryObject<class_2591<MPBrewingStandBlockEntity>> BREWING_BLOCK_ENTITY =
            cast(BLOCK_ENTITY_TYPES.register("brewing_block_entity", () -> buildType(class_2591.class_2592.method_20528(MPBrewingStandBlockEntity::new, MPBlockCore.BrewingBlock.get()))));
    public static final RegistryObject<class_2591<MPCraftingBlockEntity>> CRAFTING_BLOCK_ENTITY =
            cast(BLOCK_ENTITY_TYPES.register("crafting_entity", () -> buildType(class_2591.class_2592.method_20528(MPCraftingBlockEntity::new, MPBlockCore.CraftingBlock.get()))));

    private static <T extends net.minecraft.class_2586> class_2591<T> buildType(class_2591.class_2592<T> builder) {
        return builder.method_11034(null);
    }

    @SuppressWarnings("unchecked")
    private static <T> RegistryObject<T> cast(RegistryObject<?> value) {
        return (RegistryObject<T>) value;
    }

    public static void init() {
    }

}
