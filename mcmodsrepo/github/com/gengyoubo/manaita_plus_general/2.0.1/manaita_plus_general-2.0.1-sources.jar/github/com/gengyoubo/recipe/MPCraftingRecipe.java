package github.com.gengyoubo.recipe;

import com.google.gson.JsonObject;
import github.com.gengyoubo.MPGConfig;
import github.com.gengyoubo.block.item.MPBrewingBlockItem;
import github.com.gengyoubo.block.item.MPCraftingBlockItem;
import github.com.gengyoubo.block.item.MPFurnaceBlockItem;
import github.com.gengyoubo.block.item.MPHookBlockItem;
import github.com.gengyoubo.core.MPBlockCore;
import github.com.gengyoubo.core.MPItemCore;
import github.com.gengyoubo.core.MPRecipeSerializerCore;
import github.com.gengyoubo.item.MPSourceItem;
import github.com.gengyoubo.util.MPNBTData;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_3955;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;
import org.jetbrains.annotations.NotNull;

public class MPCraftingRecipe implements class_3955 {
    private static final class_1799 SOURCE_RESULT = new class_1799(MPItemCore.ManaitaSource.get());

    private final class_2960 id;
    private final class_7710 category;

    public MPCraftingRecipe(class_2960 id, class_7710 category) {
        this.id = id;
        this.category = category;
    }

    @Override
    public @NotNull class_2960 method_8114() {
        return id;
    }

    @Override
    public @NotNull class_7710 method_45441() {
        return category;
    }

    @Override
    public boolean matches(class_8566 container, @NotNull class_1937 level) {
        int sourceStacks = 0;
        int nonEmptyCount = 0;
        class_1799 otherStack = class_1799.field_8037;
        for (class_1799 stack : container.method_51305()) {
            if (stack.method_7960()) {
                continue;
            }
            nonEmptyCount++;
            if (stack.method_7909() instanceof MPSourceItem) {
                sourceStacks++;
            } else {
                otherStack = stack;
            }
        }

        if (nonEmptyCount != 2 || sourceStacks == 0) {
            return false;
        }

        if (sourceStacks == 2) {
            return true;
        }

        if (!otherStack.method_7960() && !(otherStack.method_7909() instanceof MPSourceItem)) {
            if (!(otherStack.method_7909() instanceof MPCraftingBlockItem)
                    && !(otherStack.method_7909() instanceof MPFurnaceBlockItem)
                    && !(otherStack.method_7909() instanceof MPBrewingBlockItem)
                    && !(otherStack.method_7909() instanceof MPHookBlockItem)) {
                return true;
            }
        }

        boolean hasUpgradeableBlock = false;
        boolean hasPortableBlock = false;
        boolean hasMaterial = false;
        boolean hasHook = false;
        for (class_1799 stack : container.method_51305()) {
            class_1792 item = stack.method_7909();
            if (item instanceof MPHookBlockItem) {
                hasHook = true;
            } else if (item instanceof MPFurnaceBlockItem || item instanceof MPBrewingBlockItem) {
                hasUpgradeableBlock = true;
                hasPortableBlock = true;
            } else if (item instanceof MPCraftingBlockItem) {
                hasPortableBlock = true;
            } else if (item == class_1802.field_8118 || item == class_1802.field_20412 || item == class_1802.field_8773 || item == class_1802.field_8793 || item == class_1802.field_8494 || item == class_1802.field_8603 || item == class_1802.field_8733 || item == class_1802.field_22018) {
                hasMaterial = true;
            }
        }
        return (hasUpgradeableBlock && hasMaterial) || (hasPortableBlock && hasHook);
    }

    @Override
    public @NotNull class_1799 assemble(class_8566 container, @NotNull class_5455 registryAccess) {
        class_1799 material = class_1799.field_8037;
        class_1799 blockInput = class_1799.field_8037;
        class_1799 hookInput = class_1799.field_8037;
        boolean hasSource = false;
        int sourceStacks = 0;
        class_1799 sourceTarget = class_1799.field_8037;

        for (class_1799 stack : container.method_51305()) {
            class_1792 item = stack.method_7909();
            if (item instanceof MPSourceItem) {
                hasSource = true;
                sourceStacks++;
                if (sourceTarget.method_7960()) {
                    sourceTarget = stack;
                }
                continue;
            }
            if (stack.method_7960()) {
                continue;
            }
            if (item instanceof MPHookBlockItem) {
                hookInput = stack;
                continue;
            }
            if (item instanceof MPCraftingBlockItem || item instanceof MPFurnaceBlockItem || item instanceof MPBrewingBlockItem) {
                blockInput = stack;
                continue;
            }
            material = stack;
        }

        if (sourceStacks == 2 && material.method_7960() && blockInput.method_7960() && hookInput.method_7960()) {
            class_1799 copied = sourceTarget.method_7972();
            copied.method_7939(sourceTarget.method_7947() * MPGConfig.source_doubling_value);
            return copied;
        }

        if (hasSource && !material.method_7960() && blockInput.method_7960() && hookInput.method_7960()) {
            class_1799 copied = material.method_7972();
            copied.method_7939(material.method_7947() * MPGConfig.source_doubling_value);
            return copied;
        }

        if (!blockInput.method_7960() && !hookInput.method_7960()) {
            return assemblePortable(blockInput, hookInput);
        }

        if (!material.method_7960() && !blockInput.method_7960()) {
            int type = resolveMaterialType(material.method_7909());
            if (type <= 0) {
                return class_1799.field_8037;
            }
            class_1799 result = createBlockResult(blockInput.method_7909());
            if (result.method_7960()) {
                return class_1799.field_8037;
            }
            result.method_7948().method_10569(MPNBTData.ItemType, type);
            return result;
        }
        return class_1799.field_8037;
    }

    private static class_1799 assemblePortable(class_1799 blockInput, class_1799 hookInput) {
        if (blockInput.method_7948().method_10550(MPNBTData.ItemType) != 0) {
            return class_1799.field_8037;
        }

        class_1799 portable;
        class_1792 item = blockInput.method_7909();
        if (item instanceof MPCraftingBlockItem) {
            portable = new class_1799(MPItemCore.ManaitaCraftingPortable.get());
        } else if (item instanceof MPFurnaceBlockItem) {
            portable = new class_1799(MPItemCore.ManaitaFurnacePortable.get());
        } else if (item instanceof MPBrewingBlockItem) {
            portable = new class_1799(MPItemCore.ManaitaBrewingPortable.get());
        } else {
            return class_1799.field_8037;
        }

        int hookType = hookInput.method_7948().method_10550(MPNBTData.ItemType);
        portable.method_7948().method_10569(MPNBTData.ItemType, hookType + 1);
        return portable;
    }

    private static class_1799 createBlockResult(class_1792 blockItem) {
        if (blockItem instanceof MPFurnaceBlockItem) {
            return new class_1799(MPBlockCore.FurnaceBlockItem.get());
        }
        if (blockItem instanceof MPBrewingBlockItem) {
            return new class_1799(MPBlockCore.BrewingBlockItem.get());
        }
        return class_1799.field_8037;
    }

    private static int resolveMaterialType(class_1792 material) {
        if (material == class_1802.field_8118) return 1;
        if (material == class_1802.field_20412) return 2;
        if (material == class_1802.field_8773) return 3;
        if (material == class_1802.field_8494) return 4;
        if (material == class_1802.field_8603) return 5;
        if (material == class_1802.field_8733) return 6;
        if (material == class_1802.field_8793) return 7;
        if (material == class_1802.field_22018) return 8;
        return -1;
    }

    @Override
    public boolean method_8113(int width, int height) {
        return width * height >= 2;
    }

    @Override
    public @NotNull class_1799 method_8110(@NotNull class_5455 registryAccess) {
        return SOURCE_RESULT;
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return MPRecipeSerializerCore.CraftingRecipe.get();
    }

    public static class Serializer implements class_1865<MPCraftingRecipe> {
        @Override
        public @NotNull MPCraftingRecipe method_8121(@NotNull class_2960 id, @NotNull JsonObject json) {
            class_7710 category = class_7710.field_40252.method_47920(class_3518.method_15253(json, "category", null), class_7710.field_40251);
            return new MPCraftingRecipe(id, category);
        }

        @Override
        public @NotNull MPCraftingRecipe method_8122(@NotNull class_2960 id, class_2540 buf) {
            return new MPCraftingRecipe(id, buf.method_10818(class_7710.class));
        }

        @Override
        public void toNetwork(class_2540 buf, MPCraftingRecipe recipe) {
            buf.method_10817(recipe.category);
        }
    }
}
