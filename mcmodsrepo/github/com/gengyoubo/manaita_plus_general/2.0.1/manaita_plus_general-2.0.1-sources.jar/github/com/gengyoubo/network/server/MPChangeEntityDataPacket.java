package github.com.gengyoubo.network.server;

import github.com.gengyoubo.network.MPNetworking;
import net.minecraft.class_2540;

public class MPChangeEntityDataPacket {
    private final int id;
    private final int flag;

    public MPChangeEntityDataPacket(class_2540 buffer) {
        this.id = buffer.readInt();
        this.flag = buffer.readInt();
    }

    public MPChangeEntityDataPacket(int id, int flag) {
        this.id = id;
        this.flag = flag;
    }

    public class_2540 toBuf() {
        class_2540 buf = MPNetworking.createBuf();
        buf.writeInt(id);
        buf.writeInt(flag);
        return buf;
    }

    public int getId() {
        return id;
    }

    public int getFlag() {
        return flag;
    }
}
