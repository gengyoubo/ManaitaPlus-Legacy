package github.com.gengyoubo.entity;

import github.com.gengyoubo.MPG;
import github.com.gengyoubo.util.MPEntityData;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1667;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2960;
import net.minecraft.class_3966;
import net.minecraft.class_7923;
import org.jetbrains.annotations.NotNull;

public class MPGEntityArrow extends class_1667 {
    private static final class_2960 ENTITY_ID = new class_2960(MPG.MODID, "manaita_arrow");

    public MPGEntityArrow(class_1299<? extends class_1667> entityType, class_1937 level) {
        super(entityType, level);
    }

    public static class_1667 create(class_1937 level, class_1309 owner) {
        class_1667 arrow = null;
        if (class_7923.field_41177.method_10250(ENTITY_ID)) {
            class_1299<?> entityType = class_7923.field_41177.method_10223(ENTITY_ID);
            if (entityType != null) {
                arrow = (class_1667) entityType.method_5883(level);
            }
        }
        if (arrow == null) {
            arrow = new class_1667(level, owner);
        }
        arrow.method_7432(owner);
        arrow.method_5814(owner.method_23317(), owner.method_23320() - 0.1D, owner.method_23321());
        return arrow;
    }

    @Override
    protected @NotNull class_1799 method_7445() {
        return class_1799.field_8037;
    }

    @Override
    protected void method_7454(class_3966 hitResult) {
        class_1297 entity = hitResult.method_17782();
        super.method_7454(hitResult);
        if (!method_37908().field_9236) {
            class_1297 owner = method_24921();
            if (owner instanceof class_1657 player) {
                class_1282 source = entity.method_48923().method_48802(player);
                entity.method_5643(source, 100000.0F);
            } else if (owner instanceof class_1309 living) {
                class_1282 source = entity.method_48923().method_48812(living);
                entity.method_5643(source, 100000.0F);
            }
            MPEntityData.death.add(entity);
        }
    }

    @Override
    protected void method_7488(@NotNull class_239 hitResult) {
        super.method_7488(hitResult);
        method_31472();
    }

    @Override
    public double method_7448() {
        return Double.MAX_VALUE;
    }

    @Override
    public void method_5694(@NotNull class_1657 player) {
    }
}
