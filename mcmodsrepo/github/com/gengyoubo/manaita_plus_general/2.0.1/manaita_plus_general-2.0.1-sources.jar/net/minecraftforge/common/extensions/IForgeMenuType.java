package net.minecraftforge.common.extensions;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2540;
import net.minecraft.class_3917;

public final class IForgeMenuType {
    private IForgeMenuType() {
    }

    public static <T extends class_1703> class_3917<T> create(MenuFactory<T> factory) {
        return new ExtendedScreenHandlerType<>(factory::create);
    }

    @FunctionalInterface
    public interface MenuFactory<T extends class_1703> {
        T create(int syncId, class_1661 inventory, class_2540 buf);
    }
}
