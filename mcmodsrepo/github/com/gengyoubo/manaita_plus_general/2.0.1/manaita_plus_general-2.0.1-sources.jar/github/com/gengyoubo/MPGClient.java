package github.com.gengyoubo;

import github.com.gengyoubo.blockentity.RenderMPBrewingBlockEntity;
import github.com.gengyoubo.blockentity.RenderMPCraftingBlockEntity;
import github.com.gengyoubo.blockentity.RenderMPFurnaceBlockEntity;
import github.com.gengyoubo.core.MPBlockEntityCore;
import github.com.gengyoubo.core.MPMenuCore;
import github.com.gengyoubo.entity.RenderMPGArrow;
import github.com.gengyoubo.gui.MPBrewingStandScreen;
import github.com.gengyoubo.gui.MPCraftingScreen;
import github.com.gengyoubo.gui.MPFurnaceScreen;
import github.com.gengyoubo.network.MPClientPacketHandlers;
import github.com.gengyoubo.network.MPNetworking;
import github.com.gengyoubo.network.server.MPChangeEntityDataPacket;
import github.com.gengyoubo.network.server.MPDestroyBlockPacket;
import github.com.gengyoubo.util.MPNBTData;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3929;
import net.minecraft.class_5272;
import net.minecraft.class_5616;
import net.minecraft.class_7923;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;

public class MPGClient implements ClientModInitializer {
    private static final class_2960 TYPE_PREDICATE = new class_2960(MPG.MODID, MPNBTData.Type);
    private static final String[] TYPE_ITEMS = {
            "block_crafting_manaita",
            "block_furnace_manaita",
            "block_brewing_manaita",
            "block_hook_manaita",
            "manaita_crafting_portable",
            "manaita_furnace_portable",
            "manaita_brewing_portable"
    };
    private static boolean predicatesRegistered;

    @Override
    public void onInitializeClient() {
        registerTypePredicates();
        MPGKeyBindings.init();
        class_3929.method_17542(MPMenuCore.CraftingManaita.get(), MPCraftingScreen::new);
        class_3929.method_17542(MPMenuCore.FurnaceManaita.get(), MPFurnaceScreen::new);
        class_3929.method_17542(MPMenuCore.BrewingStandManaita.get(), MPBrewingStandScreen::new);
        class_5616.method_32144(MPBlockEntityCore.CRAFTING_BLOCK_ENTITY.get(), RenderMPCraftingBlockEntity::new);
        class_5616.method_32144(MPBlockEntityCore.FURNACE_BLOCK_ENTITY.get(), RenderMPFurnaceBlockEntity::new);
        class_5616.method_32144(MPBlockEntityCore.BREWING_BLOCK_ENTITY.get(), RenderMPBrewingBlockEntity::new);
        registerEntityRenderers();
        ClientPlayNetworking.registerGlobalReceiver(MPNetworking.DESTROY_BLOCK, (client, handler, buf, responseSender) -> {
            MPDestroyBlockPacket packet = new MPDestroyBlockPacket(buf);
            client.execute(() -> MPClientPacketHandlers.handleDestroyBlock(packet));
        });
        ClientPlayNetworking.registerGlobalReceiver(MPNetworking.CHANGE_ENTITY_DATA, (client, handler, buf, responseSender) -> {
            MPChangeEntityDataPacket packet = new MPChangeEntityDataPacket(buf);
            client.execute(() -> MPClientPacketHandlers.handleChangeEntityData(packet));
        });
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> registerTypePredicates());
    }

    private static void registerTypePredicates() {
        if (predicatesRegistered) {
            return;
        }

        for (String itemPath : TYPE_ITEMS) {
            class_2960 id = new class_2960(MPG.MODID, itemPath);
            class_1792 item = class_7923.field_41178.method_10223(id);
            if (item == net.minecraft.class_1802.field_8162) {
                MPG.LOGGER.warn("Skipped predicate registration for missing item {}", id);
                continue;
            }
            class_5272.method_27879(item, TYPE_PREDICATE, MPGClient::readTypeValue);
            MPG.LOGGER.info("Registered type predicate {} for {}", TYPE_PREDICATE, id);
        }

        predicatesRegistered = true;
    }

    @SuppressWarnings("unchecked")
    private static void registerEntityRenderers() {
        class_2960 arrowId = new class_2960(MPG.MODID, "manaita_arrow");
        if (!class_7923.field_41177.method_10250(arrowId)) {
            MPG.LOGGER.warn("Skipped renderer registration for missing entity {}", arrowId);
            return;
        }
        class_1299<?> entityType = class_7923.field_41177.method_10223(arrowId);
        EntityRendererRegistry.register((class_1299<? extends github.com.gengyoubo.entity.MPGEntityArrow>) entityType, RenderMPGArrow::new);
    }

    private static float readTypeValue(class_1799 stack, net.minecraft.class_638 level, net.minecraft.class_1309 entity, int seed) {
        if (!stack.method_7985() || stack.method_7969() == null) {
            return 0.0F;
        }
        return normalizeTypeValue(stack.method_7969().method_10550(MPNBTData.ItemType));
    }

    private static float normalizeTypeValue(int type) {
        return switch (type) {
            case 1, 2, 3, 4, 5, 6, 7, 8 -> type / 8.0F;
            default -> 0.0F;
        };
    }
}
