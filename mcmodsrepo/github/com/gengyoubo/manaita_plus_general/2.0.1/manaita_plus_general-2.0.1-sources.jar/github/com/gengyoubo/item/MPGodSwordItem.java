package github.com.gengyoubo.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import github.com.gengyoubo.item.data.IMPDoubling;
import github.com.gengyoubo.item.data.IMPKey;
import github.com.gengyoubo.item.tier.MPToolTier;
import github.com.gengyoubo.network.MPNetworking;
import github.com.gengyoubo.network.server.MPChangeEntityDataPacket;
import github.com.gengyoubo.util.MPEntityData;
import github.com.gengyoubo.util.MPNBTData;
import github.com.gengyoubo.util.MPText;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1303;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1311;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1538;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_5134;

public class MPGodSwordItem extends class_1829 implements IMPKey, IMPDoubling {
    private final Multimap<class_1320, class_1322> defaultModifiers;

    public MPGodSwordItem() {
        super(new MPToolTier(), 0, 0, new class_1792.class_1793().method_24359());
        ImmutableMultimap.Builder<class_1320, class_1322> builder = ImmutableMultimap.builder();
        builder.put(class_5134.field_23721, new class_1322(field_8006, "Weapon modifier", Double.POSITIVE_INFINITY, class_1322.class_1323.field_6328));
        builder.put(class_5134.field_23723, new class_1322(field_8001, "Weapon modifier", Double.POSITIVE_INFINITY, class_1322.class_1323.field_6328));
        this.defaultModifiers = builder.build();
    }

    @Override
    public void method_7888(@NotNull class_1799 stack, @NotNull class_1937 level, @NotNull class_1297 entity, int slot, boolean selected) {
        if (entity instanceof class_1657 player) {
            player.method_31549().field_7478 = true;
            player.method_6033(player.method_6063());
        }
        MPEntityData.manaita.add(entity);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, @NotNull class_1268 hand) {
        class_1799 itemStack = player.method_5998(hand);
        player.method_6019(hand);
        if (!level.field_9236) {
            summonLightning(level, player.method_19538());
            godKill(player, isRemove(itemStack), player.method_5715());
        }
        return class_1271.method_29237(itemStack, level.field_9236);
    }

    @Override
    public boolean method_7873(@NotNull class_1799 stack, @NotNull class_1309 target, @NotNull class_1309 attacker) {
        if (attacker instanceof class_1657 player && !player.method_37908().field_9236) {
            attack(target, player, isRemove(stack));
            godKill(player, isRemove(stack), player.method_5715());
        }
        return super.method_7873(stack, target, attacker);
    }

    @Override
    public @NotNull Multimap<class_1320, class_1322> method_7844(@NotNull class_1304 slot) {
        return slot == class_1304.field_6173 ? this.defaultModifiers : super.method_7844(slot);
    }

    @Override
    public void method_7851(@NotNull class_1799 stack, @Nullable class_1937 level, @NotNull List<class_2561> tooltip, @NotNull class_1836 flag) {
        super.method_7851(stack, level, tooltip, flag);
        tooltip.add(class_2561.method_43470(MPText.manaita_mode.formatting(class_2561.method_43471("mode.doubling").getString() + ":" + (isDoubling(stack) ? class_2561.method_43471("info.on").getString() : class_2561.method_43471("info.off").getString()))));
        tooltip.add(class_2561.method_43470(MPText.manaita_mode.formatting(class_2561.method_43471("mode.remove.name").getString() + ":" + (isRemove(stack) ? class_2561.method_43471("info.on").getString() : class_2561.method_43471("info.off").getString()))));
        tooltip.add(class_2561.method_43473());
        tooltip.add(class_2561.method_43470(MPText.manaita_enchantment.formatting(class_2561.method_43471("info.item.manaita_sword_god.1").getString())));
    }

    @Override
    public @NotNull class_2561 method_7864(@NotNull class_1799 stack) {
        return class_2561.method_43470(MPText.manaita_infinity.formatting(class_2561.method_43471("item.manaita_sword_god.name").getString()));
    }

    @Override
    public int method_7881(@NotNull class_1799 stack) {
        return 72000;
    }

    @Override
    public @NotNull class_1839 method_7853(@NotNull class_1799 stack) {
        return class_1839.field_8949;
    }

    @Override
    public boolean method_7886(@NotNull class_1799 stack) {
        return true;
    }

    @Override
    public boolean method_7870(@NotNull class_1799 stack) {
        return true;
    }

    @Override
    public void onManaitaKeyPress(class_1799 itemStack) {
        toggleDoubling(itemStack);
    }

    @Override
    public void onManaitaKeyPressOnClient(class_1799 itemStack, class_1657 player) {
        if (player.method_5715()) {
            boolean remove = !isRemove(itemStack);
            setRemove(itemStack, remove);
            player.method_7353(class_2561.method_43470(MPText.manaita_mode.formatting(String.format("[%s] %s: %s",
                    class_2561.method_43471("item.manaita_sword_god.name").getString(),
                    class_2561.method_43471("mode.remove.name").getString(),
                    remove ? class_2561.method_43471("info.on").getString() : class_2561.method_43471("info.off").getString()))), true);
        } else {
            boolean doubling = toggleDoubling(itemStack);
            player.method_7353(class_2561.method_43470(MPText.manaita_mode.formatting(String.format("[%s] %s: %s",
                    class_2561.method_43471("item.manaita_sword_god.name").getString(),
                    class_2561.method_43471("mode.doubling").getString(),
                    doubling ? class_2561.method_43471("info.on").getString() : class_2561.method_43471("info.off").getString()))), true);
        }
    }

    public static boolean isRemove(class_1799 itemStack) {
        if (!itemStack.method_7985()) {
            return false;
        }
        return itemStack.method_7969() != null && itemStack.method_7969().method_10577(MPNBTData.Remove);
    }

    public static void setRemove(class_1799 itemStack, boolean remove) {
        itemStack.method_7948().method_10556(MPNBTData.Remove, remove);
    }

    private static void godKill(class_1657 player, boolean remove, boolean includeEverything) {
        if (!(player.method_37908() instanceof class_3218 serverLevel)) {
            return;
        }

        List<class_1297> pickups = new ArrayList<>();
        for (class_1297 entity : serverLevel.method_27909()) {
            if (entity == player || !entity.method_5805()) {
                continue;
            }

            if (entity instanceof class_1542 || entity instanceof class_1303) {
                pickups.add(entity);
                continue;
            }

            if (!includeEverything && entity.method_5864().method_5891() != class_1311.field_6302) {
                continue;
            }

            attack(entity, player, remove);
        }

        for (class_1297 entity : pickups) {
            if (entity instanceof class_1542 itemEntity) {
                itemEntity.method_6975();
                itemEntity.method_5694(player);
            } else if (entity instanceof class_1303 experienceOrb) {
                player.field_7504 = 0;
                experienceOrb.method_5694(player);
            }
        }
    }

    private static void attack(class_1297 target, class_1657 player, boolean remove) {
        if (target == null || !target.method_5805()) {
            return;
        }

        MPEntityData.death.add(target);
        MPNetworking.sendToSameLevelPlayers(player.method_37908(), new MPChangeEntityDataPacket(target.method_5628(), MPEntityData.death.getFlag()));

        if (remove) {
            MPEntityData.remove.add(target);
            MPNetworking.sendToSameLevelPlayers(player.method_37908(), new MPChangeEntityDataPacket(target.method_5628(), MPEntityData.remove.getFlag()));
            target.method_31472();
            return;
        }

        if (target instanceof class_1309 living) {
            living.method_5643(living.method_48923().method_48802(player), Float.MAX_VALUE);
            living.method_6033(0.0F);
            living.method_6078(living.method_48923().method_48830());
        } else {
            target.method_31472();
        }
    }

    private static void summonLightning(class_1937 level, class_243 position) {
        Random random = new Random();
        for (int i = 0; i < 100; i++) {
            class_1538 bolt = net.minecraft.class_1299.field_6112.method_5883(level);
            if (bolt == null) {
                continue;
            }

            float angle = random.nextFloat() * 62.831852F;
            double distance = random.nextGaussian() * 100.0D;
            double x = class_3532.method_15374(angle) * distance + position.field_1352;
            double z = class_3532.method_15362(angle) * distance + position.field_1350;
            int y = level.method_8624(class_2902.class_2903.field_13194, (int) x, (int) z);

            bolt.method_5814(x, y, z);
            level.method_8649(bolt);
        }
    }
}
