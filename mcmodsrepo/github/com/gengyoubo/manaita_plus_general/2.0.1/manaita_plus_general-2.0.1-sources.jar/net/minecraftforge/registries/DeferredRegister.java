package net.minecraftforge.registries;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;

public final class DeferredRegister<T> {
    private final class_2378<T> registry;
    private final String modId;
    private final List<Entry<T>> entries = new ArrayList<>();

    private DeferredRegister(class_2378<T> registry, String modId) {
        this.registry = registry;
        this.modId = modId;
    }

    public static <T> DeferredRegister<T> create(class_2378<T> registry, String modId) {
        return new DeferredRegister<>(registry, modId);
    }

    public RegistryObject<T> register(String path, Supplier<T> supplier) {
        RegistryObject<T> object = new RegistryObject<>(modId + ":" + path, supplier);
        entries.add(new Entry<>(path, object));
        return object;
    }

    public void registerAll() {
        for (Entry<T> entry : entries) {
            entry.object.initialize();
            class_2378.method_10230(registry, new class_2960(modId, entry.path), entry.object.get());
        }
    }

    private record Entry<T>(String path, RegistryObject<T> object) {
    }
}
