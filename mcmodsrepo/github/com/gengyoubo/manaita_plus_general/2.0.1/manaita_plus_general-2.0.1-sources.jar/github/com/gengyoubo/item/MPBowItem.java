package github.com.gengyoubo.item;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import github.com.gengyoubo.entity.MPGEntityArrow;
import github.com.gengyoubo.item.data.IMPDoubling;
import github.com.gengyoubo.item.data.IMPKey;
import github.com.gengyoubo.util.MPText;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class MPBowItem extends class_1792 implements IMPKey, IMPDoubling {
    private static final int CHARGE_TICKS = 10;
    private static final int RAPID_FIRE_INTERVAL = 2;

    public MPBowItem() {
        super(new class_1793().method_7898(-1).method_24359());
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, @NotNull class_1657 player, @NotNull class_1268 hand) {
        class_1799 heldItem = player.method_5998(hand);
        player.method_6019(hand);
        return class_1271.method_22428(heldItem);
    }

    @Override
    public void method_7852(class_1937 level, @NotNull class_1309 livingEntity, @NotNull class_1799 stack, int remainingUseDuration) {
        if (level.field_9236 || !(livingEntity instanceof class_1657 player)) {
            return;
        }

        int elapsed = method_7881(stack) - remainingUseDuration;
        if (elapsed < CHARGE_TICKS) {
            return;
        }
        if ((elapsed - CHARGE_TICKS) % RAPID_FIRE_INTERVAL != 0) {
            return;
        }

        shootArrow(level, player, stack, player.method_6058());
    }

    @Override
    public int method_7881(@NotNull class_1799 stack) {
        return 72000;
    }

    @Override
    public @NotNull class_1839 method_7853(@NotNull class_1799 stack) {
        return class_1839.field_8953;
    }

    @Override
    public void method_7851(@NotNull class_1799 stack, @Nullable class_1937 level, List<class_2561> tooltip, @NotNull class_1836 flag) {
        tooltip.add(class_2561.method_43470(MPText.manaita_mode.formatting(class_2561.method_43471("mode.doubling").getString() + ":" + (isDoubling(stack) ? class_2561.method_43471("info.on").getString() : class_2561.method_43471("info.off").getString()))));
        tooltip.add(class_2561.method_43470(MPText.manaita_infinity.formatting(class_2561.method_43471("info.attack").getString())));
    }

    @Override
    public @NotNull class_2561 method_7864(@NotNull class_1799 stack) {
        return class_2561.method_43470(MPText.manaita_mode.formatting(class_2561.method_43471("item.manaita_bow.name").getString()));
    }

    @Override
    public void onManaitaKeyPress(class_1799 itemStack) {
        toggleDoubling(itemStack);
    }

    @Override
    public void onManaitaKeyPressOnClient(class_1799 itemStack, class_1657 player) {
        boolean doubling = toggleDoubling(itemStack);
        player.method_7353(class_2561.method_43470(String.format("[%s%s] %s%s: %s", MPText.manaita_mode.formatting(class_2561.method_43471("item.manaita_bow.name").getString()), class_124.field_1070, class_124.field_1070, class_2561.method_43471("mode.doubling").getString(), (doubling ? class_2561.method_43471("info.on").getString() : class_2561.method_43471("info.off").getString()))), true);
    }

    private void shootArrow(class_1937 level, class_1657 player, class_1799 stack, class_1268 hand) {
        class_1665 abstractArrow = MPGEntityArrow.create(level, player);
        abstractArrow.method_24919(player, player.method_36455(), player.method_36454(), 0.0F, 10.0F, 1.0F);
        abstractArrow.method_7439(true);
        abstractArrow.method_7438(isDoubling(stack) ? 40.0D : 20.0D);
        abstractArrow.method_5803(true);
        level.method_8649(abstractArrow);
        stack.method_7956(1, player, p -> p.method_20236(hand));
    }
}
