package github.com.gengyoubo.recipe;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import github.com.gengyoubo.core.MPRecipeSerializerCore;
import github.com.gengyoubo.util.MPNBTData;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_3955;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;

public class MPNBTCraftingRecipe implements class_3955 {
    private final class_2960 id;
    private final String group;
    private final class_7710 category;
    private final int width;
    private final int height;
    private final IngredientSpec[] ingredients;
    private final class_1799 result;
    private final boolean showNotification;

    public MPNBTCraftingRecipe(class_2960 id, String group, class_7710 category, int width, int height, IngredientSpec[] ingredients, class_1799 result, boolean showNotification) {
        this.id = id;
        this.group = group;
        this.category = category;
        this.width = width;
        this.height = height;
        this.ingredients = ingredients;
        this.result = result;
        this.showNotification = showNotification;
    }

    @Override
    public @NotNull class_2960 method_8114() {
        return id;
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return MPRecipeSerializerCore.NBTCraftingRecipe.get();
    }

    @Override
    public @NotNull String method_8112() {
        return group;
    }

    @Override
    public @NotNull class_7710 method_45441() {
        return category;
    }

    @Override
    public @NotNull class_1799 method_8110(@NotNull class_5455 registryAccess) {
        return result.method_7972();
    }

    public boolean method_49188() {
        return showNotification;
    }

    @Override
    public boolean method_8113(int gridWidth, int gridHeight) {
        return gridWidth >= width && gridHeight >= height;
    }

    @Override
    public boolean matches(class_8566 container, @NotNull class_1937 level) {
        for (int x = 0; x <= container.method_17398() - width; ++x) {
            for (int y = 0; y <= container.method_17397() - height; ++y) {
                if (matches(container, x, y, true) || matches(container, x, y, false)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean matches(class_8566 container, int offsetX, int offsetY, boolean mirrored) {
        for (int x = 0; x < container.method_17398(); ++x) {
            for (int y = 0; y < container.method_17397(); ++y) {
                int patternX = x - offsetX;
                int patternY = y - offsetY;
                IngredientSpec expected = IngredientSpec.EMPTY;
                if (patternX >= 0 && patternY >= 0 && patternX < width && patternY < height) {
                    if (mirrored) {
                        expected = ingredients[width - patternX - 1 + patternY * width];
                    } else {
                        expected = ingredients[patternX + patternY * width];
                    }
                }

                if (!expected.test(container.method_5438(x + y * container.method_17398()))) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public @NotNull class_1799 assemble(@NotNull class_8566 container, @NotNull class_5455 registryAccess) {
        return result.method_7972();
    }

    public static class Serializer implements class_1865<MPNBTCraftingRecipe> {
        @Override
        public @NotNull MPNBTCraftingRecipe method_8121(@NotNull class_2960 id, @NotNull JsonObject json) {
            String group = class_3518.method_15253(json, "group", "");
            class_7710 category = class_7710.field_40252.method_47920(class_3518.method_15253(json, "category", null), class_7710.field_40251);
            String[] pattern = shrink(patternFromJson(class_3518.method_15261(json, "pattern")));
            if (pattern.length == 0) {
                throw new JsonSyntaxException("Invalid pattern: empty pattern not allowed");
            }
            int width = pattern[0].length();
            int height = pattern.length;
            Map<Character, IngredientSpec> key = keyFromJson(class_3518.method_15296(json, "key"));
            IngredientSpec[] ingredients = dissolvePattern(pattern, key, width, height);
            class_1799 result = resultFromJson(class_3518.method_15296(json, "result"));
            boolean showNotification = class_3518.method_15258(json, "show_notification", true);
            return new MPNBTCraftingRecipe(id, group, category, width, height, ingredients, result, showNotification);
        }

        @Override
        public @NotNull MPNBTCraftingRecipe method_8122(@NotNull class_2960 id, class_2540 buf) {
            int width = buf.method_10816();
            int height = buf.method_10816();
            String group = buf.method_19772();
            class_7710 category = buf.method_10818(class_7710.class);
            IngredientSpec[] ingredients = new IngredientSpec[width * height];
            for (int i = 0; i < ingredients.length; i++) {
                ingredients[i] = IngredientSpec.fromNetwork(buf);
            }
            class_1799 result = buf.method_10819();
            boolean showNotification = buf.readBoolean();
            return new MPNBTCraftingRecipe(id, group, category, width, height, ingredients, result, showNotification);
        }

        @Override
        public void toNetwork(class_2540 buf, MPNBTCraftingRecipe recipe) {
            buf.method_10804(recipe.width);
            buf.method_10804(recipe.height);
            buf.method_10814(recipe.group);
            buf.method_10817(recipe.category);
            for (IngredientSpec ingredient : recipe.ingredients) {
                ingredient.toNetwork(buf);
            }
            buf.method_10793(recipe.result);
            buf.writeBoolean(recipe.showNotification);
        }

        private static class_1799 resultFromJson(JsonObject json) {
            class_1799 stack = new class_1799(net.minecraft.class_1869.method_8155(json), class_3518.method_15282(json, "count", 1));
            if (json.has("nbt")) {
                JsonObject nbt = class_3518.method_15296(json, "nbt");
                int type = readType(nbt);
                if (type >= 0) {
                    stack.method_7948().method_10569(MPNBTData.ItemType, type);
                }
            }
            return stack;
        }

        private static int readType(JsonObject json) {
            if (json.has(MPNBTData.ItemType)) {
                return class_3518.method_15260(json, MPNBTData.ItemType);
            }
            if (json.has("ManaitaPlusLegacyType")) {
                return class_3518.method_15260(json, "ManaitaPlusLegacyType");
            }
            if (json.has("ManaitaType")) {
                return class_3518.method_15260(json, "ManaitaType");
            }
            return -1;
        }

        private static IngredientSpec[] dissolvePattern(String[] pattern, Map<Character, IngredientSpec> key, int width, int height) {
            IngredientSpec[] ingredients = new IngredientSpec[width * height];
            Arrays.fill(ingredients, IngredientSpec.EMPTY);
            Map<Character, IngredientSpec> remaining = new HashMap<>(key);
            remaining.remove(' ');

            for (int y = 0; y < pattern.length; ++y) {
                for (int x = 0; x < pattern[y].length(); ++x) {
                    char symbol = pattern[y].charAt(x);
                    IngredientSpec ingredient = key.get(symbol);
                    if (ingredient == null) {
                        throw new JsonSyntaxException("Pattern references symbol '" + symbol + "' but it's not defined in the key");
                    }
                    remaining.remove(symbol);
                    ingredients[x + width * y] = ingredient;
                }
            }

            if (!remaining.isEmpty()) {
                throw new JsonSyntaxException("Key defines symbols that aren't used in pattern: " + remaining.keySet());
            }
            return ingredients;
        }

        private static Map<Character, IngredientSpec> keyFromJson(JsonObject json) {
            Map<Character, IngredientSpec> map = new HashMap<>();
            for (Map.Entry<String, JsonElement> entry : json.entrySet()) {
                if (entry.getKey().length() != 1) {
                    throw new JsonSyntaxException("Invalid key entry: '" + entry.getKey() + "' is an invalid symbol");
                }
                char symbol = entry.getKey().charAt(0);
                if (symbol == ' ') {
                    throw new JsonSyntaxException("Invalid key entry: ' ' is a reserved symbol.");
                }
                map.put(symbol, IngredientSpec.fromJson(class_3518.method_15295(entry.getValue(), "key")));
            }
            map.put(' ', IngredientSpec.EMPTY);
            return map;
        }

        private static String[] patternFromJson(JsonArray json) {
            String[] pattern = new String[json.size()];
            if (pattern.length == 0) {
                throw new JsonSyntaxException("Invalid pattern: empty pattern not allowed");
            }
            if (pattern.length > 3) {
                throw new JsonSyntaxException("Invalid pattern: too many rows, 3 is maximum");
            }

            for (int i = 0; i < pattern.length; ++i) {
                String row = class_3518.method_15287(json.get(i), "pattern[" + i + "]");
                if (row.length() > 3) {
                    throw new JsonSyntaxException("Invalid pattern: too many columns, 3 is maximum");
                }
                if (i > 0 && pattern[0].length() != row.length()) {
                    throw new JsonSyntaxException("Invalid pattern: each row must be the same width");
                }
                pattern[i] = row;
            }
            return pattern;
        }

        private static String[] shrink(String... pattern) {
            int firstColumn = Integer.MAX_VALUE;
            int lastColumn = 0;
            int leadingEmptyRows = 0;
            int trailingEmptyRows = 0;

            for (int row = 0; row < pattern.length; ++row) {
                String line = pattern[row];
                firstColumn = Math.min(firstColumn, firstNonSpace(line));
                int last = lastNonSpace(line);
                lastColumn = Math.max(lastColumn, last);
                if (last < 0) {
                    if (leadingEmptyRows == row) {
                        ++leadingEmptyRows;
                    }
                    ++trailingEmptyRows;
                } else {
                    trailingEmptyRows = 0;
                }
            }

            if (pattern.length == trailingEmptyRows) {
                return new String[0];
            }

            String[] shrunk = new String[pattern.length - trailingEmptyRows - leadingEmptyRows];
            for (int i = 0; i < shrunk.length; ++i) {
                shrunk[i] = pattern[i + leadingEmptyRows].substring(firstColumn, lastColumn + 1);
            }
            return shrunk;
        }

        private static int firstNonSpace(String line) {
            int i = 0;
            while (i < line.length() && line.charAt(i) == ' ') {
                i++;
            }
            return i;
        }

        private static int lastNonSpace(String line) {
            int i = line.length() - 1;
            while (i >= 0 && line.charAt(i) == ' ') {
                --i;
            }
            return i;
        }
    }

    private record IngredientSpec(class_1856 ingredient, int requiredType) {
        private static final IngredientSpec EMPTY = new IngredientSpec(class_1856.field_9017, Integer.MIN_VALUE);

        private boolean test(class_1799 stack) {
            if (this == EMPTY) {
                return stack.method_7960();
            }
            if (!ingredient.method_8093(stack)) {
                return false;
            }
            if (requiredType == Integer.MIN_VALUE) {
                return true;
            }
            return stack.method_7985() && stack.method_7969().method_10550(MPNBTData.ItemType) == requiredType;
        }

        private void toNetwork(class_2540 buf) {
            ingredient.method_8088(buf);
            buf.writeInt(requiredType);
        }

        private static IngredientSpec fromNetwork(class_2540 buf) {
            return new IngredientSpec(class_1856.method_8086(buf), buf.readInt());
        }

        private static IngredientSpec fromJson(JsonObject json) {
            class_1856 ingredient = class_1856.method_52177(json);
            int requiredType = Integer.MIN_VALUE;
            if (json.has("type")) {
                requiredType = class_3518.method_15260(json, "type");
            }
            return new IngredientSpec(ingredient, requiredType);
        }
    }
}
