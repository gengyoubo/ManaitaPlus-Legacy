package github.com.gengyoubo.menu;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1662;
import net.minecraft.class_1703;
import net.minecraft.class_1715;
import net.minecraft.class_1729;
import net.minecraft.class_1731;
import net.minecraft.class_1734;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2653;
import net.minecraft.class_3222;
import net.minecraft.class_3914;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_5421;
import net.minecraft.class_8566;
import net.minecraft.world.inventory.*;
import org.jetbrains.annotations.NotNull;
import github.com.gengyoubo.MPGConfig;
import github.com.gengyoubo.core.MPBlockCore;
import github.com.gengyoubo.core.MPMenuCore;

import java.util.Optional;

public class MPCraftingMenu extends class_1729<class_8566> {
    private final class_8566 craftSlots = new class_1715(this, 3, 3);
    private final class_1731 resultSlots = new class_1731();
    private final class_3914 access;
    private final class_1657 player;
    private boolean stillValid = false;

    @SuppressWarnings("unused")
    public MPCraftingMenu(int p_39353_, class_1661 p_39354_, class_2540 extraData) {
        this(p_39353_, p_39354_, class_3914.method_17392(p_39354_.field_7546.method_37908(), extraData.method_10811()));
        stillValid = true;
    }

    public MPCraftingMenu(int p_39353_, class_1661 p_39354_, class_1937 level) {
        this(p_39353_, p_39354_, class_3914.method_17392(level, class_2338.field_10980));
        stillValid = true;
    }

    public MPCraftingMenu(int p_39356_, class_1661 p_39357_, class_3914 p_39358_) {
        super(MPMenuCore.CraftingManaita.get(), p_39356_);
        this.access = p_39358_;
        this.player = p_39357_.field_7546;
        this.method_7621(new class_1734(p_39357_.field_7546, this.craftSlots, this.resultSlots, 0, 124, 35));

        for(int i = 0; i < 3; ++i) {
            for(int j = 0; j < 3; ++j) {
                this.method_7621(new class_1735(this.craftSlots, j + i * 3, 30 + j * 18, 17 + i * 18));
            }
        }

        for(int k = 0; k < 3; ++k) {
            for(int i1 = 0; i1 < 9; ++i1) {
                this.method_7621(new class_1735(p_39357_, i1 + k * 9 + 9, 8 + i1 * 18, 84 + k * 18));
            }
        }

        for(int l = 0; l < 9; ++l) {
            this.method_7621(new class_1735(p_39357_, l, 8 + l * 18, 142));
        }

    }

    protected static void slotChangedCraftingGrid(class_1703 p_150547_, class_1937 p_150548_, class_1657 p_150549_, class_8566 p_150550_, class_1731 p_150551_) {
        if (!p_150548_.field_9236) {
            if (p_150548_.method_8503() == null) {
                return;
            }
            class_3222 serverplayer = (class_3222) p_150549_;
            class_1799 itemstack = class_1799.field_8037;
            Optional<class_3955> optional = p_150548_.method_8503().method_3772().method_8132(class_3956.field_17545, p_150550_, p_150548_);
            if (optional.isPresent()) {
                class_3955 craftingrecipe = optional.get();
                p_150551_.method_7662(craftingrecipe);
                class_1799 itemstack1 = craftingrecipe.method_8116(p_150550_, p_150548_.method_30349());
                if (itemstack1.method_45435(p_150548_.method_45162())) {
                    itemstack = itemstack1;
                    itemstack.method_7939(itemstack.method_7947() * MPGConfig.crafting_doubling_value);
                }
            }

            p_150551_.method_5447(0, itemstack);
            p_150547_.method_34245(0, itemstack);
            serverplayer.field_13987.method_14364(new class_2653(p_150547_.field_7763, p_150547_.method_37422(), 0, itemstack));
        }
    }

    public void method_7609(@NotNull class_1263 p_39366_) {
        this.access.method_17393((p_39386_, p_39387_) -> slotChangedCraftingGrid(this, p_39386_, this.player, this.craftSlots, this.resultSlots));
    }

    public void method_7654(@NotNull class_1662 p_39374_) {
        this.craftSlots.method_7683(p_39374_);
    }

    public void method_7657() {
        this.craftSlots.method_5448();
        this.resultSlots.method_5448();
    }

    public boolean method_7652(class_1860<? super class_8566> p_39384_) {
        return p_39384_.method_8115(this.craftSlots, this.player.method_37908());
    }

    public void method_7595(@NotNull class_1657 p_39389_) {
        super.method_7595(p_39389_);
        this.access.method_17393((p_39371_, p_39372_) -> this.method_7607(p_39389_, this.craftSlots));
    }

    public @NotNull class_1799 method_7601(@NotNull class_1657 p_39391_, int p_39392_) {
        class_1799 itemstack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(p_39392_);
        if (slot.method_7681()) {
            class_1799 itemstack1 = slot.method_7677();
            itemstack = itemstack1.method_7972();
            if (p_39392_ == 0) {
                this.access.method_17393((p_39378_, p_39379_) -> itemstack1.method_7909().method_7843(itemstack1, p_39378_, p_39391_));
                if (!this.method_7616(itemstack1, 10, 46, true)) {
                    return class_1799.field_8037;
                }

                slot.method_7670(itemstack1, itemstack);
            } else if (p_39392_ >= 10 && p_39392_ < 46) {
                if (!this.method_7616(itemstack1, 1, 10, false)) {
                    if (p_39392_ < 37) {
                        if (!this.method_7616(itemstack1, 37, 46, false)) {
                            return class_1799.field_8037;
                        }
                    } else if (!this.method_7616(itemstack1, 10, 37, false)) {
                        return class_1799.field_8037;
                    }
                }
            } else if (!this.method_7616(itemstack1, 10, 46, false)) {
                return class_1799.field_8037;
            }

            if (itemstack1.method_7960()) {
                slot.method_48931(class_1799.field_8037);
            } else {
                slot.method_7668();
            }

            if (itemstack1.method_7947() == itemstack.method_7947()) {
                return class_1799.field_8037;
            }

            slot.method_7667(p_39391_, itemstack1);
            if (p_39392_ == 0) {
                p_39391_.method_7328(itemstack1, false);
            }
        }

        return itemstack;
    }

    public boolean method_7597(@NotNull class_1657 p_39368_) {
        if (stillValid) return true;
        return method_17695(this.access, p_39368_, MPBlockCore.CraftingBlock.get());
    }


    public boolean method_7613(@NotNull class_1799 p_39381_, class_1735 p_39382_) {
        return p_39382_.field_7871 != this.resultSlots && super.method_7613(p_39381_, p_39382_);
    }

    public int method_7655() {
        return 0;
    }

    public int method_7653() {
        return this.craftSlots.method_17398();
    }

    public int method_7656() {
        return this.craftSlots.method_17397();
    }

    public int method_7658() {
        return 10;
    }

    public @NotNull class_5421 method_30264() {
        return class_5421.field_25763;
    }

    public boolean method_32339(int p_150553_) {
        return p_150553_ != this.method_7655();
    }
}

