package net.minecraftforge.registries;

import net.minecraft.class_1299;
import net.minecraft.class_1320;
import net.minecraft.class_1792;
import net.minecraft.class_1865;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public final class ForgeRegistries {
    public static final class_2378<class_2248> BLOCKS = class_7923.field_41175;
    public static final class_2378<class_1792> ITEMS = class_7923.field_41178;
    public static final class_2378<class_3917<?>> MENU_TYPES = class_7923.field_41187;
    public static final class_2378<class_1320> ATTRIBUTES = class_7923.field_41190;
    public static final class_2378<class_1865<?>> RECIPE_SERIALIZERS = class_7923.field_41189;
    public static final class_2378<class_1299<?>> ENTITY_TYPES = class_7923.field_41177;
    public static final class_2378<class_2591<?>> BLOCK_ENTITY_TYPES = class_7923.field_41181;

    private ForgeRegistries() {
    }
}
