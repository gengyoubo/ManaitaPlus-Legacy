package github.com.gengyoubo.item.portable;

import org.jetbrains.annotations.NotNull;
import github.com.gengyoubo.block.entity.MPGBrewingLogicHelper;
import github.com.gengyoubo.core.MPBlockEntityCore;
import github.com.gengyoubo.core.MPBlockCore;
import github.com.gengyoubo.menu.MPBrewingStandMenu;

import java.util.Arrays;
import net.minecraft.class_1262;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2624;
import net.minecraft.class_3222;
import net.minecraft.class_3913;

public class MPBrewingPortable extends MPGPortableItem {
    public MPBrewingPortable() {
        super("item.portableBrewing.");
    }

    @Override
    protected void openPortableMenu(class_3222 serverPlayer, class_1799 itemInHand, class_1937 level) {
        openPortableScreen(serverPlayer, itemInHand, level, "container.brewing_manaita",
                (containerId, inventory, player, heldStack, world) -> {
                    MPBrewingStandBlockEntity blockEntity = new MPBrewingStandBlockEntity(inventory.field_7546, heldStack);
                    return blockEntity.createMenu(containerId, inventory, player);
                });
    }

    public static class MPBrewingStandBlockEntity extends class_2624 {
        private static final int[] SLOTS_FOR_SIDES = new int[]{0, 1, 2, 4};
        private class_2371<class_1799> items = class_2371.method_10213(5, class_1799.field_8037);
        private boolean[] lastPotionCount;
        private final class_1657 player;
        private final class_1799 stack;

        protected final class_3913 dataAccess = new class_3913() {
            public int method_17390(int index) {
                return 0;
            }

            public void method_17391(int index, int value) {
            }

            public int method_17389() {
                return 2;
            }
        };

        public MPBrewingStandBlockEntity(class_1657 player, class_1799 stack) {
            super(MPBlockEntityCore.BREWING_BLOCK_ENTITY.get(), player.method_24515(), MPBlockCore.BrewingBlock.get().method_9564());
            this.player = player;
            this.stack = stack;
            method_11014(stack.method_7948());
        }

        protected @NotNull net.minecraft.class_2561 method_17823() {
            return net.minecraft.class_2561.method_43471("container.brewing_manaita");
        }

        public int method_5439() {
            return this.items.size();
        }

        public boolean method_5442() {
            for (class_1799 itemstack : this.items) {
                if (!itemstack.method_7960()) {
                    return false;
                }
            }
            return true;
        }

        private boolean[] getPotionBits() {
            boolean[] bits = new boolean[3];
            for (int i = 0; i < 3; ++i) {
                if (!this.items.get(i).method_7960()) {
                    bits[i] = true;
                }
            }
            return bits;
        }

        private static boolean isBrewable(class_2371<class_1799> items) {
            class_1799 ingredient = items.get(3);
            return !ingredient.method_7960();
        }

        private void doBrew(class_1937 level, class_2371<class_1799> items) {
            MPGBrewingLogicHelper.finishBrew(level, player.method_23317(), player.method_23318(), player.method_23321(), items, 3);
        }

        public void method_11014(@NotNull class_2487 tag) {
            super.method_11014(tag);
            this.items = class_2371.method_10213(this.method_5439(), class_1799.field_8037);
            class_1262.method_5429(tag, this.items);
        }

        protected void method_11007(@NotNull class_2487 tag) {
            super.method_11007(tag);
            class_1262.method_5426(tag, this.items);
        }

        public @NotNull class_1799 method_5438(int index) {
            return index >= 0 && index < this.items.size() ? this.items.get(index) : class_1799.field_8037;
        }

        public @NotNull class_1799 method_5434(int index, int count) {
            return class_1262.method_5430(this.items, index, count);
        }

        public @NotNull class_1799 method_5441(int index) {
            return class_1262.method_5428(this.items, index);
        }

        public void method_5447(int index, @NotNull class_1799 stack) {
            if (index >= 0 && index < this.items.size()) {
                this.items.set(index, stack);
                if (isBrewable(this.items)) {
                    doBrew(player.method_37908(), this.items);
                }

                boolean[] bits = this.getPotionBits();
                if (!Arrays.equals(bits, this.lastPotionCount)) {
                    this.lastPotionCount = bits;
                }
            }
            method_11007(this.stack.method_7948());
        }

        public boolean method_5443(@NotNull class_1657 player) {
            return true;
        }

        public boolean method_5437(int index, @NotNull class_1799 stack) {
            return MPGBrewingLogicHelper.canPlaceItem(index, stack, this.method_5438(index));
        }

        public void method_5448() {
            this.items.clear();
        }

        protected @NotNull class_1703 method_5465(int containerId, @NotNull class_1661 inventory) {
            return new MPBrewingStandMenu(containerId, inventory, this, this.dataAccess);
        }
    }
}
