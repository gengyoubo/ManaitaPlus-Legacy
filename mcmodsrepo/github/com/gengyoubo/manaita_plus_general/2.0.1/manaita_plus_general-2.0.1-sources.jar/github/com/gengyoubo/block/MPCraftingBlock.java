package github.com.gengyoubo.block;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3726;
import net.minecraft.class_3908;
import net.minecraft.class_3914;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.world.*;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.NotNull;
import github.com.gengyoubo.block.data.MPBlockData;
import github.com.gengyoubo.block.entity.MPCraftingBlockEntity;
import github.com.gengyoubo.menu.MPCraftingMenu;

import java.util.List;

import static github.com.gengyoubo.block.MPBrewingStandBlock.getItemStacks;

@SuppressWarnings("deprecation")
public class MPCraftingBlock extends class_2237 {

    private static final class_2561 CONTAINER_TITLE = class_2561.method_43471("container.crafting_manaita");


    public MPCraftingBlock() {
        super(class_4970.class_2251.method_9637().method_22488());
        this.method_9590(this.field_10647.method_11664().method_11657(MPBlockData.HOOK, 8).method_11657(MPBlockData.FACING, class_2350.field_11043).method_11657(MPBlockData.WALL,class_2350.field_11033).method_11657(MPBlockData.TYPES,0));
    }


    @Override
    public @NotNull class_265 method_9530(class_2680 p_60555_, @NotNull class_1922 p_60556_, @NotNull class_2338 p_60557_, @NotNull class_3726 p_60558_) {
        class_2350 wall = p_60555_.method_11654(MPBlockData.WALL);
        class_2350 facing = p_60555_.method_11654(MPBlockData.FACING);
        boolean hasHook = p_60555_.method_11654(MPBlockData.HOOK) != 8;
        return MPBlockData.getWallMountedShape(wall, facing, hasHook);
    }

    @Override
    public @NotNull List<class_1799> method_9560(@NotNull class_2680 p_287732_, class_8567.@NotNull class_8568 p_287596_) {
        List<class_1799> list = com.google.common.collect.Lists.newArrayList();
        list.add(new class_1799(this));
        int hook = p_287732_.method_11654(MPBlockData.HOOK);
        if (hook != 8) {
            class_1799 itemStack = new class_1799(github.com.gengyoubo.core.MPBlockCore.HookBlockItem.get());
            itemStack.method_7948().method_10569(github.com.gengyoubo.util.MPNBTData.ItemType, hook);
            list.add(itemStack);
        }
        return list;
    }


    public @NotNull class_1269 method_9534(@NotNull class_2680 p_52233_, @NotNull class_1937 p_52234_, @NotNull class_2338 p_52235_, @NotNull class_1657 p_52236_, @NotNull class_1268 p_52237_, @NotNull class_3965 p_52238_) {
        if (p_52234_.field_9236) {
            return class_1269.field_5812;
        } else {
            p_52236_.method_17355(p_52233_.method_26196(p_52234_, p_52235_));
//            p_52236_.awardStat(((ResourceLocation) ManaitaPlusStarCore.INTERACT_WITH_CRAFTING_MANAITA_TABLE.get()));
            return class_1269.field_21466;
        }

    }
//
    public class_3908 method_17454(@NotNull class_2680 p_52240_, @NotNull class_1937 p_52241_, @NotNull class_2338 p_52242_) {
        return new ExtendedScreenHandlerFactory() {
            @Override
            public @NotNull class_2561 method_5476() {
                return CONTAINER_TITLE;
            }

            @Override
            public void writeScreenOpeningData(net.minecraft.class_3222 player, class_2540 buf) {
                buf.method_10807(p_52242_);
            }

            @Override
            public @NotNull class_1703 createMenu(int containerId, @NotNull net.minecraft.class_1661 inventory, @NotNull class_1657 player) {
                return new MPCraftingMenu(containerId, inventory, class_3914.method_17392(p_52241_, p_52242_));
            }
        };
    }

    public class_2680 method_9605(class_1750 p_48689_) {
        return this.method_9564().method_11657(MPBlockData.WALL,p_48689_.method_8038().method_10153()).method_11657(MPBlockData.FACING, p_48689_.method_8042().method_10153());
    }


    public @NotNull class_2680 method_9598(class_2680 p_48722_, class_2470 p_48723_) {
        return p_48722_.method_11657(MPBlockData.FACING, p_48723_.method_10503(p_48722_.method_11654(MPBlockData.FACING)));
    }

    public @NotNull class_2680 method_9569(class_2680 p_48719_, class_2415 p_48720_) {
        return p_48719_.method_26186(p_48720_.method_10345(p_48719_.method_11654(MPBlockData.FACING)));
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> p_48725_) {
        p_48725_.method_11667(MPBlockData.FACING, MPBlockData.TYPES, MPBlockData.WALL, MPBlockData.HOOK);
    }

    public class_2586 method_10123(@NotNull class_2338 p_153277_, @NotNull class_2680 p_153278_) {
        return new MPCraftingBlockEntity(p_153277_, p_153278_);
    }
}

