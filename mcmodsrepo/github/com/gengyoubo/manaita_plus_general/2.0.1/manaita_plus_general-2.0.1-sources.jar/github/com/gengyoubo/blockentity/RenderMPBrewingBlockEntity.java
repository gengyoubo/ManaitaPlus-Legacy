package github.com.gengyoubo.blockentity;

import github.com.gengyoubo.block.entity.MPBrewingStandBlockEntity;
import github.com.gengyoubo.core.MPBlockCore;
import net.minecraft.class_1799;
import net.minecraft.class_5614;

public class RenderMPBrewingBlockEntity extends AbstractRenderMPBlockEntity<MPBrewingStandBlockEntity> {
    public RenderMPBrewingBlockEntity(class_5614.class_5615 context) {
        super(new class_1799(MPBlockCore.BrewingBlockItem.get()));
    }
}
