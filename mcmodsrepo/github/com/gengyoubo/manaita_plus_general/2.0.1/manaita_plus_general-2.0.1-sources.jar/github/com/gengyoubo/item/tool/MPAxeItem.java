package github.com.gengyoubo.item.tool;

import org.jetbrains.annotations.NotNull;
import github.com.gengyoubo.item.tool.base.MPTaggedToolItem;
import github.com.gengyoubo.item.tool.base.MPToolActionHelper;
import net.minecraft.class_1269;
import net.minecraft.class_1838;
import net.minecraft.class_3481;

public class MPAxeItem extends MPTaggedToolItem {
    public MPAxeItem() {
        super(class_3481.field_33713);
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        int range = getRange(context.method_8041()) >> 1;
        boolean changed = MPToolActionHelper.applyInRange(context, range, (pos, state) -> MPToolActionHelper.applyAxeActions(context, pos, state));
        return changed ? class_1269.method_29236(context.method_8045().field_9236) : class_1269.field_5811;
    }
}
