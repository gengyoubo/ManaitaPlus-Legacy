package github.com.gengyoubo.gui;

import github.com.gengyoubo.MPGConfig;
import github.com.gengyoubo.menu.MPCraftingMenu;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_465;
import net.minecraft.class_507;
import net.minecraft.class_518;
import org.jetbrains.annotations.NotNull;

public class MPCraftingScreen extends class_465<MPCraftingMenu> implements class_518 {
    private static final class_2960 CRAFTING_TABLE_LOCATION = new class_2960("textures/gui/container/crafting_table.png");
    private static final class_2960 RECIPE_BUTTON_LOCATION = new class_2960("textures/gui/recipe_button.png");
    private final class_507 recipeBookComponent = new class_507();
    private boolean widthTooNarrow;
    private final String doublingText;

    public MPCraftingScreen(MPCraftingMenu menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
        doublingText = MPGConfig.crafting_doubling_value + "x";
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        this.widthTooNarrow = this.field_22789 < 379;
        if (this.field_22787 != null) {
            this.recipeBookComponent.method_2597(this.field_22789, this.field_22790, this.field_22787, this.widthTooNarrow, this.field_2797);
        }
        this.field_2776 = this.recipeBookComponent.method_2595(this.field_22789, this.field_2792);
        this.method_37063(new class_344(this.field_2776 + 5, this.field_22790 / 2 - 49, 20, 18, 0, 0, 19, RECIPE_BUTTON_LOCATION, button -> {
            this.recipeBookComponent.method_2591();
            this.field_2776 = this.recipeBookComponent.method_2595(this.field_22789, this.field_2792);
            button.method_48229(this.field_2776 + 5, this.field_22790 / 2 - 49);
        }));
        this.method_25429(this.recipeBookComponent);
        this.method_48265(this.recipeBookComponent);
        this.field_25267 = 29;
    }

    @Override
    public void method_37432() {
        super.method_37432();
        this.recipeBookComponent.method_2590();
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.method_25420(guiGraphics);
        if (this.recipeBookComponent.method_2605() && this.widthTooNarrow) {
            this.method_2389(guiGraphics, partialTick, mouseX, mouseY);
            this.recipeBookComponent.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        } else {
            this.recipeBookComponent.method_25394(guiGraphics, mouseX, mouseY, partialTick);
            super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
            this.recipeBookComponent.method_2581(guiGraphics, this.field_2776, this.field_2800, true, partialTick);
        }

        this.method_2380(guiGraphics, mouseX, mouseY);
        this.recipeBookComponent.method_2601(guiGraphics, this.field_2776, this.field_2800, mouseX, mouseY);
    }

    @Override
    protected void method_2388(class_332 guiGraphics, int mouseX, int mouseY) {
        guiGraphics.method_51439(this.field_22793, this.field_22785, this.field_25267, this.field_25268, 4210752, false);
        guiGraphics.method_51439(this.field_22793, this.field_29347, this.field_25269, this.field_25270, 4210752, false);
        guiGraphics.method_51433(this.field_22793, doublingText, 126, 22, 4210752, false);
    }

    @Override
    protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        int left = this.field_2776;
        int top = (this.field_22790 - this.field_2779) / 2;
        guiGraphics.method_25302(CRAFTING_TABLE_LOCATION, left, top, 0, 0, this.field_2792, this.field_2779);
    }

    @Override
    protected boolean method_2378(int x, int y, int width, int height, double mouseX, double mouseY) {
        return (!this.widthTooNarrow || !this.recipeBookComponent.method_2605()) && super.method_2378(x, y, width, height, mouseX, mouseY);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (this.recipeBookComponent.method_25402(mouseX, mouseY, button)) {
            this.method_25395(this.recipeBookComponent);
            return true;
        } else {
            return this.widthTooNarrow && this.recipeBookComponent.method_2605() || super.method_25402(mouseX, mouseY, button);
        }
    }

    @Override
    protected boolean method_2381(double mouseX, double mouseY, int left, int top, int button) {
        boolean outside = mouseX < (double) left || mouseY < (double) top || mouseX >= (double) (left + this.field_2792) || mouseY >= (double) (top + this.field_2779);
        return this.recipeBookComponent.method_2598(mouseX, mouseY, this.field_2776, this.field_2800, this.field_2792, this.field_2779, button) && outside;
    }

    @Override
    protected void method_2383(@NotNull class_1735 slot, int slotId, int mouseButton, @NotNull class_1713 clickType) {
        super.method_2383(slot, slotId, mouseButton, clickType);
        this.recipeBookComponent.method_2600(slot);
    }

    @Override
    public void method_16891() {
        this.recipeBookComponent.method_2592();
    }

    @Override
    public @NotNull class_507 method_2659() {
        return this.recipeBookComponent;
    }
}
