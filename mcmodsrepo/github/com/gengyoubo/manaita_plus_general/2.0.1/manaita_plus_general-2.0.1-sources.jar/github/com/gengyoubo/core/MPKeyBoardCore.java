package github.com.gengyoubo.core;

import net.minecraft.class_304;

public class MPKeyBoardCore {
    public static class_304 MESSAGE_KEY;
    public static class_304 MESSAGE_ARMOR_KEY;

    private MPKeyBoardCore() {
    }
}
